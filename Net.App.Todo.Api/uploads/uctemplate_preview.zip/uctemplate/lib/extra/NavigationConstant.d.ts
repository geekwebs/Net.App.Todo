export declare class NavigationConstant {
    static DASHEMPTY: string;
    static DASHBOARD: string;
    static BACK_TO_PAGING: string;
    static BACK_TO_PAGING2: string;
    static BACK_TO_DETAIL: string;
    static BACK_TO_ADD_EDIT: string;
    static BACK_TO_EDIT: string;
    static PAGES_CHANGE_PASSWORD: string;
    static PAGES_LOGIN: string;
    static PAGES_REQ_PASSWORD: string;
    static PAGES_CONTENT: string;
    static ERROR: string;
    static NOTIF: string;
}
