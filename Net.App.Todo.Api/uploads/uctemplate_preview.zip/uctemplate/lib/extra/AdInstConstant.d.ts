import { HttpHeaders } from "@angular/common/http";
export declare class AdInsConstant {
    static RestrictionBetween: string;
    static RestrictionLike: string;
    static RestrictionEq: string;
    static RestrictionNeq: string;
    static RestrictionGt: string;
    static RestrictionGte: string;
    static RestrictionLt: string;
    static RestrictionLte: string;
    static RestrictionIn: string;
    static RestrictionNotIn: string;
    static RestrictionOr: string;
    static RestrictionOrNeq: string;
    static RestrictionIsNull: string;
    static RestrictionIsNotNull: string;
    static RestrictionGTE: string;
    static RestrictionLTE: string;
    static showData: string;
    static TimeoutSession: number;
    static GetListProduct: string;
    static FormDefault: string;
    static JoinTypeInner: string;
    static PAGE_STATE_SINGLE: string;
    static PAGE_STATE_MULTI: string;
    static PAGE_STATE_PREPAID: string;
    static FROM_PAGE_PAYMENT_RCV: string;
    static FROM_PAGE_CASHIER_TRX: string;
    static WatchRoleState: string;
    static WatchRoleLang: string;
    private static SpinnerHeaders;
    static SpinnerOptions: {
        headers: HttpHeaders;
    };
}
