import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie';
export declare class AdInsHelper {
    static ClearAllLog(cookieService: CookieService): void;
    static ClearPageAccessLog(cookieService: CookieService): void;
    static CheckSessionTimeout(environment: any, cookieService: CookieService): "1" | "0";
    static IsGrantAccess(environment: any, formPath: any): boolean;
    static transformAmount(element: any): string;
    static transformToDecimal(element: any): number | "";
    static Encrypt128CBC(plain: string, k: string, i: string): any;
    static RedirectUrl(router: Router, url: Array<string>, queryParams?: {}, isSkipLocation?: boolean): void;
    static SetLocalStorage(environment: any, key: string, value: string): void;
    static GetLocalStorage(environment: any, key: string): any;
    static SetCookie(environment: any, cookieService: CookieService, key: string, value: string): void;
    static GetCookie(environment: any, cookieService: CookieService, key: string): any;
    private static EncryptString;
    private static DecryptString;
    static GetUserAccess(environment: any, cookieService: CookieService): any;
}
