import * as i0 from "@angular/core";
export declare class LogService {
    _environment: Record<string, any>;
    constructor();
    set environment(env: Record<string, any>);
    get environment(): Record<string, any>;
    get Instance(): this;
    log(message: any, obj?: any): void;
    error(message: any, obj?: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LogService>;
}
