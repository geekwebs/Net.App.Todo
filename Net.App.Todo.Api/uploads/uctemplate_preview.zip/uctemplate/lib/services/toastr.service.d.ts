import { ToastrService } from 'ngx-toastr';
import * as i0 from "@angular/core";
export declare class NGXToastrService {
    toastr: ToastrService;
    constructor(toastr: ToastrService);
    typeSuccess(): void;
    typeInfo(): void;
    typeWarning(): void;
    typeError(): void;
    typeCustom(): void;
    progressBar(): void;
    timeout(): void;
    dismissToastOnClick(): void;
    clearToast(): void;
    showCloseButton(): void;
    enableHtml(): void;
    titleClass(): void;
    messageClass(): void;
    errorMessage(msg: any): void;
    typeSave(msg: any): void;
    typeErrorCustom(msg: any): void;
    successMessage(msg: any): void;
    warningMessage(msg: any): void;
    infoMessage(msg: any): void;
    errorAPI(status: any, reason: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NGXToastrService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NGXToastrService>;
}
