import * as i0 from "@angular/core";
export declare class ScrollToErrService {
    screenWindow: Element;
    formValidate(form: any): void;
    scrollIfFormHasErrors(form: any): Promise<any>;
    private scrollToError;
    private scrollTo;
    private filterFormEl;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollToErrService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ScrollToErrService>;
}
