import * as i0 from "@angular/core";
export declare class LocalStorageService {
    private Storage;
    constructor();
    remove(key: string): void;
    clear(): void;
    create(key: string, data: any): void;
    createOrUpdate(key: string, data: any, index?: number, before?: any): void;
    find(key: string): any;
    get size(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<LocalStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LocalStorageService>;
}
