import * as i0 from "@angular/core";
export interface Config {
    target: string;
    alias?: string;
    methodName: string;
    args: {
        [key: string]: any;
    };
}
export declare class ExecutorService {
    private executor;
    constructor();
    setExecutor(alias: string, executor: any): void;
    getExecutor(alias: string): any;
    invokeMethod(config: Config, params: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExecutorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ExecutorService>;
}
