import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export interface Message {
    type: string;
    data?: any;
}
export declare class BroadcastReceiverService {
    private channel;
    private message;
    event: Observable<Message>;
    constructor();
    pub(message: Message): void;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BroadcastReceiverService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BroadcastReceiverService>;
}
