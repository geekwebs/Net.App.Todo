import { ElementRef, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie';
import { BroadcastReceiverService } from './broadcast-receiver.service';
import * as i0 from "@angular/core";
export declare class ActiveSessionService {
    private router;
    private cookieService;
    private receiver;
    private Identity;
    private routerSub;
    private broadcaster;
    private askRefresh;
    private elementRef;
    private renderer;
    private hasAlert;
    constructor(router: Router, cookieService: CookieService, receiver: BroadcastReceiverService);
    initialize(elementRef: ElementRef, renderer: Renderer2): void;
    dispatchEvent(event: CustomEvent): void;
    logout(): void;
    unsubscribe(): void;
    private alertSessionChange;
    private clearSession;
    private setIdentity;
    private validate;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActiveSessionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ActiveSessionService>;
}
