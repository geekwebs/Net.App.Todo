import { FormGroup, NgForm } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class ContainerService {
    private Module;
    private enjiForm;
    private form;
    constructor();
    setModule(module: any): void;
    getComponent(className: string): any;
    setEnjiForm(enjiForm: any): void;
    getEnjiForm(): NgForm;
    setForm(formGroup: FormGroup): void;
    getForm(): FormGroup;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContainerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContainerService>;
}
