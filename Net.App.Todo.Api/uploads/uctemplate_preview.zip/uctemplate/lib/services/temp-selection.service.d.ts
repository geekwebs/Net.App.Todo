import * as i0 from "@angular/core";
export declare class TempSelectionService {
    private readonly key;
    private maps;
    constructor();
    setList(list: any[]): Map<string, any[]>;
    getList(): any[];
    remove(key: string): boolean;
    clearAll(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TempSelectionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TempSelectionService>;
}
