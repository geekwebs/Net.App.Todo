export interface FunctionHandler {
    beforeSave?: () => boolean;
    afterSave?: (result: any) => void;
    beforeNext?: () => any;
    callback?: (event: any) => void;
}
