import { Condition } from './condition';
import { FunctionAction, HttpAction, LinkAction, ModalAction, SwitchAction, ToasterAction } from './action';
export interface Button {
    id: string;
    key: string;
    displayName: string;
    btnType: "button" | "submit";
    position: string;
    icon: string;
    cssClass: string;
    action: LinkAction | HttpAction | FunctionAction | ToasterAction | ModalAction | SwitchAction;
    conditions: Condition[];
}
