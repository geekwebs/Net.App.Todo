import { Condition } from './condition';
import { FunctionAction, HttpAction, LinkAction, ModalAction, SwitchAction, ToasterAction } from './action';
export interface Case {
    conditions: Condition[];
    result: LinkAction | HttpAction | FunctionAction | ToasterAction | ModalAction | SwitchAction;
}
