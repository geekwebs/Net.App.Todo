import { FunctionHandler } from './FunctionHandler';
export interface BaseTemplate {
    pageName: string;
    handler?: FunctionHandler;
}
