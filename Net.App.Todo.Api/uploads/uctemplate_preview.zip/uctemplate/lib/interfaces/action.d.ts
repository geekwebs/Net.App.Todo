import { Case } from './case';
export interface Action {
    type: ActionType;
}
export interface ToasterAction extends Action {
    mode: string;
    message: string;
}
export interface CommonAction extends Action {
    target: string;
    params: PropValue[];
}
export interface LinkAction extends CommonAction {
    environment?: string;
    path: string;
}
export interface FunctionAction extends CommonAction {
    alias: string;
    methodName: string;
}
export interface LocalStorageAction extends CommonAction {
    mode: 'add' | 'edit' | 'delete' | 'clearAll';
    key?: string;
    backUrl?: string;
    mapObj: {
        propName: string;
        propValue: string;
    }[];
    excObj: {
        key: string;
    }[];
}
export interface HttpAction extends Action {
    environment: string;
    path: string;
    reqObj: PropValue[];
    onSuccess: Case[];
    onError: ToasterAction;
    mapResToDict: any[];
    excObj: {
        key: string;
    }[];
}
export interface SwitchAction extends Action {
    breakIfFound?: boolean;
    cases: Case[];
}
export interface ModalAction extends Action {
    isTemplate: boolean;
    width: string;
    backdropClass: string;
    disableClose: boolean;
    component: string;
    params: PropValue[];
    refreshFrom: any;
    affectedTable: string;
    mapObj: {
        propName: string;
        propValue: string;
    }[];
    excObj: {
        key: string;
    }[];
}
export interface PropValue {
    propName: string;
    propValue: string;
}
export declare enum ActionType {
    Link = "link",
    Http = "http",
    Function = "function",
    Modal = "modal",
    Toaster = "toaster",
    Switch = "switch",
    Callback = "callback",
    Confirm = "confirm",
    Reload = "reload",
    LocalStorage = "localStorage"
}
