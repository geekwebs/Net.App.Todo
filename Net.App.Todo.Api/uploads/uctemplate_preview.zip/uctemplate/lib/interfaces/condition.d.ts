export interface Condition {
    property: string;
    restriction: string;
    value: any;
}
