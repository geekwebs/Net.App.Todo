import { InputLookupObj } from './input-lookup-obj.model';
export declare class InputFieldObj {
    addr: any;
    areaCode4: any;
    areaCode3: any;
    phnArea1: any;
    phn1: any;
    phnExt1: any;
    phnArea2: any;
    phn2: any;
    phnExt2: any;
    faxArea: any;
    fax: any;
    subZipCode: any;
    areaCode2: any;
    areaCode1: any;
    city: any;
    inputLookupObj: InputLookupObj;
}
