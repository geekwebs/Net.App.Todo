export declare class CriteriaObj {
    propName: string;
    restriction: string;
    value: any;
    low: number;
    high: number;
    DataType: string;
    listValue: Array<any>;
    constructor();
}
