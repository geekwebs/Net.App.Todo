import { CriteriaObj } from '../criteria-obj.model';
import { UcTemplateService } from '../../uctemplate.service';
import { IntegrationObj } from '../integration-obj.model';
export declare class UcTempPagingObj {
    private service;
    urlJson: string;
    enviromentUrl: string;
    apiQryPaging: string;
    pagingJson: string;
    isReady: boolean;
    addCritInput: Array<CriteriaObj>;
    ddlEnvironments: Array<EnviObj>;
    whereValue: Array<WhereValueObj>;
    fromValue: Array<FromValueObj>;
    navigationConst: any;
    listEnvironments: Array<EnvisObj>;
    dataInput: any;
    templateService: any;
    dicts: Record<string, any>;
    isJoinExAPI: boolean;
    integrationObj: IntegrationObj;
    useSafeUrl: boolean;
    constructor(service: UcTemplateService);
}
export declare class EnviObj {
    name: string;
    environment: string;
    constructor();
}
export declare class WhereValueObj {
    property: string;
    value: any;
    constructor();
}
export declare class FromValueObj {
    property: string;
    value: any;
    constructor();
}
export declare class EnvisObj {
    environment: string;
    url: string;
    constructor();
}
