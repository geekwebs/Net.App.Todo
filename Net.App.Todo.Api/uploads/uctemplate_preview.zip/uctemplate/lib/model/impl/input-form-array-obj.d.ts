import { UcTemplateService } from '../../uctemplate.service';
export declare class InputFormArrayObj {
    private service;
    title: string;
    formId: string;
    formJson: string;
    IsSubsection: boolean;
    IsVertical: boolean;
    IsModeAdd: boolean;
    CustomObjName: string;
    ColumnObject: Object;
    environment: any;
    listEnvironments: {
        [Id: string]: string;
    };
    formInput?: any;
    isReady?: boolean;
    dicts?: Record<string, any>;
    onloadAct: any[];
    conditionalDel: any;
    navigationConst: any;
    isPageFromService: string;
    pagesUrl: string;
    constructor(service: UcTemplateService);
}
