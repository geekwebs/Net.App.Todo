import { UcTemplateService } from '../../uctemplate.service';
export declare class InputGridviewObj {
    private service;
    id?: string;
    isSubsection: boolean;
    title: string;
    resultData: any;
    searchComp: any;
    apiUrl: any;
    deleteUrl: any;
    pageNow: any;
    pageSize: any;
    pagingJson: any;
    navigationConst: any;
    dataInput: any;
    isReady: boolean;
    isFromApi: boolean;
    dicts: Record<string, any>;
    serviceObj: any;
    listBtn: any[];
    usePagination: boolean;
    defaultChecked: boolean;
    useSafeUrl: boolean;
    constructor(service: UcTemplateService);
}
