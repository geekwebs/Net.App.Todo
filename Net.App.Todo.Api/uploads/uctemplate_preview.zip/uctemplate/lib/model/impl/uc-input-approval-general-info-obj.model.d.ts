import { UcTemplateService } from '../../uctemplate.service';
export declare class UcInputApprovalGeneralInfoObj {
    private service;
    TaskId: number;
    EnvUrl: string;
    PathUrl: string;
    constructor(service: UcTemplateService);
}
