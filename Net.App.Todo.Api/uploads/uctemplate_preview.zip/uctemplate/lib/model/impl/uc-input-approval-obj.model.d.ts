import { UcTemplateService } from '../../uctemplate.service';
export declare class UcInputApprovalObj {
    private service;
    TaskId: number;
    EnvUrl: string;
    PathUrlGetLevelVoting: string;
    PathUrlGetPossibleResult: string;
    PathUrlGetPossibleResultMulti: string;
    PathUrlSubmitApproval: string;
    PathUrlGetNextNodeMember: string;
    PathUrlGetReasonActive: string;
    PathUrlGetChangeFinalLevel: string;
    PathUrlReturnToLevel: string;
    PathUrlContinueToLevel: string;
    RequestId: number;
    PathUrlGetHistory: string;
    TrxNo: string;
    requiredNotes: boolean;
    showApvHistory: boolean;
    notesReqWhen: string[];
    isMultiApv: boolean;
    dicts: Record<string, any>;
    apvGridObj: any;
    listApproveProp: string;
    IsReturnToRequestorOnly: boolean;
    constructor(service: UcTemplateService);
}
