import { FormInputType, InputUcFormObj } from "@adins/ucform";
import { UcTemplateService } from '../../uctemplate.service';
export declare class UcInputFormObj implements InputUcFormObj {
    private service;
    title: string;
    formId: string;
    formJson: string;
    IsSubsection: boolean;
    IsCollapsed: boolean;
    IsVertical: boolean;
    IsModeAdd: boolean;
    FormEditObject: Object;
    environment: any;
    listEnvironments: {
        [Id: string]: string;
    };
    formInput: FormInputType[];
    dicts: Record<string, any>;
    navigationConst: any;
    onloadAct: any[];
    initAction: any[];
    isPageFromService: string;
    pagesUrl: string;
    pageName?: string;
    constructor(service: UcTemplateService);
}
