import { UcTemplateService } from '../../uctemplate.service';
export declare class UcInputApprovalHistoryObj {
    private service;
    RequestId: number;
    EnvUrl: string;
    PathUrl: string;
    constructor(service: UcTemplateService);
}
