export declare class IntegrationObj {
    baseUrl: string;
    apiPath: string;
    requestObj: Object;
    leftColumnToJoin: string;
    rightColumnToJoin: string;
    joinType: string;
    constructor();
}
export declare class UcPagingConstant {
    static JoinTypeInner: string;
    static JoinTypeLeft: string;
}
