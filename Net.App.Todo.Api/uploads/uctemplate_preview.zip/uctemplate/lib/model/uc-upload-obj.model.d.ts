import { UcTemplateService } from '../uctemplate.service';
export declare class UcUploadObj {
    private service;
    title: string;
    subsectionId: string;
    formatsAllowed: string;
    UploadTypeCode: string;
    ErrorDownloadUrl: string;
    TemplateUrl: string;
    TemplateName: string;
    FileErrorName: string;
    environmentUrl: string;
    apiQryPaging: string;
    pagingJson: string;
    SheetName: string;
    url: string;
    theme: string;
    id: number;
    hideProgressBar: boolean;
    hideResetBtn: boolean;
    hideSelectBtn: boolean;
    maxSize: number;
    multiple: boolean;
    headers: any;
    resetUpload: boolean;
    replaceTexts: ReplaceTexts;
    isDownloadTmplt: boolean;
    downloadTmpltOpt: any[];
    ddlEnvironments: Array<EnviObj>;
    listEnvironments: Array<EnvisObj>;
    dataInput: any;
    additionalPayload: Record<string, string>;
    constructor(service: UcTemplateService);
}
export declare class EnviObj {
    name: string;
    environment: string;
    constructor();
}
export declare class EnvisObj {
    environment: string;
    url: string;
    constructor();
}
export declare class ReplaceTexts {
    selectFileBtn: string;
    resetBtn: string;
    uploadBtn: string;
    dragNDropBox: string;
    attachPinBtn: string;
    afterUploadMsg_success: string;
    afterUploadMsg_error: string;
}
