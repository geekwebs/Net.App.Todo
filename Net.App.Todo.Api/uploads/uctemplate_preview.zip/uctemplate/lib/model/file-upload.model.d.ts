export declare class FileUploadObj {
    label: string;
    propName: string;
    docuploadType: string;
    limitFileSize: number;
    allowedExt: string;
    isRequired: boolean;
    isSubsection: boolean;
    subsectionTitle: string;
    metadata: Metadata[];
    constructor();
}
export declare class Metadata {
    label: string;
    value: string;
}
