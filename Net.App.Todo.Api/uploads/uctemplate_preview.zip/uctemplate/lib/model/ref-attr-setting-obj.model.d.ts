import { InputLookupObj } from './input-lookup-obj.model';
import { UcTemplateService } from '../uctemplate.service';
export declare class RefAttrSettingObj {
    private service;
    IsVertical: boolean;
    IsDisable: boolean;
    IsShowBtnRefresh?: boolean;
    UrlGetLookupExistingValue?: string;
    UrlGetRuleForAttrContent?: string;
    UrlGetListAttr: string;
    ReqGetListAttrObj: object;
    Title?: string;
    Variable?: string;
    EditObj: any[];
    IsAdd: boolean;
    DefaultSettingUcLookupObj?: InputLookupObj;
    constructor(service: UcTemplateService);
}
export declare class EnvisObj {
    environment: string;
    url: string;
    constructor();
}
