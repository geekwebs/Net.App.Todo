export declare enum InputType {
    BLANK = "BLANK",
    TEXT = "TEXT",
    TEXTAREA = "TEXTAREA",
    DATE = "DATE",
    DATETIME = "DATETIME",
    TIME = "TIME",
    BOOL = "BOOL",
    NUMERIC = "NUMERIC",
    CURRENCY = "CURRENCY",
    PERCENT = "PERCENT",
    LOOKUP = "LOOKUP",
    DROPDOWNLIST = "DDL",
    LABEL = "LABEL",
    ADDRESS = "ADDRESS"
}
export declare enum ValidatorPattern {
    CHARACTER_ONLY = "^[a-zA-Z ]*$",
    CHARACTER_ONLY_REQUIRED = "^[a-zA-Z ]*$",
    CHARACTER_ONLY_NON_WHITESPACE = "^[a-zA-Z]*$",
    CHARACTER_ONLY_NON_WHITESPACE_REQUIRED = "^[a-zA-Z]+$",
    NUMBER_ONLY = "^[0-9]*$",
    NUMBER_ONLY_REQUIRED = "^[0-9]+$",
    NUMBER_ONLY_DECIMAL = "^[0-9]+([,.][0-9]+)?$",
    EMAIL_SMALL_CASE = "^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$",
    EMAIL_ALL_CASE = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,4}$",
    MULTIPLE_EMAIL_ALL_CASE = "^(([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)(s*;\\s*|\\s*$))+$",
    VAT_INVOICE = "^[A-Za-z0-9]{3}.[A-Za-z0-9]{3}.[A-Za-z0-9]{2}.[A-Za-z0-9]{8}$",
    VAT_INVOICE_NUMBER_ONLY = "^[0-9]{2}.[0-9]{3}.[0-9]{3}.[0-9]{1}-[0-9]{3}.[0-9]{3}$"
}
export declare type FormInputType = FormInputTypeBlank | FormInputTypeText | FormInputTypeTextarea | FormInputTypeDate | FormInputTypeDatetime | FormInputTypeTime | FormInputTypeBool | FormInputTypeNumeric | FormInputTypeCurrency | FormInputTypePercent | FormInputTypeLookup | FormInputTypeDdl | FormInputTypeLabel | FormInputTypeAddress;
declare type FormInputTypeBlank = {
    Type: "BLANK";
};
declare type FormInputTypeText = BaseFormInputType & {
    Type: "TEXT";
    Pattern?: ValidatorPatternType;
    CustomPattern?: CustomPatternType[];
    Min?: number;
    Max?: number;
    Value?: string;
    Placeholder?: string;
};
declare type FormInputTypeTextarea = BaseFormInputType & {
    Type: "TEXTAREA";
    Pattern?: ValidatorPatternType;
    CustomPattern?: CustomPatternType[];
    Min?: number;
    Max?: number;
    Value?: string;
    Placeholder?: string;
};
declare type FormInputTypeDate = BaseFormInputTypeNoUppercase & {
    Type: "DATE";
    Min?: string;
    Max?: string;
    Value?: string;
};
declare type FormInputTypeDatetime = BaseFormInputTypeNoUppercase & {
    Type: "DATETIME";
    Min?: string;
    Max?: string;
    Value?: string;
};
declare type FormInputTypeTime = BaseFormInputTypeNoUppercase & {
    Type: "TIME";
    Value?: string;
};
declare type FormInputTypeBool = BaseFormInputTypeNoUppercase & {
    Type: "BOOL";
    Value?: boolean;
};
declare type FormInputTypeNumeric = BaseFormInputTypeNoUppercase & {
    Type: "NUMERIC";
    Min?: number;
    Max?: number;
    Value?: number;
};
declare type FormInputTypeCurrency = BaseFormInputTypeNoUppercase & {
    Type: "CURRENCY";
    CurrencyMaskConfig?: MaskConfigType;
    Min?: number;
    Max?: number;
    Value?: number;
};
declare type FormInputTypePercent = BaseFormInputTypeNoUppercase & {
    Type: "PERCENT";
    CurrencyMaskConfig?: MaskConfigType;
    Min?: number;
    Max?: number;
    Value?: number;
};
declare type FormInputTypeLookup = Omit<BaseFormInputTypeNoUppercase, "IsEditable"> & {
    Type: "LOOKUP";
};
declare type FormInputTypeDdl = BaseFormInputTypeNoUppercase & {
    Type: "DDL";
    UseDefaultValue: boolean;
    DdlReqObj?: DdlReqObjType;
    DdlItemsObj?: KeyValueDdlItemsType[];
};
declare type FormInputTypeLabel = {
    Type: "LABEL";
    Label: string;
    Variable: string;
    Value: string;
};
declare type FormInputTypeAddress = {
    Type: "ADDRESS";
    Variable: string;
    IsRequired?: boolean;
    IsReadonly?: boolean;
    IsUpperCase?: boolean;
    IsHide?: boolean;
    IsEditable?: boolean;
};
declare type BaseFormInputTypeNoUppercase = Omit<BaseFormInputType, "IsUppercase">;
declare type BaseFormInputType = {
    Label: string;
    Variable: string;
    IsRequired?: boolean;
    IsUppercase?: boolean;
    IsCallback?: boolean;
    IsReadonly?: boolean;
    IsHide?: boolean;
    IsEditable?: boolean;
};
declare type MaskConfigType = {
    align?: "left" | "center" | "right";
    allowNegative?: boolean;
    decimal?: string;
    precision?: number;
    prefix?: string;
    suffix?: string;
    thousands?: string;
    nullable?: boolean;
    inputMode?: 0 | 1;
};
declare type DdlReqObjType = {
    Environment: string;
    Url: string;
    CustomObjName?: string;
    CustomKeyName?: string;
    CustomValueName?: string;
    ReqObj?: Record<string, string>;
};
declare type ValidatorPatternType = keyof typeof ValidatorPattern;
declare type KeyValueDdlItemsType = {
    Key: string;
    Value: string;
};
export declare type CustomPatternType = {
    pattern: string;
    invalidMsg: string;
};
export declare enum CallbackKeys {
    CB_UPDATE_CREATE_APV = "cbUpdateCreateApvScheme"
}
export {};
