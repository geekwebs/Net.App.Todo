import { UcTemplateService } from '../uctemplate.service';
export declare class UcViewGenericObj {
    private service;
    viewInput: string;
    viewEnvironment: string;
    ddlEnvironments: Array<EnviObj>;
    whereValue: Array<any>;
    navigationConst: any;
    listEnvironments: Array<EnvisObj>;
    dataInput: any;
    dicts: Record<string, any>;
    IsCard: boolean;
    environment: any;
    Experimental: boolean;
    constructor(service: UcTemplateService);
}
export declare class EnviObj {
    name: string;
    environment: string;
    constructor();
}
export declare class WhereValueObj {
    property: string;
    value: any;
    constructor();
}
export declare class EnvisObj {
    environment: string;
    url: string;
    constructor();
}
