import { CriteriaObj } from "./criteria-obj.model";
import { UcTemplateService } from '../uctemplate.service';
import { IntegrationObj } from './integration-obj.model';
export declare class UcPagingObj {
    private service;
    _url: string;
    enviromentUrl: string;
    title: string;
    apiQryPaging: string;
    deleteUrl: string;
    pagingJson: string;
    arrCritObj: any;
    addCritInput: Array<CriteriaObj>;
    ddlEnvironments: Array<EnviObj>;
    fromValue: Array<FromValueObj>;
    whereValue: Array<WhereValueObj>;
    isHideSearch: boolean;
    isSearched: boolean;
    delay: number;
    navigationConst: any;
    listEnvironments: Array<EnvisObj>;
    isJoinExAPI: boolean;
    isGetAllData: boolean;
    integrationObj: IntegrationObj;
    dataInput: any;
    dicts: Record<string, any>;
    useSafeUrl: boolean;
    constructor(service: UcTemplateService);
}
export declare class EnviObj {
    name: string;
    environment: string;
    constructor();
}
export declare class FromValueObj {
    property: string;
    value: any;
    constructor();
}
export declare class WhereValueObj {
    property: string;
    value: any;
    constructor();
}
export declare class EnvisObj {
    environment: string;
    url: string;
    constructor();
}
