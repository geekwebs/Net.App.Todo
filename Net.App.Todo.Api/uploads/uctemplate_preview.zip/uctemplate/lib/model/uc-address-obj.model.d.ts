export declare class UcAddressObj {
    Addr: string;
    AreaCode4: string;
    AreaCode3: string;
    AreaCode2: string;
    AreaCode1: string;
    City: string;
    PhnArea1: string;
    Phn1: string;
    PhnExt1: string;
    PhnArea2: string;
    Phn2: string;
    PhnExt2: string;
    PhnArea3: string;
    Phn3: string;
    PhnExt3: string;
    Notes: string;
    FaxArea: string;
    Fax: string;
    MrHouseOwnershipCode: string;
    SubZipcode: string;
    StayLength: number;
    RowVersion: string;
    StaySince: string;
    constructor();
}
