export declare class ViewFileUploadObj {
    fullPath: string;
    fullPathDownload: string;
    deletePath: string;
    code: string;
    isSubsection: boolean;
    subsectionTitle: string;
    metadata: Metadata[];
    canDelete: boolean;
    hideWhenEmpty: boolean;
    constructor();
}
export declare class Metadata {
    label: string;
    value: string;
}
