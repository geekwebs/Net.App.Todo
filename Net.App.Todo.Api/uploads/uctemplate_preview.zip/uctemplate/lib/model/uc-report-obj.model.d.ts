import { UcTemplateService } from '../uctemplate.service';
export declare class InputReportObj {
    private service;
    JsonPath: string;
    EnvironmentUrl: string;
    ApiReportPath: string;
    ModuleCode: string;
    ddlEnvironments: Array<EnviObj>;
    listEnvironments: Array<EnvisObj>;
    dataInput: any;
    useSubReport: boolean;
    subReport?: any;
    constructor(service: UcTemplateService);
}
export declare class EnviObj {
    name: string;
    environment: string;
    constructor();
}
export declare class EnvisObj {
    environment: string;
    url: string;
    constructor();
}
