import { CurrencyMaskConfig } from "ngx-currency";
import { FormInputType, InputType } from "./constants";
import { KeyValueObj } from "./key-value-obj.model";
export declare class InputUcFormObj {
    title: string;
    formId: string;
    formJson: string;
    formInput: FormInputType[];
    IsSubsection: boolean;
    IsVertical: boolean;
    IsModeAdd: boolean;
    FormEditObject: Object;
    listEnvironments: {
        [Id: string]: string;
    };
}
export declare class UcFormObj {
    Type: InputType;
    Label: string;
    Variable: string;
    Placeholder: string;
    IsRequired: boolean;
    IsUppercase: boolean;
    IsCallback: boolean;
    IsReadonly: boolean;
    IsHide: boolean;
    IsEditable: boolean;
    Pattern?: string;
    CustomPattern?: Array<any>;
    Min?: string;
    Max?: string;
    DdlReqObj?: DdlReqObj;
    DdlItemsObj?: KeyValueObj[];
    UseDefaultValue?: boolean;
    CurrencyMaskConfig?: CurrencyMaskConfig;
    Value?: string | boolean | number;
    constructor();
}
export declare class DdlReqObj {
    Environment: string;
    Url: string;
    CustomObjName: string;
    CustomKeyName: string;
    CustomValueName: string;
    ReqObj: object;
    constructor();
}
