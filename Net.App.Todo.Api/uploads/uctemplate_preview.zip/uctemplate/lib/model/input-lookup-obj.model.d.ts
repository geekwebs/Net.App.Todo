import { UcTemplateService } from '../uctemplate.service';
export declare class InputLookupObj {
    private service;
    urlJson: string;
    urlQryPaging: string;
    urlEnviPaging: string;
    _url: any;
    nameSelect: any;
    idSelect: any;
    jsonSelect: any;
    addCritInput: any;
    isRequired: boolean;
    pagingJson: any;
    genericJson: any;
    isReadonly: boolean;
    isReady: boolean;
    isDisable: boolean;
    ddlEnvironments: Array<EnviObj>;
    listEnvironments: Array<EnvisObj>;
    title: any;
    isClear: boolean;
    IsUpdate: boolean;
    dataInput: any;
    placeholder: string;
    constructor(service: UcTemplateService);
}
export declare class EnviObj {
    name: string;
    environment: string;
    constructor();
}
export declare class EnvisObj {
    environment: string;
    url: string;
    constructor();
}
