export declare class KeyValueObj {
    Key: string;
    Value: string;
    constructor();
}
