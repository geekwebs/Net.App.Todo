import * as i0 from '@angular/core';
import { Injectable, EventEmitter, Component, Inject, Input, Output, NgModule } from '@angular/core';
import * as i2 from '@angular/router';
import { NavigationEnd, RouterModule } from '@angular/router';
import Swal from 'sweetalert2';
import * as i2$1 from 'ngx-cookie';
import { BehaviorSubject, lastValueFrom } from 'rxjs';
import { __awaiter, __asyncValues, __rest } from 'tslib';
import * as i5 from '@angular/common';
import { formatDate, CommonModule } from '@angular/common';
import * as CryptoJS from 'crypto-js';
import * as i3 from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import Stepper from 'bs-stepper';
import * as i12 from '@angular/material/dialog';
import { MatDialogConfig, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import * as i1$1 from '@angular/forms';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import * as i6 from '@adins/ucform';
import { UcformModule } from '@adins/ucform';
import * as i7 from '@adins/ucformarray';
import { UcformarrayModule } from '@adins/ucformarray';
import * as i1 from 'ngx-toastr';
import * as i14 from '@adins/ucattribute2';
import { Ucattribute2Module } from '@adins/ucattribute2';
import * as i15 from '@adins/fe-core';
import * as i16 from '@adins/ucapprovalcreate';
import { UcapprovalcreateModule } from '@adins/ucapprovalcreate';
import * as i17 from '@adins/ucapproval-r3';
import { UcapprovalR3Module } from '@adins/ucapproval-r3';
import * as i18 from '@adins/ucviewgeneric';
import { UcviewgenericModule } from '@adins/ucviewgeneric';
import * as i19 from '@adins/ucaddtotemp';
import { UcaddtotempModule } from '@adins/ucaddtotemp';
import * as i20 from '@adins/uctable';
import { UctableModule } from '@adins/uctable';
import * as i21 from '@adins/ucpaging';
import { UcpagingModule } from '@adins/ucpaging';
import * as i22 from '@adins/ucapproval-history';
import { UcapprovalHistoryModule } from '@adins/ucapproval-history';
import * as i23 from '@adins/ucapprovalgeneralinfo';
import { UcapprovalgeneralinfoModule } from '@adins/ucapprovalgeneralinfo';
import * as i24 from '@adins/ucreport';
import { UcreportModule } from '@adins/ucreport';
import * as i25 from '@adins/ucupload';
import { UcuploadModule } from '@adins/ucupload';
import * as i26 from '@angular/material/tabs';
import { MatTabsModule } from '@angular/material/tabs';
import { UcDirectiveUpperCaseModule } from '@adins/uc-directive-upper-case';
import { NgbModule, NgbModalModule, NgbCollapseModule } from '@ng-bootstrap/ng-bootstrap';
import { UcSubsectionModule } from '@adins/uc-subsection';
import { UcgridviewModule } from '@adins/ucgridview';
import { UcFileUploadModule } from '@adins/uc-file-upload';
import { UcviewfileuploadModule } from '@adins/ucviewfileupload';

class ContainerService {
    constructor() { }
    setModule(module) {
        this.Module = module;
    }
    getComponent(className) {
        return this.Module[className];
    }
    setEnjiForm(enjiForm) {
        this.enjiForm = enjiForm;
        console.log('ngForm', this.enjiForm);
    }
    getEnjiForm() {
        return this.enjiForm;
    }
    setForm(formGroup) {
        this.form = formGroup;
    }
    getForm() {
        return this.form;
    }
}
ContainerService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: ContainerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
ContainerService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: ContainerService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: ContainerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

class TempSelectionService {
    constructor() {
        this.key = 'LIST_TEMP';
        this.maps = new Map();
    }
    setList(list) {
        return this.maps.set(this.key, list);
    }
    getList() {
        return this.maps.get(this.key) || [];
    }
    remove(key) {
        return this.maps.delete(key);
    }
    clearAll() {
        return this.maps.clear();
    }
}
TempSelectionService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: TempSelectionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
TempSelectionService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: TempSelectionService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: TempSelectionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

class ExecutorService {
    constructor() {
        this.executor = new Map();
    }
    setExecutor(alias, executor) {
        this.executor.set(alias, executor);
    }
    getExecutor(alias) {
        return this.executor.get(alias);
    }
    invokeMethod(config, params) {
        const target = this.getExecutor(config.alias);
        if (typeof target === 'function') {
            return target(...Object.values(params));
        }
        if (typeof target[config.methodName] === 'function') {
            return target[config.methodName](...Object.values(params));
        }
    }
}
ExecutorService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: ExecutorService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
ExecutorService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: ExecutorService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: ExecutorService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

class LogService {
    constructor() { }
    set environment(env) {
        this._environment = env;
    }
    get environment() {
        return this._environment;
    }
    get Instance() {
        return this;
    }
    log(message, obj) {
        var _a, _b;
        // Ignore log in production mode
        if (!!((_a = this.environment) === null || _a === void 0 ? void 0 : _a.production) && !!((_b = this.environment) === null || _b === void 0 ? void 0 : _b.disableLog)) {
            return;
        }
        if (!obj) {
            return console.log(message);
        }
        return console.log(message, obj);
    }
    error(message, obj) {
        var _a;
        // Ignore log in production mode
        if ((_a = this.environment) === null || _a === void 0 ? void 0 : _a.production) {
            return;
        }
        if (!obj) {
            return console.error(message);
        }
        return console.error(message, obj);
    }
}
LogService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: LogService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
LogService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: LogService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: LogService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

class BroadcastReceiverService {
    constructor() {
        this.message = new BehaviorSubject({ type: 'none' });
        this.event = this.message.asObservable();
        this.channel = new BroadcastChannel('com.ad-ins.ngx');
        // Listen for incoming messages
        this.channel.onmessage = event => {
            this.message.next(event.data);
        };
    }
    pub(message) {
        // Send a message through the BroadcastChannel
        this.channel.postMessage(message);
    }
    close() {
        // Close the BroadcastChannel when no longer needed
        this.channel.close();
    }
}
BroadcastReceiverService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: BroadcastReceiverService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
BroadcastReceiverService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: BroadcastReceiverService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: BroadcastReceiverService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

var EventType;
(function (EventType) {
    EventType["UserLogin"] = "user:login";
    EventType["UserLogout"] = "user:logout";
    EventType["ChangeRole"] = "change:role";
})(EventType || (EventType = {}));
class ActiveSessionService {
    constructor(router, cookieService, receiver) {
        this.router = router;
        this.cookieService = cookieService;
        this.receiver = receiver;
        this.askRefresh = false;
        this.hasAlert = false;
    }
    initialize(elementRef, renderer) {
        this.elementRef = elementRef;
        this.renderer = renderer;
        // Initiate Session Identity
        this.setIdentity(this.cookieService.get('UserAccess'));
        document.addEventListener('visibilitychange', () => {
            // let routeChangeSub: Subscription;
            if (document.hidden) {
                console.log('Identity', this.Identity);
            }
            else {
                this.validate();
            }
        });
        // Event listener for user logout
        window.addEventListener(EventType.UserLogout, () => {
            this.Identity = null;
            sessionStorage.clear();
        });
        // Event listener for change role
        window.addEventListener(EventType.ChangeRole, event => {
            this.setIdentity(event['detail']['Identity']);
        });
        // Receive user event handler
        this.broadcaster = this.receiver.event.subscribe(event => {
            switch (event.type) {
                case EventType.UserLogout:
                    Swal.close();
                    this.clearSession();
                    break;
                case EventType.ChangeRole:
                    console.log('change:role', event);
                    const latestIdentity = event.data.Identity;
                    this.askRefresh = this.Identity ? latestIdentity !== this.Identity : false;
                    break;
                case EventType.UserLogin:
                    Swal.close();
                    this.askRefresh = false;
                    this.setIdentity(event.data.Identity);
                    this.router.navigate(['Dashboard', 'Dash-Board']);
                    break;
                default:
                    console.log(`Event [${event.type}] is not supported.`);
                    break;
            }
        });
        this.routerSub = this.router.events.subscribe(next => {
            if (next instanceof NavigationEnd) {
                setTimeout(() => {
                    this.validate();
                }, 2 * 1000);
            }
        });
    }
    dispatchEvent(event) {
        window.dispatchEvent(event);
        this.receiver.pub({ type: event.type, data: event.detail });
    }
    logout() {
        const event = new CustomEvent(EventType.UserLogout);
        this.dispatchEvent(event);
    }
    unsubscribe() {
        this.routerSub.unsubscribe();
        this.broadcaster.unsubscribe();
        this.receiver.close();
    }
    alertSessionChange() {
        const msgr = Swal.mixin({
            customClass: {
                confirmButton: 'btn btn-primary-2',
                cancelButton: 'btn btn-link-2'
            },
            buttonsStyling: true
        });
        msgr.fire({
            title: 'Session Identity Invalid',
            text: 'Your session identity has been changed, please refresh your current page!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Refresh',
            cancelButtonText: 'Cancel',
            reverseButtons: true
        }).then(result => {
            if (result.isConfirmed) {
                location.reload();
            }
        });
    }
    clearSession() {
        this.Identity = null;
        this.askRefresh = false;
        sessionStorage.clear();
        const url = location.href;
        if (!url.includes('Login')) {
            this.router.navigate(['Pages', 'Login']);
        }
    }
    setIdentity(identity) {
        if (!identity) {
            return;
        }
        this.Identity = identity;
        sessionStorage.setItem('Identity', this.Identity);
    }
    validate() {
        if (!this.askRefresh) {
            return;
        }
        const containerElement = this.elementRef.nativeElement.querySelector('.content-wrapper');
        if (containerElement) {
            const buttons = containerElement.querySelectorAll('button'); // formElement.querySelector('button');
            console.log('buttons', buttons);
            buttons.forEach((button) => {
                if (button.type === 'button') {
                    button.setAttribute('disabled', 'disabled');
                }
                else {
                    this.renderer.listen(button, 'click', (event) => {
                        // Stop form from default submission and run custom event handler
                        event.preventDefault();
                        this.alertSessionChange();
                    });
                }
            });
        }
        this.alertSessionChange();
    }
}
ActiveSessionService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: ActiveSessionService, deps: [{ token: i2.Router }, { token: i2$1.CookieService }, { token: BroadcastReceiverService }], target: i0.ɵɵFactoryTarget.Injectable });
ActiveSessionService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: ActiveSessionService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: ActiveSessionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: i2.Router }, { type: i2$1.CookieService }, { type: BroadcastReceiverService }]; } });

// TODO: need to remove this file and use ScrollToErrFormService from @adins/fe-core as late of Q3
// might need little adjustment / syncrhonize between code when this file going to removed
class ScrollToErrService {
    formValidate(form) {
        console.log(form);
        this.scrollIfFormHasErrors(form).then(() => {
            // Run any additional functionality if you need to. 
        });
    }
    scrollIfFormHasErrors(form) {
        return __awaiter(this, void 0, void 0, function* () {
            yield form.invalid;
            this.scrollToError();
        });
    }
    scrollToError() {
        const elementsWithError = document.getElementsByClassName('ng-invalid');
        // check if its a modal or not
        let isModal = false;
        const filteredElForms = this.filterFormEl(elementsWithError);
        if (elementsWithError.length !== filteredElForms.length) {
            // maybe its a modal
            const a = document.getElementsByTagName("mat-dialog-container");
            if (a.length > 0) {
                this.screenWindow = a[0];
                isModal = true;
            }
        }
        if (filteredElForms.length < 2)
            return;
        this.scrollTo(filteredElForms[1], isModal);
    }
    scrollTo(el, isModal = false) {
        if (el) {
            const headerOffset = 45;
            const elPos = el.getBoundingClientRect().top;
            if (isModal) {
                const offsetPos = elPos + this.screenWindow.scrollTop - headerOffset - 55;
                this.screenWindow.scrollTo({
                    top: offsetPos,
                    behavior: 'smooth',
                });
                return;
            }
            const offsetPos = elPos + window.scrollY - headerOffset;
            window.scrollTo({
                top: offsetPos,
                behavior: 'smooth',
            });
        }
    }
    filterFormEl(el) {
        const formEl = [];
        let formElIdx = 0;
        for (let i = 0; i < el.length; i++) {
            if (el[i].nodeName === "FORM")
                formElIdx = i;
        }
        for (let i = formElIdx; i < el.length; i++) {
            if (el[i].nodeName === "TR")
                continue;
            formEl.push(el[i]);
        }
        return formEl;
    }
}
ScrollToErrService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: ScrollToErrService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
ScrollToErrService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: ScrollToErrService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: ScrollToErrService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class UcTemplateService {
    constructor() {
        this._containerService = new ContainerService();
        this._callbackSubject = new BehaviorSubject(null);
        this.callback = this._callbackSubject.asObservable();
        this._baseUrl = location.origin || 'http://localhost:4200';
        this.listMapComponent = {};
    }
    set baseUrl(baseUrl) {
        this._baseUrl = baseUrl;
    }
    get baseUrl() {
        return this._baseUrl;
    }
    set environment(environment) {
        this._environment = environment;
    }
    get environment() {
        return this._environment;
    }
    set envConfig(envConfig) {
        this._envConfig = envConfig;
    }
    get envConfig() {
        return this._envConfig;
    }
    set urlConstant(urlConstant) {
        this._urlConstant = urlConstant;
    }
    get urlConstant() {
        return this._urlConstant;
    }
    set pathConstant(pathConstant) {
        this._pathConstant = pathConstant;
    }
    get pathConstant() {
        return this._pathConstant;
    }
    set listEnvironments(listEnvironments) {
        this._listEnvironments = listEnvironments;
    }
    set navConstant(navConstant) {
        this._navConstant = navConstant;
    }
    get navConstant() {
        return this._navConstant;
    }
    get listEnvironments() {
        return this._listEnvironments;
    }
    set moment(moment) {
        this._moment = moment;
    }
    get moment() {
        return this._moment;
    }
    get container() {
        return this._containerService;
    }
    get event() {
        return this._callbackSubject.value;
    }
    set module(module) {
        this._containerService.setModule(module);
    }
    set urlEnviPaging(url) {
        this._urlEnviPaging = url;
    }
    get urlEnviPaging() {
        return this._urlEnviPaging;
    }
    set apiQryPaging(url) {
        this._apiQryPaging = url;
    }
    get apiQryPaging() {
        return this._apiQryPaging;
    }
    set addrEnviUrl(url) {
        this._addrEnviUrl = url;
    }
    get addrEnviUrl() {
        return this._addrEnviUrl;
    }
    getCookie(cookieService, key) { }
    /** Publish event callback to observer */
    publish(ev) {
        this._callbackSubject.next(ev);
    }
    listener(pageId, event) { }
    subscribe() {
        this._subscription = this.callback.subscribe(next => this.listener(next === null || next === void 0 ? void 0 : next.pageId, next));
    }
    unsubscribe() {
        if (this._subscription) {
            this._subscription.unsubscribe();
        }
    }
    setListMapComponent(id, item) {
        this.listMapComponent[id] = new Map(item);
    }
}
UcTemplateService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: UcTemplateService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
UcTemplateService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: UcTemplateService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: UcTemplateService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

class CommonConstant {
}
// REGEX
CommonConstant.regexAPI = "\\/[v,V][1-9]\\d*(\\.[1-9]\\d*)*";
CommonConstant.regexEmail = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$";
// MODULE
CommonConstant.MODULE_FOU = "FOU";
CommonConstant.MODULE_LOS = "LOS";
CommonConstant.MODULE_LMS = "LMS";
CommonConstant.MODULE_AMS = "AMS";
CommonConstant.MODULE_CMS = "CMS";
// MODE
CommonConstant.MODE_ADD = "ADD";
CommonConstant.MODE_EDIT = "EDIT";
// APPLICATION DATA
CommonConstant.USER_ACCESS = "UserAccess";
CommonConstant.USER_NAME = "UserName";
CommonConstant.BUSINESS_DT = "BusinessDt";
CommonConstant.BUSINESS_DATE = "BusinessDate";
CommonConstant.BUSINESS_DATE_RAW = "BusinessDateRaw";
CommonConstant.CURRENT_USER_CONTEXT = "currentUserContext";
CommonConstant.PAGE_ACCESS = "PageAccess";
CommonConstant.TOKEN = "XSRF-TOKEN";
CommonConstant.VERSION = "Version";
CommonConstant.LAST_ACCESS_TIME = "LastAccessTime";
CommonConstant.MENU = "Menu";
CommonConstant.ReturnObj = 'ReturnObject';
CommonConstant.Status = 'Status';
CommonConstant.ENVIRONMENT_MODULE = 'EnvironmentModule';
CommonConstant.OFFICE_CODE = 'OfficeCode';
CommonConstant.ROLE_CODE = 'RoleCode';
//Status Code
CommonConstant.STATUS_CODE_USER_LOCKED = "002";
// NOTIFICATION METHOD
CommonConstant.NotificationMethodIntLink = "INT_LINK";
CommonConstant.NotificationMethodExtLink = "EXT_LINK";
// GENERAL SETTING CODE
CommonConstant.GSCodeDefLocalNationality = "DEF_LOCAL_NATIONALITY";
CommonConstant.GsCodePasswordRegex = "PASSWORD_REGEX";
CommonConstant.GSCodeIsShowCbxBorrow = "IS_SHOW_CBX_BORROW";
CommonConstant.GSCodeIsShowCbxPledge = "IS_SHOW_CBX_PLEDGE";
CommonConstant.GSCodeListLegalDocCantDuplicate = "LIST_LEGAL_DOC_CANNOT_DUPLICATE";
CommonConstant.GSCodeIsUseDigitalization = "IS_USE_DIGITALIZATION";
CommonConstant.GSCodeDefSeparatorDDLVerfQuest = "DEF_SEPARATOR_DDL_VERF_QUEST";
CommonConstant.GSCodeRegexDDLSeparator = "REGEX_DDL_SEPARATOR";
CommonConstant.GSCodeFilterAddr = "FILTER_ADDR";
CommonConstant.GSCodeMaxHierarchyLvlOffice = "MAX_HIERARCHY_LVL_OFFICE";
CommonConstant.GSCodeOwnershipMandatoryAddrType = "OWNERSHIP_MANDATORY_BY_ADDR_TYPE";
CommonConstant.GSCodeVATForPersonal = "VAT_FOR_PERSONAL";
//DMS
CommonConstant.DmsKey = "PHL7KV8RR0VG30K4";
CommonConstant.DmsIV = "0G7HFV96AVWXUQ51";
CommonConstant.DmsOverideSecurity = "OverideSecurity";
CommonConstant.DmsOverideUpload = "Upload";
CommonConstant.DmsOverideView = "View";
CommonConstant.DmsOverideUploadView = "Upload,View";
CommonConstant.DmsOverideViewDownload = "View,Download";
CommonConstant.DmsOverideUploadDownloadView = "Upload,Download,View";
CommonConstant.DmsNoCust = "No Customer";
CommonConstant.DmsNoApp = "No Application";
CommonConstant.DmsNoAgr = "No Agreement";
CommonConstant.DmsViewCodeCust = "ConfinsCust";
CommonConstant.DmsViewCodeApp = "ConfinsApp";
CommonConstant.DmsViewCodeAgr = "ConfinsAgr";
CommonConstant.DmsViewCodeMou = "ConfinsMou";
CommonConstant.DmsViewCodeLead = "ConfinsLead";
CommonConstant.DmsViewCodeSurvey = "Survey";
CommonConstant.DmsSurveyId = "Survey Id";
CommonConstant.DmsTaskId = "Task Id";
CommonConstant.AMT_LIMIT_APV_TYPE = "APV_LIMIT";

class AdInsConstant {
}
//Application Item
AdInsConstant.RestrictionBetween = "Between";
AdInsConstant.RestrictionLike = "Like";
AdInsConstant.RestrictionEq = "Eq";
AdInsConstant.RestrictionNeq = "NEQ";
AdInsConstant.RestrictionGt = "GT";
AdInsConstant.RestrictionGte = "GTE";
AdInsConstant.RestrictionLt = "LT";
AdInsConstant.RestrictionLte = "LTE";
AdInsConstant.RestrictionIn = "IN";
AdInsConstant.RestrictionNotIn = "NotIn";
AdInsConstant.RestrictionOr = "Or"; //pastikan ada 1 criteria sebelumnya
AdInsConstant.RestrictionOrNeq = "OrNeq"; //pastikan ada 1 criteria sebelumnya
AdInsConstant.RestrictionIsNull = "isnull";
AdInsConstant.RestrictionIsNotNull = "isnotnull";
AdInsConstant.RestrictionGTE = "GTE";
AdInsConstant.RestrictionLTE = "LTE";
AdInsConstant.showData = "10,50,100";
AdInsConstant.TimeoutSession = 6000000;
AdInsConstant.GetListProduct = "http://creator_websvr:7272/NEW_FINANCING/api/Catalog/getPopularViewByCriteria";
AdInsConstant.FormDefault = "dashboard/dash-board";
AdInsConstant.JoinTypeInner = "INNER";
AdInsConstant.PAGE_STATE_SINGLE = "single";
AdInsConstant.PAGE_STATE_MULTI = "multi";
AdInsConstant.PAGE_STATE_PREPAID = "prepaid";
AdInsConstant.FROM_PAGE_PAYMENT_RCV = "paymentreceive";
AdInsConstant.FROM_PAGE_CASHIER_TRX = "cashiertrx";
// Storage Watch Key
AdInsConstant.WatchRoleState = "RoleState";
AdInsConstant.WatchRoleLang = "lang";
AdInsConstant.SpinnerHeaders = new HttpHeaders({
    'IsLoading': "true"
});
AdInsConstant.SpinnerOptions = { headers: AdInsConstant.SpinnerHeaders };

class AdInsHelper {
    static ClearAllLog(cookieService) {
        const version = localStorage.getItem(CommonConstant.VERSION);
        localStorage.clear();
        localStorage.setItem('Version', version);
        cookieService.removeAll();
    }
    static ClearPageAccessLog(cookieService) {
        localStorage.removeItem('PageAccess');
        cookieService.remove('PageAccess');
    }
    static CheckSessionTimeout(environment, cookieService) {
        const today = new Date();
        const businessDtBefore = this.GetCookie(environment, cookieService, CommonConstant.LAST_ACCESS_TIME);
        const businessDtNow = formatDate(today, 'yyyy-MM-dd HH:mm:ss', 'en-US');
        if (businessDtBefore === undefined || businessDtBefore == null) {
            this.SetCookie(environment, cookieService, CommonConstant.LAST_ACCESS_TIME, businessDtNow);
        }
        else {
            const bsDtBefore = new Date(businessDtBefore);
            const tempDate = today.getTime() - bsDtBefore.getTime();
            if (tempDate > AdInsConstant.TimeoutSession) {
                const data = { status: '001', reason: 'Session Time Out' };
                AdInsHelper.ClearAllLog(cookieService);
                return '1';
            }
            this.SetCookie(environment, cookieService, CommonConstant.LAST_ACCESS_TIME, businessDtNow);
        }
        return '0';
    }
    static IsGrantAccess(environment, formPath) {
        const temp = AdInsHelper.GetLocalStorage(environment, CommonConstant.MENU);
        let objectMenu = [];
        objectMenu = JSON.parse(temp);
        if (objectMenu != null) {
            const exsisting = objectMenu['find'](x => x.path === formPath);
            if (exsisting === undefined) {
                return false;
            }
            else {
                return true;
            }
        }
    }
    static transformAmount(element) {
        let formattedAmount = '';
        if (element.target.value !== '') {
            if (parseFloat(element.target.value).toLocaleString('en') !== 'NaN') {
                formattedAmount = parseFloat(element.target.value).toLocaleString('en');
            }
            else {
                formattedAmount = '';
            }
        }
        return formattedAmount;
    }
    static transformToDecimal(element) {
        let parsedValue = 0;
        if (element.target.value !== '') {
            if (parseFloat(element.target.value.toString().replace(/,/g, '')).toString() !== 'NaN') {
                parsedValue = parseFloat(element.target.value.toString().replace(/,/g, ''));
            }
            else {
                return '';
            }
        }
        return parsedValue;
    }
    static Encrypt128CBC(plain, k, i) {
        const key = CryptoJS.enc.Utf8.parse(k);
        const iv = CryptoJS.enc.Utf8.parse(i);
        return CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(plain), key, {
            keySize: 128 / 8,
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });
    }
    static RedirectUrl(router, url, queryParams = {}, isSkipLocation = true) {
        // Ngebuat bisa jalanin Constructor dan NgOnInit lagi
        // router.routeReuseStrategy.shouldReuseRoute = () => {
        //     return false;
        // }
        // router.navigateByUrl(
        //   router.createUrlTree(
        //     [url.toString()], { queryParams: queryParams }
        //   ), { skipLocationChange: isSkipLocation }
        // );
        router.navigate(url, { queryParams: queryParams, skipLocationChange: true });
    }
    static SetLocalStorage(environment, key, value) {
        return localStorage.setItem(key, this.EncryptString(value, environment.ChipperKeyLocalStorage));
    }
    static GetLocalStorage(environment, key) {
        return this.DecryptString(localStorage.getItem(key), environment.ChipperKeyLocalStorage);
    }
    static SetCookie(environment, cookieService, key, value) {
        cookieService.put(key, this.EncryptString(value, environment.ChipperKeyCookie));
    }
    static GetCookie(environment, cookieService, key) {
        const value = cookieService.get(key);
        if (value === undefined || value.trim() === '') {
            return null;
        }
        return this.DecryptString(value, environment.ChipperKeyCookie);
    }
    static EncryptString(plaintext, chipperKey = '') {
        if (chipperKey === undefined || chipperKey.trim() === '') {
            return plaintext;
        }
        const chipperKeyArr = CryptoJS.enc.Utf8.parse(chipperKey);
        const iv = CryptoJS.lib.WordArray.create([0x00, 0x00, 0x00, 0x00]);
        const encrypted = CryptoJS.AES.encrypt(plaintext, chipperKeyArr, { iv: iv });
        return CryptoJS.enc.Base64.stringify(encrypted.ciphertext);
    }
    static DecryptString(chipperText, chipperKey) {
        if (chipperKey === undefined || chipperKey.trim() === '' ||
            chipperText === undefined || chipperText.trim() === '') {
            return chipperText;
        }
        const chipperKeyArr = CryptoJS.enc.Utf8.parse(chipperKey);
        const iv = CryptoJS.lib.WordArray.create([0x00, 0x00, 0x00, 0x00]);
        const decrypted = CryptoJS.AES.decrypt(chipperText, chipperKeyArr, { iv: iv });
        return decrypted.toString(CryptoJS.enc.Utf8);
    }
    static GetUserAccess(environment, cookieService) {
        const userAccess = AdInsHelper.GetCookie(environment, cookieService, CommonConstant.USER_ACCESS);
        if (!userAccess) {
            return null;
        }
        return JSON.parse(userAccess);
    }
}

class CriteriaObj {
    constructor() {
        this.low = 0;
        this.high = 0;
        this.DataType = 'Text';
    }
}

class IntegrationObj {
    constructor() {
        this.baseUrl = "";
        this.apiPath = "";
        this.requestObj = new Object();
        this.leftColumnToJoin = "";
        this.rightColumnToJoin = "";
        this.joinType = UcPagingConstant.JoinTypeInner;
    }
}
class UcPagingConstant {
}
UcPagingConstant.JoinTypeInner = "INNER";
UcPagingConstant.JoinTypeLeft = "LEFT";

class PathConstant {
}
// Notes: data yang di CombinePath itu arti ny ada lebih dari 1 Const dan ada /
// layout-routes
//#region layout-routes
PathConstant.LR_DASHBOARD = "Dashboard";
PathConstant.LR_FORMS = "forms";
PathConstant.LR_COMPNT = "components";
PathConstant.LR_NOTIF = "Notification";
PathConstant.LR_PAGES = "Pages";
PathConstant.LR_OFFICE = "Office";
PathConstant.LR_OFFICE_BANK_ACC = "OfficeBankAcc";
PathConstant.LR_EMP = "Employee";
PathConstant.LR_ORG = "Organization";
PathConstant.LR_CUST = "Customer";
PathConstant.LR_SYSTEM_SETTING = "SystemSetting";
PathConstant.LR_COY = "company";
PathConstant.LR_COMMON_SETTING = "CommonSetting";
PathConstant.LR_UPLOAD = "Upload";
PathConstant.LR_ASSET = "Asset";
PathConstant.LR_VENDOR = "Vendor";
PathConstant.LR_VERIF = "Verification";
PathConstant.LR_APPRV_SCRN = "ApprovalScreen";
PathConstant.LR_ERROR = "Error";
PathConstant.LR_SRVY = "Survey";
PathConstant.LR_INTEGRATION = "Integration";
PathConstant.LR_DOC_MNGMNT = "DocumentManagement";
PathConstant.LR_JOURNAL = "journal";
PathConstant.LR_FEE = "Fee";
PathConstant.LR_LICENSE = "License";
PathConstant.LR_SYS_USER = "SystemUser";
//#endregion
//#region content-routes
PathConstant.CR_PAGES = "Pages";
PathConstant.CR_VIEW = "View";
PathConstant.CR_DOC_MNGMNT_VIEW = "DocumentManagementView";
//#endregion
//#region content-pages
PathConstant.LOGIN = "Login";
PathConstant.CONTENT = "Content";
PathConstant.REQ_PASSWORD = "RequestPassword";
PathConstant.RESET_PASSWORD = "ResetPassword/:code";
//#endregion
//#region Common-Path
PathConstant.VIEW = "View";
PathConstant.PAGES = "pages";
PathConstant.PAGING = "Paging";
PathConstant.MAIN = "Main";
PathConstant.ADD = "Add";
PathConstant.EDIT = "Edit";
PathConstant.ADD_EDIT = "AddEdit";
PathConstant.DETAIL = "Detail";
PathConstant.ADD_DETAIL = PathConstant.ADD + "/" + PathConstant.DETAIL;
PathConstant.APPRV = "Approval";
PathConstant.INQUIRY = "Inquiry";
PathConstant.CANCEL = "Cancel";
PathConstant.TYPE = "Type";
PathConstant.PERSONAL = "Personal";
PathConstant.COY = "Company";
PathConstant.MEMBER = "Member";
PathConstant.RTN_PAGING = "ReturnPaging";
PathConstant.GROUP = "Group";
//#endregion
//#region Dashboard-Module
PathConstant.DASHBOARD = "Dash-Board";
PathConstant.DASHEMPTY = "Dash-Empty";
PathConstant.CHANGE_PASSWORD = "ChangePassword";

class NavigationConstant {
}
NavigationConstant.DASHEMPTY = "/" + PathConstant.LR_DASHBOARD + "/" + PathConstant.DASHEMPTY; //'/Dashboard/Dash-Empty'
NavigationConstant.DASHBOARD = "/" + PathConstant.LR_DASHBOARD + "/" + PathConstant.DASHBOARD; //'/Dashboard/Dash-Board'
NavigationConstant.BACK_TO_PAGING = '..' + "/" + PathConstant.PAGING; //'../Paging'
NavigationConstant.BACK_TO_PAGING2 = '..' + "/" + '..' + "/" + PathConstant.PAGING; //'../../Paging'
NavigationConstant.BACK_TO_DETAIL = '..' + "/" + PathConstant.DETAIL; //'../Detail'
NavigationConstant.BACK_TO_ADD_EDIT = '..' + "/" + PathConstant.ADD_EDIT; //'../AddEdit'
NavigationConstant.BACK_TO_EDIT = '..' + "/" + PathConstant.EDIT; //'../Edit'
NavigationConstant.PAGES_CHANGE_PASSWORD = "/" + PathConstant.LR_PAGES + "/" + PathConstant.CHANGE_PASSWORD; //'/Pages/ChangePassword'
NavigationConstant.PAGES_LOGIN = "/" + PathConstant.LR_PAGES + "/" + PathConstant.LOGIN; //'/Pages/Login'
NavigationConstant.PAGES_REQ_PASSWORD = "/" + PathConstant.LR_PAGES + "/" + PathConstant.REQ_PASSWORD; //'/Pages/RequestPassword'
NavigationConstant.PAGES_CONTENT = "/" + PathConstant.LR_PAGES + "/" + PathConstant.CONTENT; //'/Pages/Content'
NavigationConstant.ERROR = "/" + PathConstant.LR_ERROR; //'/Error'
NavigationConstant.NOTIF = "/" + PathConstant.LR_NOTIF; //'/Notification'

class UcPagingObj {
    constructor(service) {
        this.service = service;
        this._url = "";
        this.title = "";
        this.enviromentUrl = this.service.environment.isCore ? this.service.envConfig.FoundationR3Url + '/v2' : this.service.envConfig.FoundationR3Url + '/v1';
        this.apiQryPaging = this.service.apiQryPaging !== undefined ? this.service.apiQryPaging : this.service.urlConstant.GetPagingObjectBySQL;
        this.deleteUrl = "";
        this.pagingJson = "";
        this.arrCritObj = null;
        this.addCritInput = new Array();
        this.ddlEnvironments = new Array();
        this.listEnvironments = this.service.listEnvironments;
        this.whereValue = new Array();
        this.fromValue = new Array();
        this.isHideSearch = false;
        this.delay = 0;
        this.isSearched = false;
        this.navigationConst = NavigationConstant;
        this.isJoinExAPI = false;
        this.isGetAllData = false;
        this.integrationObj = new IntegrationObj();
        this.dicts = {};
        this.useSafeUrl = false;
    }
}
class EnviObj$5 {
    constructor() {
        this.name = "";
        this.environment = "";
    }
}
class FromValueObj$1 {
    constructor() {
        this.property = "";
    }
}
class WhereValueObj$2 {
    constructor() {
        this.property = "";
    }
}
class EnvisObj$6 {
    constructor() {
        this.environment = "";
        this.url = "";
    }
}

class InputLookupObj {
    constructor(service) {
        this.service = service;
        this.urlJson = "./assets/uclookup/zipcode/lookupZipcode.json";
        this.urlQryPaging = this.service.apiQryPaging !== undefined ? this.service.apiQryPaging : this.service.urlConstant.GetPagingObjectBySQL;
        this.urlEnviPaging = (this.service.urlEnviPaging !== undefined ? this.service.urlEnviPaging : this.service.envConfig.FoundationR3Url) + "/v1";
        this.jsonSelect = "";
        this.idSelect = "";
        this.nameSelect = "";
        this.addCritInput = null;
        this.ddlEnvironments = new Array();
        this.listEnvironments = this.service.listEnvironments;
        this.isRequired = true;
        this.isReadonly = true;
        this.isReady = false;
        this.title = "";
        this.isDisable = false;
        this.isClear = false;
        this.IsUpdate = false;
        this.placeholder = "";
    }
}
class EnviObj$4 {
    constructor() {
        this.name = "";
        this.environment = "";
    }
}
class EnvisObj$5 {
    constructor() {
        this.environment = "";
        this.url = "";
    }
}

class UcAddressObj {
    constructor() {
        this.Addr = "";
        this.AreaCode4 = "";
        this.AreaCode3 = "";
        this.AreaCode2 = "";
        this.AreaCode1 = "";
        this.City = "";
        this.PhnArea1 = "";
        this.Phn1 = "";
        this.PhnExt1 = "";
        this.PhnArea2 = "";
        this.Phn2 = "";
        this.PhnExt2 = "";
        this.PhnArea3 = "";
        this.Phn3 = "";
        this.PhnExt3 = "";
        this.FaxArea = "";
        this.Fax = "";
        this.MrHouseOwnershipCode = "";
        this.SubZipcode = "";
        this.StayLength = 0;
        this.RowVersion = "";
        this.StaySince = "";
    }
}

class InputFieldObj {
}

class InputAddressObj {
    constructor(service) {
        this.service = service;
        this.default = new UcAddressObj();
        this.title = "Address Information";
        this.inputField = new InputFieldObj();
        this.showAllPhn = true;
        this.showPhn1 = true;
        this.showPhn2 = true;
        this.showPhn3 = true;
        this.requiredPhn1 = false;
        this.requiredPhn2 = false;
        this.requiredPhn3 = false;
        this.requiredPhnExt1 = false;
        this.requiredPhnExt2 = false;
        this.requiredPhnExt3 = false;
        this.showFax = true;
        this.showOwnership = false;
        this.requiredOwnership = false;
        this.showSubsection = true;
        this.showStayLength = false;
        this.isRequired = true;
        this.environmentUrl = (this.service.addrEnviUrl !== undefined ? this.service.addrEnviUrl : this.service.envConfig.FoundationR3Url)
            + "/v1";
        this.isReadonly = false;
        this.isAddrUppercase = true;
        this.useStaySince = false;
        this.readonlyPhn1 = false;
        this.readonlyPhnExt1 = false;
        this.readonlyPhn2 = false;
        this.readonlyPhnExt2 = false;
        this.readonlyPhn3 = false;
        this.readonlyPhnExt3 = false;
        this.environment = service.environment;
        this.useFourColl = false;
        this.ownershipCode = '';
        this.isAddrReady = false;
    }
}

class UcViewGenericObj {
    // END EXPERIMENTAL
    constructor(service) {
        this.service = service;
        this.IsCard = false;
        // EXPERIMENTAL for BaseView API
        this.Experimental = false;
        this.viewInput = "";
        this.viewEnvironment = this.service.envConfig.FoundationR3Url + '/v1';
        this.ddlEnvironments = new Array();
        this.listEnvironments = this.service.listEnvironments;
        this.whereValue = new Array();
        this.navigationConst = this.service.navConstant || NavigationConstant;
        this.dicts = {};
        this.IsCard = false;
        this.Experimental = false;
        this.environment = {};
    }
}
class EnviObj$3 {
    constructor() {
        this.name = "";
        this.environment = "";
    }
}
class WhereValueObj$1 {
    constructor() {
        this.property = "";
    }
}
class EnvisObj$4 {
    constructor() {
        this.environment = "";
        this.url = "";
    }
}

class InputReportObj {
    constructor(service) {
        this.service = service;
        this.JsonPath = '';
        this.ModuleCode = this.service.environment.Module;
        this.EnvironmentUrl = this.service.envConfig.FoundationR3Url + '/v1';
        this.ApiReportPath = '/Report/GenerateReportR3';
        this.ddlEnvironments = new Array();
        this.listEnvironments = this.service.listEnvironments;
        this.useSubReport = false;
    }
}
class EnviObj$2 {
    constructor() {
        this.name = '',
            this.environment = '';
    }
}
class EnvisObj$3 {
    constructor() {
        this.environment = '';
        this.url = '';
    }
}

class UcUploadObj {
    constructor(service) {
        this.service = service;
        this.title = "";
        this.subsectionId = "UcUploadFile";
        this.formatsAllowed = ".xls, .xlsx, .txt, .TXT";
        this.UploadTypeCode = "";
        this.ErrorDownloadUrl = "";
        this.TemplateUrl = this.service.urlConstant.DownloadTemplate;
        this.TemplateName = "";
        this.FileErrorName = "";
        this.environmentUrl = this.service.environment.isCore ? this.service.envConfig.FoundationR3Url + '/v2' : this.service.envConfig.FoundationR3Url + '/v1';
        this.apiQryPaging = this.service.apiQryPaging !== undefined ? this.service.apiQryPaging : this.service.urlConstant.GetPagingObjectBySQL;
        this.pagingJson = "";
        this.SheetName = "";
        this.url = this.service.urlConstant.UploadFileV2;
        this.hideProgressBar = false;
        this.hideResetBtn = false;
        this.hideSelectBtn = false;
        this.maxSize = 20;
        this.multiple = false;
        this.headers = {};
        this.resetUpload = false;
        this.isDownloadTmplt = true;
        this.ddlEnvironments = new Array();
        this.listEnvironments = this.service.listEnvironments;
        this.additionalPayload = {};
        this.downloadTmpltOpt = [
            {
                key: "XLSX",
                value: "Excel"
            },
            {
                key: "TXT",
                value: "Text"
            }
        ];
    }
}
class EnviObj$1 {
    constructor() {
        this.name = "";
        this.environment = "";
    }
}
class EnvisObj$2 {
    constructor() {
        this.environment = "";
        this.url = "";
    }
}
class ReplaceTexts {
}

class UcInputRFAObj {
    constructor(service, http, cookieService) {
        this.service = service;
        this.http = http;
        this.cookieService = cookieService;
        // const context = JSON.parse(AdInsHelper.GetCookie(this.service, this.cookieService, CommonConstant.USER_ACCESS));
        const context = JSON.parse(this.service.getCookie(this.cookieService, CommonConstant.USER_ACCESS));
        this.RequestedBy = context[CommonConstant.USER_NAME];
        this.OfficeCode = context[CommonConstant.OFFICE_CODE];
        this.OfficeCodes = [];
        this.ApvTypecodes = [];
        this.ImmutableApvTypecodes = [];
        this.EnvUrl = this.service.envConfig.FoundationR3Url;
        this.PathUrlGetSchemeBySchemeCode = this.service.urlConstant.GetSchemesBySchemeCode;
        this.PathUrlGetCategoryByCategoryCode = this.service.urlConstant.GetRefSingleCategoryByCategoryCode;
        this.PathUrlGetAdtQuestion = this.service.urlConstant.GetRefAdtQuestion;
        this.PathUrlGetPossibleMemberAndAttributeExType = this.service.urlConstant.GetPossibleMemberAndAttributeExType;
        this.PathUrlGetApprovalReturnHistory = this.service.urlConstant.GetApprovalReturnHistory;
        this.PathUrlCreateNewRFA = this.service.urlConstant.CreateNewRFA;
        this.PathUrlCreateJumpRFA = this.service.urlConstant.CreateJumpRFA;
        this.CategoryCode = '';
        this.SchemeCode = '';
        this.TrxNo = '';
        this.Reason = [];
        this.IsHideTrxNo = false;
        this.dicts = {};
        this.requiredNotes = true;
        this.defaultApprover = '';
        this.IsHideNewRfa = false;
    }
    setApprovalAmt(apvAmt) {
        return __awaiter(this, void 0, void 0, function* () {
            this.ApvTypecodes = [{
                    'TypeCode': CommonConstant.AMT_LIMIT_APV_TYPE,
                    'Attributes': [{
                            'AttributeName': 'Approval Amount',
                            'AttributeValue': apvAmt
                        }],
                }];
        });
    }
    setListReason(refReasonTypeCode) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.http.post(this.service.urlConstant.GetListActiveRefReason, { RefReasonTypeCode: refReasonTypeCode }).toPromise().then((response) => {
                this.Reason = response['ReturnObject'];
            });
        });
    }
}

class UcInputApprovalObj {
    constructor(service) {
        var _a;
        this.service = service;
        this.TaskId = 0;
        this.EnvUrl = (_a = this.service.envConfig) === null || _a === void 0 ? void 0 : _a.FoundationR3Url;
        this.PathUrlGetLevelVoting = this.service.urlConstant.GetLevelVoting;
        this.PathUrlGetPossibleResult = this.service.urlConstant.GetPossibleResult;
        this.PathUrlGetPossibleResultMulti = this.service.urlConstant.GetPossibleResultMulti;
        this.PathUrlSubmitApproval = this.service.urlConstant.SubmitApproval;
        this.PathUrlGetNextNodeMember = this.service.urlConstant.GetNextNodeMember;
        this.PathUrlGetReasonActive = this.service.urlConstant.GetRefReasonActive;
        this.PathUrlGetChangeFinalLevel = this.service.urlConstant.GetCanChangeMinFinalLevel;
        this.PathUrlReturnToLevel = this.service.urlConstant.ReturnToLevel;
        this.PathUrlContinueToLevel = this.service.urlConstant.ContinueToLevel;
        this.TrxNo = "";
        this.RequestId = 0;
        this.PathUrlGetHistory = this.service.urlConstant.GetTaskHistory;
        this.requiredNotes = true;
        this.showApvHistory = true;
        this.notesReqWhen = [];
        this.isMultiApv = false;
        this.dicts = {};
        this.apvGridObj = {};
        this.listApproveProp = "";
        this.IsReturnToRequestorOnly = false;
    }
}

class UcInputApprovalGeneralInfoObj {
    constructor(service) {
        this.service = service;
        this.TaskId = 0;
        this.EnvUrl = this.service.envConfig.FoundationR3Url + "/v1";
        this.PathUrl = "/Approval/GetSingleTaskInfo";
    }
}

class UcInputApprovalHistoryObj {
    constructor(service) {
        this.service = service;
        this.RequestId = 0;
        this.EnvUrl = this.service.envConfig.FoundationR3Url + "/v1";
        this.PathUrl = "/Approval/GetTaskHistory";
    }
}

class InputFormArrayObj {
    constructor(service) {
        this.service = service;
        this.title = '';
        this.formId = '';
        this.formJson = '';
        this.CustomObjName = '';
        this.IsSubsection = true;
        this.IsVertical = false;
        this.IsModeAdd = true;
        this.ColumnObject = {};
        this.listEnvironments = {};
        this.isReady = false;
        this.environment = this.service.environment;
        this.dicts = {};
        this.conditionalDel = { condition: [] };
        for (const env of this.service.listEnvironments) {
            this.listEnvironments[env.environment] = env.url;
        }
    }
}

class UcTempPagingObj {
    constructor(service) {
        this.service = service;
        this.urlJson = "";
        this.enviromentUrl = this.service.environment.isCore ? this.service.envConfig.FoundationR3Url + "/v2.1" :
            this.service.envConfig.FoundationR3Url + "/v1";
        this.apiQryPaging = this.service.urlConstant.GetPagingObjectBySQL;
        this.pagingJson = "";
        this.isReady = false;
        this.addCritInput = new Array();
        this.ddlEnvironments = new Array();
        this.listEnvironments = this.service.listEnvironments;
        this.whereValue = new Array();
        this.fromValue = new Array();
        this.navigationConst = this.service.navConstant;
        this.dicts = {};
        this.isJoinExAPI = false;
        this.integrationObj = new IntegrationObj();
        this.useSafeUrl = false;
    }
}
class EnviObj {
    constructor() {
        this.name = "";
        this.environment = "";
    }
}
class WhereValueObj {
    constructor() {
        this.property = "";
    }
}
class FromValueObj {
    constructor() {
        this.property = "";
    }
}
class EnvisObj$1 {
    constructor() {
        this.environment = "";
        this.url = "";
    }
}

class UcInputFormObj {
    constructor(service) {
        this.service = service;
        this.title = "";
        this.formId = "";
        this.formJson = "";
        this.IsSubsection = true;
        this.IsCollapsed = false;
        this.IsVertical = false;
        this.IsModeAdd = true;
        this.FormEditObject = {};
        this.environment = service.environment;
        this.listEnvironments = {};
        this.navigationConst = service.navConstant;
        this.dicts = {};
        this.onloadAct = [];
        this.initAction = [];
        this.pageName = 'default';
        for (const env of this.service.listEnvironments) {
            this.listEnvironments[env.environment] = env.url;
        }
    }
}

class InputGridviewObj {
    constructor(service) {
        this.service = service;
        this.id = '';
        this.isReady = false;
        this.isSubsection = false;
        this.title = "";
        this.dicts = {};
        this.navigationConst = service.navConstant;
        this.serviceObj = null;
        this.isFromApi = false;
        this.listBtn = [];
        this.usePagination = true;
        this.useSafeUrl = false;
    }
}

var ActionType;
(function (ActionType) {
    ActionType["Link"] = "link";
    ActionType["Http"] = "http";
    ActionType["Function"] = "function";
    ActionType["Modal"] = "modal";
    ActionType["Toaster"] = "toaster";
    ActionType["Switch"] = "switch";
    ActionType["Callback"] = "callback";
    ActionType["Confirm"] = "confirm";
    ActionType["Reload"] = "reload";
    ActionType["LocalStorage"] = "localStorage";
})(ActionType || (ActionType = {}));

// import { InputLookupObj } from "./uc-lookup-obj.model";
class RefAttrSettingObj {
    constructor(service) {
        this.service = service;
        this.IsVertical = false;
        this.IsDisable = false;
        this.IsShowBtnRefresh = true;
        this.UrlGetLookupExistingValue = "";
        this.UrlGetRuleForAttrContent = "";
        this.UrlGetListAttr = "";
        this.ReqGetListAttrObj = {};
        this.Title = "Ref Attribute Generate";
        this.IsAdd = true;
        this.EditObj = [];
        // this.urlQryPaging = "";
        // this.urlEnviPaging = "";
        // this.listEnvironments = new Array<EnvisObj>();
        // this.LookupJson = "./assets/uclookup/lookupRefMaster.json";
        // this.DefaultSettingUcLookupObj = new InputLookupObj(service);
    }
}
class EnvisObj {
    constructor() {
        this.environment = "";
        this.url = "";
    }
}

class FileUploadObj {
    constructor() {
        this.label = 'File to Upload';
        this.propName = '';
        this.docuploadType = '';
        this.limitFileSize = 1024;
        this.allowedExt = 'pdf';
        this.isRequired = false;
        this.isSubsection = false;
        this.subsectionTitle = '';
        this.metadata = [];
    }
}
class Metadata$1 {
}

class ViewFileUploadObj {
    constructor() {
        this.isSubsection = false;
        this.subsectionTitle = '';
        this.metadata = [];
        this.canDelete = false;
        this.deletePath = '';
        this.hideWhenEmpty = false;
    }
}
class Metadata {
}

var InputType;
(function (InputType) {
    InputType["BLANK"] = "BLANK";
    InputType["TEXT"] = "TEXT";
    InputType["TEXTAREA"] = "TEXTAREA";
    InputType["DATE"] = "DATE";
    InputType["DATETIME"] = "DATETIME";
    InputType["TIME"] = "TIME";
    InputType["BOOL"] = "BOOL";
    InputType["NUMERIC"] = "NUMERIC";
    InputType["CURRENCY"] = "CURRENCY";
    InputType["PERCENT"] = "PERCENT";
    InputType["LOOKUP"] = "LOOKUP";
    InputType["DROPDOWNLIST"] = "DDL";
    InputType["LABEL"] = "LABEL";
    InputType["ADDRESS"] = "ADDRESS";
})(InputType || (InputType = {}));
// nanti di samakan dengan ucShow error pattern.
var ValidatorPattern;
(function (ValidatorPattern) {
    ValidatorPattern["CHARACTER_ONLY"] = "^[a-zA-Z ]*$";
    ValidatorPattern["CHARACTER_ONLY_REQUIRED"] = "^[a-zA-Z ]*$";
    ValidatorPattern["CHARACTER_ONLY_NON_WHITESPACE"] = "^[a-zA-Z]*$";
    ValidatorPattern["CHARACTER_ONLY_NON_WHITESPACE_REQUIRED"] = "^[a-zA-Z]+$";
    ValidatorPattern["NUMBER_ONLY"] = "^[0-9]*$";
    ValidatorPattern["NUMBER_ONLY_REQUIRED"] = "^[0-9]+$";
    ValidatorPattern["NUMBER_ONLY_DECIMAL"] = "^[0-9]+([,.][0-9]+)?$";
    ValidatorPattern["EMAIL_SMALL_CASE"] = "^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$";
    ValidatorPattern["EMAIL_ALL_CASE"] = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,4}$";
    ValidatorPattern["MULTIPLE_EMAIL_ALL_CASE"] = "^(([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)(s*;\\s*|\\s*$))+$";
    ValidatorPattern["VAT_INVOICE"] = "^[A-Za-z0-9]{3}.[A-Za-z0-9]{3}.[A-Za-z0-9]{2}.[A-Za-z0-9]{8}$";
    ValidatorPattern["VAT_INVOICE_NUMBER_ONLY"] = "^[0-9]{2}.[0-9]{3}.[0-9]{3}.[0-9]{1}-[0-9]{3}.[0-9]{3}$";
})(ValidatorPattern || (ValidatorPattern = {}));
var CallbackKeys;
(function (CallbackKeys) {
    CallbackKeys["CB_UPDATE_CREATE_APV"] = "cbUpdateCreateApvScheme";
})(CallbackKeys || (CallbackKeys = {}));

class NGXToastrService {
    constructor(toastr) {
        this.toastr = toastr;
    }
    // Success Type
    typeSuccess() {
        this.toastr.success('You are awesome!', 'Success!');
    }
    // Success Type
    typeInfo() {
        this.toastr.info('We do have the Kapua suite available.', 'Turtle Bay Resort');
    }
    // Success Type
    typeWarning() {
        this.toastr.warning('My name is Inigo Montoya. You killed my father, prepare to die!');
    }
    // Success Type
    typeError() {
        this.toastr.error('there is an internal error', 'Failed!');
    }
    // Custom Type
    typeCustom() {
        this.toastr.success('<span style="color: red">Message in red.</span>', null, { enableHtml: true });
    }
    //Progress bar
    progressBar() {
        this.toastr.info('We do have the Kapua suite available.', 'Turtle Bay Resort', { "progressBar": true });
    }
    // Timeout
    timeout() {
        this.toastr.error('I do not think that word means what you think it means.', 'Timeout!', { "timeOut": 5000 });
    }
    //Dismiss toastr on Click
    dismissToastOnClick() {
        this.toastr.info('We do have the Kapua suite available.', 'Turtle Bay Resort', { "tapToDismiss": true });
    }
    // Remove current toasts using animation
    clearToast() {
        this.toastr.clear();
    }
    // Show close button
    showCloseButton() {
        this.toastr.info('Have fun storming the castle!', 'Miracle Max Says', { closeButton: true });
    }
    // Enable  HTML
    enableHtml() {
        this.toastr.info('<i>Have fun <b>storming</b> the castle!</i>', 'Miracle Max Says', { enableHtml: true });
    }
    // Title Class
    titleClass() {
        this.toastr.info('Have fun storming the castle!', 'Miracle Max Says', { titleClass: 'h3' });
    }
    // Message Class
    messageClass() {
        this.toastr.info('Have fun storming the castle!', 'Miracle Max Says', { messageClass: 'text-uppercase' });
    }
    errorMessage(msg) {
        this.toastr.error(msg);
    }
    typeSave(msg) {
        this.toastr.success(msg);
    }
    typeErrorCustom(msg) {
        this.toastr.error(msg);
    }
    successMessage(msg) {
        this.toastr.success(msg, 'Success!', { enableHtml: true, tapToDismiss: false, timeOut: 10000, extendedTimeOut: 10000, closeButton: true });
    }
    warningMessage(msg) {
        this.toastr.warning(msg, "", { enableHtml: true, tapToDismiss: false, timeOut: 10000, extendedTimeOut: 10000, closeButton: true });
    }
    infoMessage(msg) {
        this.toastr.info(msg, "", { enableHtml: true, tapToDismiss: false, timeOut: 10000, extendedTimeOut: 10000, closeButton: true });
    }
    errorAPI(status, reason) {
        this.toastr.error(reason, 'Status: ' + status, { "tapToDismiss": true });
    }
}
NGXToastrService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: NGXToastrService, deps: [{ token: i1.ToastrService }], target: i0.ɵɵFactoryTarget.Injectable });
NGXToastrService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: NGXToastrService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: NGXToastrService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: i1.ToastrService }]; } });

class LocalStorageService {
    constructor() {
        this.Storage = {};
    }
    remove(key) {
        delete this.Storage[key];
    }
    clear() {
        this.Storage = {};
    }
    create(key, data) {
        this.Storage[key] = data;
    }
    createOrUpdate(key, data, index = 0, before) {
        const keys = key.split('.');
        const record = this.Storage[keys[0]];
        if (!record) {
            this.create(key, data);
            return;
        }
        // Get Row Object from record
        const row = record[keys[1]];
        // Check is data available?
        if (!row) {
            record[keys[1]] = data;
            this.create(keys[0], record);
            return;
        }
        // Check is data type array?
        if (Array.isArray(row)) {
            let idx = index;
            if (before) {
                const compare = (obj1, obj2) => {
                    return JSON.stringify(obj1) === JSON.stringify(obj2);
                };
                idx = row.findIndex(obj => compare(obj, before));
            }
            else {
                idx = row.length === index ? index : row.length;
            }
            row[idx] = data;
            record[keys[1]] = row;
            this.create(keys[0], record);
        }
        else {
            record[keys[1]] = data;
            this.create(keys[0], record);
        }
        console.log(key, this.find(keys[0]));
    }
    find(key) {
        if (!key) {
            return;
        }
        const keys = key.split('.');
        if (keys.length === 1) {
            return this.Storage[key];
        }
        const record = this.Storage[keys[0]];
        if (!record) {
            return null;
        }
        return record[keys[1]];
    }
    get size() {
        return Object.keys(this.Storage).length || 0;
    }
}
LocalStorageService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: LocalStorageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
LocalStorageService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: LocalStorageService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: LocalStorageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

class UcTemplateComponent {
    constructor(fb, router, activeRoute, http, cookieService, location, AddressService, cdr, 
    // tslint:disable-next-line:max-line-length
    LookupService, LookupFAService, resolver, injector, appRef, toastr, FormSettingService, templateService, listTempService, executor, dialog, refData, LocalStorage, attrService, ngxRouter, scrollToErrFormSvc, logger) {
        this.fb = fb;
        this.router = router;
        this.activeRoute = activeRoute;
        this.http = http;
        this.cookieService = cookieService;
        this.location = location;
        this.AddressService = AddressService;
        this.cdr = cdr;
        this.LookupService = LookupService;
        this.LookupFAService = LookupFAService;
        this.resolver = resolver;
        this.injector = injector;
        this.appRef = appRef;
        this.toastr = toastr;
        this.FormSettingService = FormSettingService;
        this.templateService = templateService;
        this.listTempService = listTempService;
        this.executor = executor;
        this.dialog = dialog;
        this.refData = refData;
        this.LocalStorage = LocalStorage;
        this.attrService = attrService;
        this.ngxRouter = ngxRouter;
        this.scrollToErrFormSvc = scrollToErrFormSvc;
        this.logger = logger;
        this.data = new EventEmitter();
        this.Form = this.fb.group({});
        this.isDialog = false;
        this.isStepper = false;
        this.container = [];
        this.params = {};
        this.selfCustom = false;
        this.selectedIdxChange = new EventEmitter();
        this.parentDicts = {};
        this.notify = new EventEmitter();
        this.notifyUpdateTableFooter = new EventEmitter();
        this.notifyUpdateTable = new EventEmitter();
        this.onBtnClick = new EventEmitter();
        this.next = new EventEmitter();
        this.cbLookupManual = new EventEmitter();
        this.dictionary = new EventEmitter();
        this.onFormCreated = new EventEmitter();
        this.onRefresh = new EventEmitter();
        this.notifyUpdateDict = new EventEmitter();
        this.notifyUpdateViewFileUpload = new EventEmitter();
        this.notifyOnReadyForm = new EventEmitter();
        this.onDismissModal = new EventEmitter();
        this.callbackAction = new EventEmitter();
        this.listMapComponent = new Map();
        this.listMapTypeToIdComponent = new Map();
        this.componentTypes = [];
        this.listIds = [];
        this.queryParams = {};
        this.hideSubmitButton = false;
        this.hideCancelButton = false;
        this.overrideSubmitBtnText = "Submit";
        this.isModeAdd = false;
        this.isHumanApproval = true;
        this.cacheable = false;
        this.pageCache = {};
        this.ApvReady = false;
        this.ApvRfaReady = false;
        this.IsAdd = true;
        this.topBtns = [];
        this.botBtns = [];
        this.initialValue = {};
        this.formOnLoadAct = {};
        this.customClass = {};
        this.lookupMap = {};
        this.listIsVisible = {};
        this.selectedTabIndex = 0;
        this.AppStep = {};
        this.StepIndex = 1;
        this.copyNotify = undefined;
        this.dicts = {};
        this.TabList = {};
        // public notifyUpdateTable: EventEmitter<any> = new EventEmitter<any>();
        this.notifyUpdateFormArray = new EventEmitter();
        // public notifyUpdateDict: EventEmitter<any> = new EventEmitter<any>();
        this.notifyUpdateView = new EventEmitter();
        this.onDestroyForm = new EventEmitter();
        this.IsReady = false;
        this.formSubject = new BehaviorSubject(null);
        this.formObserver = this.formSubject.asObservable();
        this.environment = this.templateService.environment;
        this.controlObservable = {};
        this.envi = this.templateService.envConfig;
    }
    ngOnDestroy() {
        var _a, _b;
        //Check is pageName equal?
        if (this.cacheable && ((_a = this.templateObj) === null || _a === void 0 ? void 0 : _a.persistData)) {
            const cacheForm = this.Form.getRawValue();
            this.pageCache[(_b = this.templateObj) === null || _b === void 0 ? void 0 : _b.persistPropName] = {
                queryParams: this.queryParams
            };
            // should be configurable for next iteration
            if (this.dicts["ApproverUsername"]) {
                cacheForm["dicts"] = {
                    ApproverUsername: this.dicts["ApproverUsername"]
                };
            }
            localStorage.setItem('pageCache', JSON.stringify(this.pageCache));
            this.storeLocalStorage(cacheForm);
        }
        if (this.formValueChangesSubscription) {
            this.formValueChangesSubscription.unsubscribe();
        }
        if (this.formSubscription) {
            this.formSubscription.unsubscribe();
        }
        if (this.callbackSub) {
            this.callbackSub.unsubscribe();
        }
        if (this.navigationSubscription) {
            this.navigationSubscription.unsubscribe();
        }
        if (this.copyNotify) {
            this.copyNotify.unsubscribe();
        }
        delete this.templateService.listMapComponent[this.templateObj.id];
        // Notify to UcForm Component to clear form controls
        this.onDestroyForm.emit(true);
    }
    createInitialFormValue() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            // Check data from persistence service
            if ((_a = this.templateObj) === null || _a === void 0 ? void 0 : _a.persistData) {
                const draft = this.LocalStorage.find(this.templateObj.persistPropName);
                if (draft && this.IsAdd) {
                    // Set Form Value
                    // must iterate to exclude some fields
                    const formControls = Object.keys(draft.form);
                    const fieldsToExclude = ["RFAInfo"];
                    let dictsToRestore = [];
                    if (draft.form.dicts) {
                        dictsToRestore = Object.keys(draft.form.dicts);
                    }
                    formControls.forEach(controlName => {
                        if (controlName === "dicts") {
                            dictsToRestore.forEach(prop => {
                                this.dicts[prop] = draft.form.dicts[prop];
                            });
                        }
                        const control = this.Form.get(controlName);
                        if (control && fieldsToExclude.indexOf(controlName) === -1) {
                            control.setValue(draft.form[controlName]);
                        }
                    });
                    const _comp = this.listMapTypeToIdComponent.get("approvalcreate");
                    if (_comp !== undefined) {
                        this.ApvRfaReady = false;
                        yield this.constructCreateRfa(_comp.componentObj, _comp.id, false);
                    }
                }
            }
            this.initialValue = this.getFormValue(true);
            this.dicts = Object.assign(this.dicts, { form: this.initialValue });
            this.dicts = Object.assign(this.dicts, { formRaw: this.initialValue });
            this.publishDictionary();
            this.logger.log('ngForm init', this.enjiForm);
            this.logger.log('initial form value', this.initialValue);
            if (this.isStepper) {
                if (!this.parentDicts.hasOwnProperty("childDicts")) {
                    this.parentDicts.childDicts = {};
                }
                if (!this.parentDicts.childDicts.hasOwnProperty("form")) {
                    this.parentDicts.childDicts.form = {};
                }
                if (!this.parentDicts.childDicts.hasOwnProperty("formRaw")) {
                    this.parentDicts.childDicts.formRaw = {};
                }
                this.parentDicts.childDicts.form = Object.assign(Object.assign({}, this.parentDicts.childDicts.form), this.initialValue);
                this.parentDicts.childDicts.formRaw = Object.assign(Object.assign({}, this.parentDicts.childDicts.formRaw), this.initialValue);
            }
            this.formValueChangesSubscription = this.Form.valueChanges.subscribe(newValues => {
                this.dicts = Object.assign(this.dicts, { formRaw: this.Form.getRawValue() });
                this.dicts = Object.assign(this.dicts, { form: this.Form.value });
                this.publishDictionary();
                // if (this.templateObj?.persistData) {
                //   this.LocalStorage.createOrUpdate(`${this.templateObj?.persistPropName}.form`, this.Form.getRawValue());
                // }
                if (this.isStepper) {
                    if (!this.parentDicts.hasOwnProperty("childDicts")) {
                        this.parentDicts.childDicts = {};
                    }
                    if (!this.parentDicts.childDicts.hasOwnProperty("form")) {
                        this.parentDicts.childDicts.form = {};
                    }
                    if (!this.parentDicts.childDicts.hasOwnProperty("formRaw")) {
                        this.parentDicts.childDicts.formRaw = {};
                    }
                    this.parentDicts.childDicts.form = Object.assign(Object.assign({}, this.parentDicts.childDicts.form), this.Form.value);
                    this.parentDicts.childDicts.formRaw = Object.assign(Object.assign({}, this.parentDicts.childDicts.formRaw), this.Form.getRawValue());
                }
                this.logger.log('Form values changed:', newValues);
            });
        });
    }
    ngAfterViewInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.log('Module', this.templateService.environment['Module']);
            this.logger.log('BaseUrl', this.templateService.baseUrl);
            setTimeout(() => {
                this.setBorderRadius();
            }, 100);
            setTimeout(() => __awaiter(this, void 0, void 0, function* () {
                var e_1, _a;
                this.onFormCreated.emit(this.Form);
                yield this.createInitialFormValue();
                const formSubs = (next) => __awaiter(this, void 0, void 0, function* () {
                    var e_2, _d;
                    var _e, _f, _g, _h;
                    const subs = this.controlObservable[next];
                    if (!subs) {
                        return;
                    }
                    try {
                        for (var subs_1 = __asyncValues(subs), subs_1_1; subs_1_1 = yield subs_1.next(), !subs_1_1.done;) {
                            const id = subs_1_1.value;
                            const compObj = this.templateObj.component.find(x => x.id === id);
                            const isVisible = this.switchCase(compObj === null || compObj === void 0 ? void 0 : compObj.conditions);
                            if (compObj === null || compObj === void 0 ? void 0 : compObj.form) {
                                if (!isVisible) {
                                    const formInput = (_f = (_e = compObj === null || compObj === void 0 ? void 0 : compObj.form) === null || _e === void 0 ? void 0 : _e.subsection) === null || _f === void 0 ? void 0 : _f.formInput;
                                    const defaultValue = {};
                                    for (const control of formInput) {
                                        defaultValue[control === null || control === void 0 ? void 0 : control.Variable] = control === null || control === void 0 ? void 0 : control.Value;
                                        this.removeFormControl(control === null || control === void 0 ? void 0 : control.Variable);
                                    }
                                    const formInputObj = this.getComponent(id);
                                    formInputObj.FormEditObject = this.FormSettingService.SetFormEditObj(formInputObj.FormEditObject, defaultValue);
                                    this.IsReady = true;
                                    this.cdr.detectChanges();
                                    continue;
                                }
                                if (!this.IsAdd) {
                                    yield this.getSetEditObj(id, (_g = compObj.form) === null || _g === void 0 ? void 0 : _g.subsection);
                                }
                                continue;
                            }
                            else if (compObj === null || compObj === void 0 ? void 0 : compObj.container) {
                                let componentObj = Object.assign(compObj === null || compObj === void 0 ? void 0 : compObj.container, { type: 'modal', conditions: (compObj === null || compObj === void 0 ? void 0 : compObj.conditions) || [] });
                                this.compileContainer(id, { type: 'container', component: componentObj }, true);
                                continue;
                            }
                            const attrObj = compObj === null || compObj === void 0 ? void 0 : compObj.attr;
                            const attrInputObj = ((_h = this.getComponent(id)) === null || _h === void 0 ? void 0 : _h.component) || {};
                            const params = [];
                            for (const param of attrObj === null || attrObj === void 0 ? void 0 : attrObj.reqObj) {
                                const propValue = {
                                    property: param === null || param === void 0 ? void 0 : param.propName,
                                    value: param === null || param === void 0 ? void 0 : param.propValue
                                };
                                params.push(propValue);
                            }
                            attrInputObj.ReqGetListAttrObj = this.transformToObject({ arr: params });
                            this.attrService.refresh({ isRefresh: true, request: attrInputObj.ReqGetListAttrObj });
                            this.logger.log('form sub attr');
                        }
                    }
                    catch (e_2_1) { e_2 = { error: e_2_1 }; }
                    finally {
                        try {
                            if (subs_1_1 && !subs_1_1.done && (_d = subs_1.return)) yield _d.call(subs_1);
                        }
                        finally { if (e_2) throw e_2.error; }
                    }
                });
                try {
                    for (var _b = __asyncValues(Object.keys(this.initialValue)), _c; _c = yield _b.next(), !_c.done;) {
                        const prop = _c.value;
                        yield formSubs(prop);
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (_c && !_c.done && (_a = _b.return)) yield _a.call(_b);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
                this.formSubscription = this.formObserver.subscribe((next) => __awaiter(this, void 0, void 0, function* () {
                    if (!next) {
                        return;
                    }
                    yield formSubs(next);
                }));
                if (this.StepperObj) {
                    this.StepperView = new Stepper(document.getElementById(this.StepperObj.id), {
                        animation: true,
                        linear: false
                    });
                    let stepIndex = this.StepIndex;
                    let stepCode = this.getKeyByIndex(this.AppStep, stepIndex);
                    // Check is dictionary has StepCode
                    if (this.dicts.hasOwnProperty('StepCode')) {
                        stepIndex = this.AppStep[this.dicts['StepCode']];
                        stepCode = this.dicts['StepCode'];
                    }
                    this.chooseStep(stepIndex);
                    this.ChangeTab(stepCode);
                }
            }), 3000);
            if (this.isStepper) {
                this.selectedIdxChange.subscribe(idx => {
                    if (this.idx === idx) {
                        return;
                    }
                    this.idx = idx;
                    const components = this.templateObj.component.filter(x => x.hasOwnProperty('container'));
                    for (const component of components) {
                        const id = component.id;
                        const componentType = Object.keys(component).find(x => x !== 'id' && x !== 'conditions');
                        let componentObj = Object.assign(component[componentType], { type: 'page', conditions: (component === null || component === void 0 ? void 0 : component.conditions) || [] });
                        this.compileContainer(id, { type: componentType, component: componentObj }, true);
                    }
                });
            }
        });
    }
    ngOnInit() {
        this.pageCache = JSON.parse(localStorage.getItem('pageCache')) || {};
        this.templateObj = JSON.parse(localStorage.getItem('templateObj'));
        this.navigationSubscription = this.router.events.subscribe(next => {
            if (next instanceof NavigationEnd) {
                this.onRefresh.emit(this.queryParams);
            }
        });
        this.userAccess = JSON.parse(AdInsHelper.GetCookie(this.environment, this.cookieService, CommonConstant.USER_ACCESS));
        this.logger.log('Initialize Approval Request Template Component...');
        this.callbackSub = this.templateService.callback.subscribe(event => {
            this.logger.log('Received event: ', event);
            if (!event) {
                return;
            }
            if (event.hasOwnProperty('Actions') && this.StepperObj) {
                this.onNext(event);
            }
        });
        this.activeRoute.queryParams.subscribe(params => {
            this.logger.log('queryParams', params);
            this.queryParams = params;
        });
        this.activeRoute.params.subscribe(params => {
            this.logger.log('params', params);
            this.pagePath = 'form-template';
            const dataSnapshot = this.activeRoute.snapshot.data;
            // const page = dataSnapshot['page'] || params['page'];
            this.getPage(params, dataSnapshot, this.isStepper);
            this.getTemplate(this.pageName);
        });
        this.copyNotify = this.notify.subscribe(next => {
            if (next.type === 'container') {
                /* emit event should be an object with this property
                * {
                *   type: 'container'
                *   property: '' <-- refer to container key
                *   isRefresh: true/false <-- is the container need to refresh
                * }
                */
                this.notifyContainerChanges(next);
            }
            else if (next.type === 'button') {
                /* emit event should be an object with this property
                * {
                *   type: 'button'
                * }
                */
                console.log(`event type ${next.type} forwarded to uctable input [btnCallback]`);
            }
            else if (next.type === 'cbUpdateCreateApvScheme') {
                /* emit event should be an object with this property
                * {
                *   type: 'cbUpdateCreateApvScheme'
                * }
                */
                this.callback(next.type);
            }
            else {
                console.warn(`event with type ${next.type} has not implemented yet... please contact support`);
            }
        });
    }
    notifyContainerChanges(next) {
        const container = this.templateObj.component.filter(item => item.hasOwnProperty("container"));
        const compObj = container.find(x => x.container.key === next.property);
        let componentObj = Object.assign(compObj === null || compObj === void 0 ? void 0 : compObj.container, { type: 'modal', conditions: (compObj === null || compObj === void 0 ? void 0 : compObj.conditions) || [] });
        this.compileContainer(compObj.id, { type: 'container', component: componentObj }, next.isRefresh);
    }
    getPage(params, dataSnapshot, isStepper) {
        if (isStepper) {
            return;
        }
        if (params['page']) {
            this.pageName = params['page'];
        }
        else if (dataSnapshot['page']) {
            this.pageName = dataSnapshot['page'];
            this.pagePath = dataSnapshot['path'] || 'form-template';
        }
    }
    getTemplate(name, isComponent = false) {
        if (isComponent) {
            return;
        }
        const templateUrl = this.environment.isPageFromService ? `${this.envi.PagesURL}pages/${name}` : `${this.templateService.baseUrl}/assets/${this.pagePath}/${name}.json`;
        this.http.get(templateUrl).subscribe((res) => __awaiter(this, void 0, void 0, function* () {
            this.resetDictionary(res);
            if (this.isDialog) {
                this.dicts = Object.assign(this.dicts, this.refData);
                this.publishDictionary();
            }
            else {
                // this.FormSettingService.ResetUcForm(); // line disabled to allow form on multi tabs
            }
            const persistent = !!res['persistData'];
            if (!this.isDialog && !persistent) {
                this.LocalStorage.clear();
            }
            // Reset List Buttons
            this.topBtns = [];
            this.botBtns = [];
            yield this.onPageInit(res);
            yield this.transformCustomComponent(res);
        }));
    }
    resetDictionary(templateObj) {
        const token = this.templateService.getCookie(this.cookieService, CommonConstant.TOKEN);
        this.dicts = {};
        this.dicts = Object.assign(this.dicts, { listTemp: this.listTempService.getList() });
        this.dicts = Object.assign(this.dicts, this.queryParams);
        this.dicts = Object.assign(this.dicts, { token, IsDialog: this.isDialog, IsStepper: this.isStepper });
        this.dicts = Object.assign(this.dicts, { listChecked: [] });
        if (this.queryParams.hasOwnProperty('params')) {
            const params = this.ngxRouter.getQueryParams(this.queryParams);
            this.dicts = Object.assign(this.dicts, params);
        }
        // add useraccess into dictionary
        this.dicts = Object.assign(this.dicts, { useraccess: this.userAccess });
        const dictsRaw = localStorage.getItem('dicts');
        if (dictsRaw) {
            this.dicts = Object.assign(this.dicts, JSON.parse(dictsRaw));
            localStorage.removeItem('dicts');
        }
        // subscribe to data event
        this.data.subscribe(next => {
            this.dicts = Object.assign(this.dicts, next);
            this.notifyUpdateDict.emit(next);
            this.publishDictionary();
        });
        if (Object.keys(this.params).length > 0) {
            this.dicts = Object.assign(this.dicts, this.params);
        }
        this.publishDictionary();
        this.loadPersistentDatatable(templateObj);
    }
    onPageInit(templateObj) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!templateObj.hasOwnProperty('onInit')) {
                return;
            }
            const inits = templateObj.onInit || [];
            if (inits.length === 0) {
                return;
            }
            for (let init of inits) {
                const conditions = (init === null || init === void 0 ? void 0 : init.conditions) || [];
                const reqObj = init === null || init === void 0 ? void 0 : init.reqObj;
                let requestBody = {};
                // Check onload validation
                const valid = this.switchCase(conditions);
                if (!valid) {
                    continue;
                }
                const transformParams = [];
                for (const prop of reqObj) {
                    transformParams.push({
                        property: this.cleansingParams(prop.propName),
                        value: this.cleansingParams(prop.propValue)
                    });
                }
                requestBody = this.transformToObject({ arr: transformParams });
                const apiUrl = this.getServiceUrl(init === null || init === void 0 ? void 0 : init.environment, init === null || init === void 0 ? void 0 : init.apiPath); //this.templateService.envConfig[init?.environment] + init?.apiPath;
                const req = this.http.post(apiUrl, requestBody, AdInsConstant.SpinnerOptions);
                const res = yield lastValueFrom(req);
                const returnObj = init === null || init === void 0 ? void 0 : init.return;
                if (Object.keys(returnObj).length === 0) {
                    this.dicts = Object.assign(this.dicts, res);
                    continue;
                }
                let _obj = {};
                for (let obj of returnObj) {
                    _obj[obj.propName] = obj.propValue === '_res' ? res : this.parseValue(res, this.cleansingParams(obj.propValue), false, true); //res[obj.propValue];
                }
                this.dicts = Object.assign(this.dicts, _obj);
            }
            this.publishDictionary();
            this.loadPersistentDatatable(templateObj);
        });
    }
    loadPersistentDatatable(templateObj) {
        var _a, _b;
        if (!(templateObj === null || templateObj === void 0 ? void 0 : templateObj.persistData)) {
            return;
        }
        const tableObj = templateObj.component.find(x => x.hasOwnProperty('table'));
        if (!tableObj) {
            return;
        }
        const tempData = this.LocalStorage.find(templateObj === null || templateObj === void 0 ? void 0 : templateObj.persistPropName) || {};
        const tableData = tempData[(_a = tableObj.table) === null || _a === void 0 ? void 0 : _a.resultData] || [];
        if (tableData.length > 0) {
            const key = ((_b = tableObj.table) === null || _b === void 0 ? void 0 : _b.resultData) || 'resultData';
            const tableList = {};
            tableList[key] = tableData;
            this.dicts = Object.assign(this.dicts, tableList);
        }
    }
    storeLocalStorage(dataForm) {
        var _a, _b, _c, _d, _e, _f, _g;
        if (!this.templateObj) {
            return;
        }
        const dataObj = this.LocalStorage.find((_a = this.templateObj) === null || _a === void 0 ? void 0 : _a.persistPropName) || {};
        // Check is template has table component
        const tableObj = this.templateObj.component.find(x => x.hasOwnProperty('table'));
        if (tableObj) {
            dataObj[(_b = tableObj.table) === null || _b === void 0 ? void 0 : _b.resultData] = dataObj[(_c = tableObj.table) === null || _c === void 0 ? void 0 : _c.resultData] != undefined ? dataObj[(_d = tableObj.table) === null || _d === void 0 ? void 0 : _d.resultData] :
                this.dicts[(_e = tableObj.table) === null || _e === void 0 ? void 0 : _e.resultData] || [];
        }
        dataObj['form'] = dataForm;
        if ((_f = this.templateObj) === null || _f === void 0 ? void 0 : _f.persistData) {
            this.LocalStorage.create((_g = this.templateObj) === null || _g === void 0 ? void 0 : _g.persistPropName, dataObj);
            this.logger.log(this.templateObj.persistPropName, this.LocalStorage.find(this.templateObj.persistPropName));
        }
    }
    transformCustomComponent(templateObj) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j;
        return __awaiter(this, void 0, void 0, function* () {
            this.templateObj = templateObj;
            this.cacheable = templateObj === null || templateObj === void 0 ? void 0 : templateObj.persistData;
            this.pageTitle = (_a = this.templateObj) === null || _a === void 0 ? void 0 : _a.title;
            const titles = ((_b = this.templateObj) === null || _b === void 0 ? void 0 : _b.conditionalTitle) || [];
            localStorage.setItem('templateObj', JSON.stringify(templateObj));
            // 08 Sept 2023 | Add conditional title
            for (const titleObj of titles) {
                const isTitleValid = this.switchCase(titleObj === null || titleObj === void 0 ? void 0 : titleObj.conditions);
                if (!isTitleValid) {
                    continue;
                }
                this.pageTitle = titleObj === null || titleObj === void 0 ? void 0 : titleObj.title;
            }
            const transform = () => __awaiter(this, void 0, void 0, function* () {
                var _k;
                const customComponent = this.templateObj.component.filter(item => item.hasOwnProperty("customComponent"));
                const checkForConditions = (comp, conditions) => {
                    if (conditions === undefined)
                        return;
                    if (conditions.length === 0)
                        return;
                    if (comp[0].conditions === undefined) {
                        comp[0].conditions = [];
                    }
                    comp[0].conditions.push(...conditions);
                };
                for (let component of customComponent) {
                    const idx = this.templateObj.component.indexOf(component);
                    this.logger.log('idx', idx);
                    const _var = (_k = component === null || component === void 0 ? void 0 : component.customComponent) === null || _k === void 0 ? void 0 : _k.componentRef.slice(2, -1);
                    const templateUrl = this.environment.isPageFromService ? `${this.envi.PagesURL}customComp/${_var}` : `${this.templateService.baseUrl}/assets/form-template/custom-component/${_var}.json`;
                    const req = this.http.get(templateUrl);
                    const res = yield lastValueFrom(req);
                    const x = res['customComponent'] || [];
                    checkForConditions(x, component.conditions);
                    this.templateObj.component.splice(idx, 1, ...x);
                }
                // Check is component need to transform again?
                const xComponent = this.templateObj.component.filter(item => item.hasOwnProperty("customComponent"));
                if (xComponent.length > 0) {
                    yield transform();
                }
            });
            yield transform();
            this.hideSubmitButton = !!this.templateObj.hideSubmitButton;
            this.hideCancelButton = !!((_c = this.templateObj) === null || _c === void 0 ? void 0 : _c.hideCancelButton);
            if (((_d = this.templateObj) === null || _d === void 0 ? void 0 : _d.overrideSubmitBtnText) !== undefined && ((_e = this.templateObj) === null || _e === void 0 ? void 0 : _e.overrideSubmitBtnText) !== "") {
                this.overrideSubmitBtnText = (_g = (_f = this.templateObj) === null || _f === void 0 ? void 0 : _f.overrideSubmitBtnText) !== null && _g !== void 0 ? _g : "Submit";
            }
            if (((_h = this.templateObj) === null || _h === void 0 ? void 0 : _h.listBtn) && ((_j = this.templateObj) === null || _j === void 0 ? void 0 : _j.listBtn.length) > 0) {
                this.topBtns = this.templateObj.listBtn.filter(x => x.position === 'top');
                this.botBtns = this.templateObj.listBtn.filter(x => x.position === 'bottom');
            }
            yield this.render();
            setTimeout(() => __awaiter(this, void 0, void 0, function* () {
                yield this.createInitialFormValue();
            }), 1000);
            this.logger.log('template setting', this.templateObj);
        });
    }
    render() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            this.enjiForm = null;
            this.listIds = [];
            this.customClass = {};
            this.componentTypes = [];
            this.listMapComponent.clear();
            this.listMapTypeToIdComponent.clear();
            this.Form = this.fb.group({});
            this.templateService.container.setForm(this.Form);
            const components = (_a = this.templateObj) === null || _a === void 0 ? void 0 : _a.component;
            this.serviceUrl = (_b = this.templateObj) === null || _b === void 0 ? void 0 : _b.serviceUrl;
            // Merge Query Params to Dict
            if (this.queryParams.hasOwnProperty('params')) {
                const params = this.ngxRouter.getQueryParams(this.queryParams);
                this.dicts = Object.assign(this.dicts, params);
            }
            yield this.compile(components);
            this.templateService.setListMapComponent(this.templateObj.id, this.listMapComponent);
            this.logger.log('hasForm', this.hasFormComponent());
            this.logger.log('list component', components);
        });
    }
    compile(components, type = 'page') {
        return __awaiter(this, void 0, void 0, function* () {
            for (const component of components) {
                const id = component.id;
                const componentType = Object.keys(component).find(x => x !== 'id' && x !== 'conditions');
                this.logger.log('componentType', componentType);
                this.componentTypes.push(componentType);
                let componentObj = Object.assign(component[componentType], { type: type, conditions: (component === null || component === void 0 ? void 0 : component.conditions) || [], listBtn: (component === null || component === void 0 ? void 0 : component.listBtn) || [] });
                switch (componentType) {
                    case 'view':
                        this.compileView(id, { type: componentType, component: componentObj });
                        break;
                    case 'form':
                        yield this.compileForm(id, { type: componentType, component: componentObj });
                        break;
                    case 'attr':
                        yield this.compileAttr(id, { type: componentType, component: componentObj });
                        break;
                    case 'formarray':
                        yield this.compileFormArray(id, { type: componentType, component: componentObj });
                        break;
                    case 'paging':
                        this.compilePaging(id, { type: componentType, component: componentObj });
                        break;
                    case 'table':
                        yield this.compileGridView(id, { type: componentType, component: componentObj });
                        break;
                    case 'addtotemp':
                        this.compileTemp(id, { type: componentType, component: componentObj });
                        break;
                    case 'approvalcreate':
                        yield this.compileCreateRfa(id, { type: componentType, component: componentObj });
                        break;
                    case 'approvalcreate_manualdeviation':
                        yield this.compileCreateRfaManualDeviation(id, { type: componentType, component: componentObj });
                        break;
                    case 'approvalr3':
                        this.compileApproval(id, { type: componentType, component: componentObj });
                        break;
                    case 'approvalr3_multi':
                        this.compileApprovalMulti(id, { type: componentType, component: componentObj });
                        break;
                    case 'approvalgeneralinfo':
                        this.compileApprovalGeneralInfo(id, { type: componentType, component: componentObj });
                        break;
                    case 'approvalhistory':
                        this.compileApprovalHistory(id, { type: componentType, component: componentObj });
                        break;
                    case 'report':
                        this.compileReport(id, { type: componentType, component: componentObj });
                        break;
                    case 'upload':
                        this.compileUpload(id, { type: componentType, component: componentObj });
                        break;
                    case 'fileupload':
                        this.compileFileUpload(id, { type: componentType, component: componentObj });
                        break;
                    case 'viewFileupload':
                        this.compileViewFileUpload(id, { type: componentType, component: componentObj });
                        break;
                    case 'container':
                        yield this.compileContainer(id, { type: componentType, component: componentObj });
                        break;
                    case 'stepper':
                        this.compileStepper(id, { type: componentType, component: componentObj });
                        break;
                    case 'tabs':
                        yield this.compileTabs(id, { type: componentType, component: componentObj });
                        break;
                }
                this.logger.log(componentType, componentObj);
            }
        });
    }
    getSetEditObj(formId, formObj) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
        return __awaiter(this, void 0, void 0, function* () {
            const formInput = this.getComponent(formId);
            const onloads = (formObj === null || formObj === void 0 ? void 0 : formObj.onLoad) || [];
            const component = this.listMapComponent.get(formId);
            const formConditions = (component === null || component === void 0 ? void 0 : component.conditions) || [];
            const isComVisible = this.switchCase(formConditions);
            if (onloads.length === 0 || !isComVisible) {
                formInput.FormEditObject = this.FormSettingService.SetFormEditObj(formInput.FormEditObject, {});
                this.cdr.detectChanges();
                this.IsReady = true;
                return;
            }
            const address = formObj.formInput.filter(x => x.Type === 'ADDRESS') || [];
            const lookups = formObj.formInput.filter(x => x.Type === 'LOOKUP') || [];
            const trees = formObj.formInput.filter(x => x.Type === 'TREE') || [];
            this.formOnLoadAct[formId] = onloads;
            for (const onload of onloads) {
                const conditions = (onload === null || onload === void 0 ? void 0 : onload.conditions) || [];
                const valid = this.switchCase(conditions);
                if (!valid) {
                    continue;
                }
                let res;
                this.RowVersion = '';
                const formInput = this.getComponent(formId);
                const mapRes = (onload === null || onload === void 0 ? void 0 : onload.mapRes) || [];
                if (!onload.hasOwnProperty('isUseApi')) {
                    onload['isUseApi'] = true;
                }
                if (onload === null || onload === void 0 ? void 0 : onload.isUseApi) {
                    const serviceUrl = this.envi[onload === null || onload === void 0 ? void 0 : onload.environment] + (onload === null || onload === void 0 ? void 0 : onload.apiPath);
                    let reqBody = {};
                    // Updated 23 Mei 2023
                    const reqObj = (onload === null || onload === void 0 ? void 0 : onload.reqObj) || [];
                    const arrObj = [];
                    for (let obj of reqObj) {
                        arrObj.push({ property: obj === null || obj === void 0 ? void 0 : obj.propName, value: obj === null || obj === void 0 ? void 0 : obj.propValue });
                    }
                    reqBody = this.transformToObject({ arr: arrObj });
                    this.logger.log('reqBody', reqBody);
                    const req = this.http.post(serviceUrl, reqBody);
                    res = yield lastValueFrom(req);
                    this.RowVersion = res['RowVersion'] || '';
                    this.logger.log(res);
                    // Add response to dicts
                    this.dicts = Object.assign(this.dicts, res);
                    this.publishDictionary();
                    this.logger.log('dictionary', this.dicts);
                }
                else if (!(onload === null || onload === void 0 ? void 0 : onload.isUseApi) && (onload === null || onload === void 0 ? void 0 : onload.dataSource) !== 'dicts') {
                    const record = this.LocalStorage.find(onload === null || onload === void 0 ? void 0 : onload.propName) || [];
                    const params = (onload === null || onload === void 0 ? void 0 : onload.reqObj) || [];
                    const findObjectInArray = (array, params) => {
                        return array.find(obj => {
                            for (const param of params) {
                                if (obj[param.propName] != this.parseValue(this.dicts, param.propValue)) {
                                    return false;
                                }
                            }
                            return true;
                        });
                    };
                    const IdxParam = params.find(x => x.propName === 'Idx');
                    if (IdxParam) {
                        res = record[this.parseValue(this.dicts, IdxParam.propValue)];
                    }
                    else {
                        res = findObjectInArray(record, params) || {};
                    }
                    this.dicts = Object.assign(this.dicts, { beforeUpdate: res });
                    if ((_a = this.templateObj) === null || _a === void 0 ? void 0 : _a.persistData) {
                        const draft = this.LocalStorage.find((_b = this.templateObj) === null || _b === void 0 ? void 0 : _b.persistPropName);
                        res = draft !== null && (draft === null || draft === void 0 ? void 0 : draft.form) ? draft.form : res;
                    }
                    this.dicts = Object.assign(this.dicts, res);
                }
                else {
                    res = this.parseValue(this.dicts, onload === null || onload === void 0 ? void 0 : onload.propName);
                }
                // Update form values
                for (let lookup of lookups) {
                    let x = this.LookupService.GetInputLookupObj(lookup === null || lookup === void 0 ? void 0 : lookup.Variable);
                    let inputLookup = this.lookupMap[lookup.Variable];
                    // Handle lookup form array
                    if (x === undefined) {
                        this.LookupFAService.SetNameSelect(lookup === null || lookup === void 0 ? void 0 : lookup.Variable, res[(_c = inputLookup.dataInput) === null || _c === void 0 ? void 0 : _c.propertyName]);
                        this.LookupFAService.SetJsonSelect(lookup === null || lookup === void 0 ? void 0 : lookup.Variable, res);
                        break;
                    }
                    this.LookupService.SetNameSelect(lookup === null || lookup === void 0 ? void 0 : lookup.Variable, res[(_d = inputLookup.dataInput) === null || _d === void 0 ? void 0 : _d.propertyName]);
                    this.LookupService.SetIdSelect(lookup === null || lookup === void 0 ? void 0 : lookup.Variable, res[(_e = inputLookup.dataInput) === null || _e === void 0 ? void 0 : _e.propertyId]);
                    this.LookupService.SetJsonSelect(lookup === null || lookup === void 0 ? void 0 : lookup.Variable, res);
                }
                for (const addr of address) {
                    const objMap = [];
                    for (const map of mapRes) {
                        objMap.push({
                            isFromDict: true,
                            property: map === null || map === void 0 ? void 0 : map.variableName,
                            value: map === null || map === void 0 ? void 0 : map.accessorName
                        });
                    }
                    const objAddr = this.transformToObject({ arr: objMap });
                    this.logger.log(addr === null || addr === void 0 ? void 0 : addr.Variable, objAddr);
                    if (!objAddr.hasOwnProperty(addr === null || addr === void 0 ? void 0 : addr.Variable)) {
                        continue;
                    }
                    if (((_f = objAddr[addr === null || addr === void 0 ? void 0 : addr.Variable]) === null || _f === void 0 ? void 0 : _f.StaySince) != null && ((_g = objAddr[addr === null || addr === void 0 ? void 0 : addr.Variable]) === null || _g === void 0 ? void 0 : _g.StaySince) != "") {
                        const _date = new Date((_h = objAddr[addr === null || addr === void 0 ? void 0 : addr.Variable]) === null || _h === void 0 ? void 0 : _h.StaySince);
                        objAddr[addr === null || addr === void 0 ? void 0 : addr.Variable].StaySince = this.FormatDateToYYYYMM(_date);
                    }
                    if (((_j = objAddr[addr === null || addr === void 0 ? void 0 : addr.Variable]) === null || _j === void 0 ? void 0 : _j.MrHouseOwnershipCode) === null || ((_k = objAddr[addr === null || addr === void 0 ? void 0 : addr.Variable]) === null || _k === void 0 ? void 0 : _k.MrHouseOwnershipCode) === undefined) {
                        objAddr[addr === null || addr === void 0 ? void 0 : addr.Variable].MrHouseOwnershipCode = "";
                    }
                    const addrObj = this.AddressService.GetInputAddressObj(addr === null || addr === void 0 ? void 0 : addr.Variable);
                    addrObj.default = objAddr[addr === null || addr === void 0 ? void 0 : addr.Variable];
                    addrObj.inputField.inputLookupObj.nameSelect = objAddr[addr.Variable]['Zipcode'];
                    addrObj.inputField.inputLookupObj.jsonSelect = { Zipcode: objAddr[addr.Variable]['Zipcode'] };
                }
                if (trees.length > 0) {
                    for (const tree of trees) {
                        if (!res.hasOwnProperty(tree === null || tree === void 0 ? void 0 : tree.Variable)) {
                            continue;
                        }
                        res = this.flattenObject(res, tree.Variable);
                    }
                }
                formInput.FormEditObject = this.FormSettingService.SetFormEditObj(formInput.FormEditObject, res);
                if (mapRes && mapRes.length > 0) {
                    let _mapObj = {};
                    for (let _var of mapRes) {
                        _mapObj[_var === null || _var === void 0 ? void 0 : _var.variableName] = this.parseValue(this.dicts, _var === null || _var === void 0 ? void 0 : _var.accessorName, false, !!(_var === null || _var === void 0 ? void 0 : _var.isEmptyNotFound));
                    }
                    // Update form value from map response
                    formInput.FormEditObject = this.FormSettingService.SetFormEditObj(formInput.FormEditObject, _mapObj);
                }
                this.FormSettingService.notify(true, formInput.formId);
                this.cdr.detectChanges();
                this.IsReady = true;
                // setTimeout(() => {
                //   // call form action to ucform
                //   this.callbackAction.emit(onload?.action || []);
                // }, 1000);
            }
        });
    }
    getParentInfo() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            if (!((_a = this.templateObj) === null || _a === void 0 ? void 0 : _a.onLoad)) {
                return;
            }
            for (const parentId of (_b = this.templateObj) === null || _b === void 0 ? void 0 : _b.onLoad) {
                if (parentId.propertyName === this.templateObj[parentId.propertyName]) {
                    break;
                }
                const propId = (parentId === null || parentId === void 0 ? void 0 : parentId.value) || (parentId === null || parentId === void 0 ? void 0 : parentId.propertyName);
                yield this.getSetEditObj(parentId.url, this.templateObj[propId]);
                this.logger.log(parentId.propertyName, parentId.url);
            }
        });
    }
    getComponentType(id) {
        const componentObj = this.listMapComponent.get(id);
        return componentObj.type;
    }
    getComponent(id, enjiForm) {
        // this.logger.log('id:', id);
        if (!this.enjiForm && enjiForm) {
            this.enjiForm = enjiForm;
            this.templateService.container.setEnjiForm(enjiForm);
            // this.logger.log('enjiForm updated', this.enjiForm);
        }
        const componentObj = this.listMapComponent.get(id);
        // this.logger.log(`id-${id}:`, componentObj);
        return componentObj === null || componentObj === void 0 ? void 0 : componentObj.component;
    }
    getTabComponent(id, tab, enjiForm) {
        if (!this.enjiForm && enjiForm) {
            this.enjiForm = enjiForm;
            this.templateService.container.setEnjiForm(enjiForm);
            this.logger.log('enjiForm updated', this.enjiForm);
        }
        const tabs = this.TabList[id];
        const idx = tabs.indexOf(tab);
        const identifier = `${id}-${tab === null || tab === void 0 ? void 0 : tab.content}-${idx}`;
        const componentObj = this.listMapComponent.get(identifier);
        return componentObj.component;
    }
    isVisible(id) {
        const component = this.listMapComponent.get(id);
        const conditions = (component === null || component === void 0 ? void 0 : component.conditions) || [];
        const isVisible = this.switchCase(conditions);
        if (this.listIsVisible[id] === false && this.listIsVisible[id] != isVisible && component.type === 'container') {
            console.log("===============awef=============aewf", component);
            const compObj = this.templateObj.component.find(x => x.id === id);
            const componentObj = Object.assign(compObj === null || compObj === void 0 ? void 0 : compObj.container, { type: 'container', conditions: (compObj === null || compObj === void 0 ? void 0 : compObj.conditions) || [] });
            this.compileContainer(id, { type: 'container', component: componentObj }, true);
        }
        this.listIsVisible[id] = isVisible;
        return isVisible;
    }
    getCssClass(key) {
        return this.customClass[key];
    }
    hasFormComponent() {
        let hasForm = false;
        const formIdx = this.componentTypes.indexOf('form');
        hasForm = formIdx !== -1;
        if (hasForm) {
            return hasForm;
        }
        // const stepIdx = this.componentTypes.indexOf('stepper');
        // hasForm = stepIdx !== -1;
        // if (hasForm) {
        //   return hasForm;
        // }
        const fileIdx = this.componentTypes.indexOf('fileupload');
        hasForm = fileIdx !== -1;
        if (hasForm) {
            return hasForm;
        }
        const attrIdx = this.componentTypes.indexOf('attr');
        hasForm = attrIdx !== -1;
        if (hasForm) {
            return hasForm;
        }
        const formArrayIdx = this.componentTypes.indexOf('formarray');
        hasForm = formArrayIdx !== -1;
        if (hasForm) {
            return hasForm;
        }
        const containerIdx = this.componentTypes.indexOf('containerform');
        hasForm = containerIdx !== -1;
        if (hasForm) {
            return hasForm;
        }
        const approvalCreateIdx = this.componentTypes.indexOf('approvalcreate');
        hasForm = approvalCreateIdx !== -1;
        if (hasForm) {
            return hasForm;
        }
        // approvalcreate_manualdeviation
        const approvalCreateDevIdx = this.componentTypes.indexOf('approvalcreate_manualdeviation');
        hasForm = approvalCreateDevIdx !== -1;
        if (hasForm) {
            return hasForm;
        }
        const approvalR3Idx = this.componentTypes.indexOf('approvalr3');
        hasForm = approvalR3Idx !== -1;
        if (hasForm) {
            return hasForm;
        }
        const approvalR3MultiIdx = this.componentTypes.indexOf('approvalr3_multi');
        hasForm = approvalR3MultiIdx !== -1;
        if (hasForm) {
            return hasForm;
        }
        return hasForm;
    }
    getListTemp(ev) {
        this.logger.log('event', ev);
        const listTemp = ev.TempListObj;
        this.listTempService.setList(listTemp);
        this.dicts = Object.assign(this.dicts, { listTemp: this.listTempService.getList() });
        this.publishDictionary();
        this.logger.log('LIST_TEMP', this.listTempService.getList());
    }
    getFormValue(isRaw = false) {
        var _a, _b, _c;
        const tables = this.templateObj.component.filter(x => x.hasOwnProperty('table')) || [];
        const addObj = { RowVersion: this.RowVersion === undefined ? '' : this.RowVersion };
        let rawData = isRaw ? this.Form.getRawValue() : this.Form.value;
        for (const tableObj of tables) {
            if (!((_a = tableObj.table) === null || _a === void 0 ? void 0 : _a.includeSubmit)) {
                continue;
            }
            addObj[(_b = tableObj.table) === null || _b === void 0 ? void 0 : _b.resultData] = this.dicts[(_c = tableObj.table) === null || _c === void 0 ? void 0 : _c.resultData];
        }
        const attrs = this.templateObj.component.filter(x => x.hasOwnProperty('attr')) || [];
        for (const attrObj of attrs) {
            const attr = attrObj === null || attrObj === void 0 ? void 0 : attrObj.attr;
            const tempAttrs = rawData[attr === null || attr === void 0 ? void 0 : attr.variable] || [];
            const attributes = [];
            for (const attrVal of tempAttrs) {
                const attribute = {};
                attribute[attr === null || attr === void 0 ? void 0 : attr.propertyCodeName] = attrVal[attr === null || attr === void 0 ? void 0 : attr.propertyCodeName];
                attribute[attr === null || attr === void 0 ? void 0 : attr.propertyCodeValue] = attrVal[attr === null || attr === void 0 ? void 0 : attr.propertyCodeValue];
                attributes.push(attribute);
            }
            rawData[attr === null || attr === void 0 ? void 0 : attr.variable] = attributes;
        }
        return Object.assign(rawData, addObj);
    }
    refreshView() {
        this.notifyUpdateView.emit(true);
    }
    updateViewFileDocLength(ev) {
        this.notifyUpdateViewFileUpload.emit(ev);
    }
    notifyUpdateViewFileUploadFromModal(ev) {
        this.notifyUpdateViewFileUpload.emit(ev);
    }
    SaveForm() {
        // Use override submit config
        const payloadObj = this.getFormValue();
        const isValid = this.beforeSave();
        if (isValid) {
            this.logger.log('criterias', this.formCriteria);
            if (this.formCriteria) {
                for (const criteria of this.formCriteria) {
                    if (!this.IsAdd === (criteria === null || criteria === void 0 ? void 0 : criteria.setOnEdit)) {
                        payloadObj[criteria.propName] = !!(criteria === null || criteria === void 0 ? void 0 : criteria.isFromDict) ? this.parseValue(this.dicts, criteria === null || criteria === void 0 ? void 0 : criteria.propValue) : criteria === null || criteria === void 0 ? void 0 : criteria.propValue;
                    }
                }
            }
            this.logger.log(payloadObj);
            this.doSave(payloadObj);
        }
    }
    beforeSave() {
        if (!this.handler) {
            return true;
        }
        if (this.handler && !this.handler.beforeSave) {
            return true;
        }
        return this.handler.beforeSave();
    }
    afterSave(data, redirectUrl) {
        var _a;
        this.logger.log('result', data);
        if (this.handler && ((_a = this.handler) === null || _a === void 0 ? void 0 : _a.afterSave)) {
            this.handler.afterSave(data);
        }
        else {
            this.back(redirectUrl);
        }
    }
    doSave(request) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y;
        this.logger.log('requestForm', request);
        if (this.selfCustom) {
            return;
        }
        if (!!((_a = this.templateObj) === null || _a === void 0 ? void 0 : _a.isOverrideSubmit)) {
            const queries = this.ngxRouter.getQueryParams(this.queryParams);
            if (queries && queries.hasOwnProperty('mode')) {
                this.dicts = Object.assign(this.dicts, { mode: this.isDialog ? this.refData['mode'] || 'add' : queries['mode'] });
            }
            this.dicts = Object.assign(this.dicts, { form: request });
            this.dicts = Object.assign(this.dicts, { formRaw: this.getFormValue(true) });
            this.publishDictionary();
            const action = { type: ActionType.Switch, cases: (_b = this.templateObj) === null || _b === void 0 ? void 0 : _b.onSubmit };
            this.logger.log('dictionary', this.dicts);
            this.switchAction(action);
            return;
        }
        let apiUrl;
        const submitData = (url, req, redirectUrl) => {
            var _a;
            // Cancel request if url contain undefined string
            if (url === undefined) {
                console.error("The 'url' is undefined! Ensure that your submit configuration is correctly set, whether it's in the Editor or within your function.");
            }
            if (url.includes('undefined')) {
                this.toastr.toastr.warning("Please define environment and api path first in editor!");
                return;
            }
            const isDevMode = !!((_a = this.onSubmit) === null || _a === void 0 ? void 0 : _a.isDevMode);
            if (isDevMode) {
                this.logger.log('DevMode', { serviceUrl: url, requestBody: req });
                return;
            }
            this.http.post(url, req, AdInsConstant.SpinnerOptions).subscribe(res => {
                var _a;
                const _dicts = {
                    envi: {},
                };
                Object.assign(_dicts, this.dicts);
                Object.assign(_dicts, res);
                Object.assign(_dicts.envi, this.templateService.envConfig);
                this.publishDictionary();
                const msgStatement = ((_a = this.templateObj) === null || _a === void 0 ? void 0 : _a.customToastrMsg) || 'Message';
                const message = this.textManipulation(msgStatement, _dicts); //this.isStringManipulation(msgStatement) ? this.transformStringValue(msgStatement, this.dicts) : res[msgStatement];
                this.toastr.successMessage(message);
                this.afterSave(res, redirectUrl);
            });
        };
        if (this.ApvRfaReady) {
            if (this.isHumanApproval && this.onSubmit) {
                apiUrl = this.getServiceUrl((_c = this.onSubmit) === null || _c === void 0 ? void 0 : _c.environment, (_d = this.onSubmit) === null || _d === void 0 ? void 0 : _d.apiPath);
                //this.templateService.urlConstant[this.onSubmit?.apiPath] ? this.templateService.urlConstant[this.onSubmit?.apiPath] :
                // this.templateService.envConfig[this.onSubmit?.environment] + this.onSubmit?.apiPath;
                // Check is custom request payload
                const isCustomReqObj = !!this.onSubmit.customRequestObject;
                let _req = request;
                if (isCustomReqObj) {
                    this.dicts = Object.assign(this.dicts, { formValue: request });
                    Object.keys(this.queryParams).forEach(key => {
                        this.dicts[key] = this.queryParams[key];
                    });
                    _req = this.transformToObject({ arr: ((_e = this.onSubmit) === null || _e === void 0 ? void 0 : _e.reqObj) || request });
                }
                submitData(apiUrl, _req, (_f = this.onSubmit) === null || _f === void 0 ? void 0 : _f.redirectUrl);
                return;
            }
            apiUrl = this.getServiceUrl((_h = (_g = this.serviceUrl) === null || _g === void 0 ? void 0 : _g.createRfa) === null || _h === void 0 ? void 0 : _h.environment, (_k = (_j = this.serviceUrl) === null || _j === void 0 ? void 0 : _j.createRfa) === null || _k === void 0 ? void 0 : _k.apiPath); //this.templateService.envConfig[this.serviceUrl?.createRfa?.environment] +
            // this.serviceUrl?.createRfa?.apiPath;
            submitData(apiUrl, request);
            return;
        }
        if (this.ApvReady && this.onSubmit) {
            apiUrl = this.templateService.envConfig[(_l = this.onSubmit) === null || _l === void 0 ? void 0 : _l.environment] + ((_m = this.onSubmit) === null || _m === void 0 ? void 0 : _m.apiPath);
            // let addReqObj = {};
            // const approvalRequestObj = this.onSubmit?.approvalRequestObj || {};
            // Object.keys(approvalRequestObj).forEach(key => {
            //   addReqObj[key] = this.queryParams[key] ? this.queryParams[key] : approvalRequestObj[key];
            // });
            // Check is custom request payload
            const isCustomReqObj = !!((_o = this.onSubmit) === null || _o === void 0 ? void 0 : _o.approvalRequestObj);
            let _req = request;
            if (isCustomReqObj) {
                this.dicts = Object.assign(this.dicts, { formValue: request });
                Object.keys(this.queryParams).forEach(key => {
                    this.dicts[key] = this.queryParams[key];
                });
                const _data = Object.keys((_p = this.onSubmit) === null || _p === void 0 ? void 0 : _p.approvalRequestObj).map(x => {
                    var _a;
                    return {
                        property: x,
                        value: (_a = this.onSubmit) === null || _a === void 0 ? void 0 : _a.approvalRequestObj[x],
                    };
                });
                _req = Object.assign(Object.assign({}, _req), this.transformToObject({ arr: _data || request }));
            }
            // request = Object.assign(request, addReqObj);
            submitData(apiUrl, _req, (_q = this.onSubmit) === null || _q === void 0 ? void 0 : _q.redirectUrl);
            return;
        }
        if (this.IsAdd) {
            apiUrl = this.getServiceUrl((_s = (_r = this.serviceUrl) === null || _r === void 0 ? void 0 : _r.add) === null || _s === void 0 ? void 0 : _s.environment, (_u = (_t = this.serviceUrl) === null || _t === void 0 ? void 0 : _t.add) === null || _u === void 0 ? void 0 : _u.apiPath); //this.serviceUrl?.add?.apiUrl ? this.serviceUrl?.add?.apiUrl :
            // this.templateService.envConfig[this.serviceUrl?.add?.environment] + this.serviceUrl?.add?.apiPath;
        }
        else {
            apiUrl = this.getServiceUrl((_w = (_v = this.serviceUrl) === null || _v === void 0 ? void 0 : _v.edit) === null || _w === void 0 ? void 0 : _w.environment, (_y = (_x = this.serviceUrl) === null || _x === void 0 ? void 0 : _x.edit) === null || _y === void 0 ? void 0 : _y.apiPath); //this.serviceUrl?.add?.apiUrl ? this.serviceUrl?.edit?.apiUrl :
            // this.templateService.envConfig[this.serviceUrl?.edit?.environment] + this.serviceUrl?.edit?.apiPath;
        }
        if (apiUrl.includes('undefined') && this.isDialog) {
            this.onSubmitModal();
        }
        else {
            submitData(apiUrl, request);
        }
    }
    onSubmitModal() {
        this.dialogRef.close({ data: this.getFormValue(true), isModeAdd: this.IsAdd });
    }
    checkServiceUrl(env, path) {
        let result = true;
        if (!env) {
            result = false;
        }
        if (!path) {
            result = false;
        }
        return result;
    }
    back(redirectUrl) {
        var _a, _b, _c, _d, _e, _f, _g;
        this.cacheable = false;
        // Check data has list temp or not?
        if (this.dicts['listTemp'] && Object.keys(this.dicts['listTemp']).length > 0) {
            this.dicts['listTemp'] = [];
            this.listTempService.clearAll();
        }
        if (this.isDialog) {
            this.dialogRef.close();
            return;
        }
        if (redirectUrl) {
            this.router.navigate([redirectUrl], { queryParams: this.queryParams });
            return;
        }
        if ((_a = this.templateObj) === null || _a === void 0 ? void 0 : _a.isRedirect) {
            const redirectOpt = (_b = this.templateObj) === null || _b === void 0 ? void 0 : _b.redirectOption;
            if (redirectOpt === 'selfPage') {
                this.enjiForm.resetForm(this.initialValue);
                // this.ngOnInit();
                return;
            }
            const extras = { queryParams: this.queryParams };
            if (redirectOpt === 'customPath') {
                const customPath = this.templateService.navConstant[(_c = this.templateObj) === null || _c === void 0 ? void 0 : _c.redirectLink];
                const redirectUrl = !!customPath ? customPath : (_d = this.templateObj) === null || _d === void 0 ? void 0 : _d.redirectLink;
                this.router.navigateByUrl(redirectUrl, extras);
            }
            else {
                this.router.navigateByUrl((_e = this.templateObj) === null || _e === void 0 ? void 0 : _e.redirectLink, extras);
            }
        }
        // Check is use override cancel action
        if (!!((_f = this.templateObj) === null || _f === void 0 ? void 0 : _f.isOverrideCancel)) {
            this.actionResult((_g = this.templateObj) === null || _g === void 0 ? void 0 : _g.onCancel);
        }
        else {
            this.location.back();
        }
    }
    callbackLookup(property) {
        this.cbLookupManual.emit(property);
    }
    callbackUpdateFormArr(ev) {
        this.notifyUpdateFormArray.emit(ev);
    }
    callbackUpdateDict(ev) {
        this.notifyUpdateDict.emit(ev);
    }
    callbackOnReadyForm(ev) {
        this.notifyOnReadyForm.emit(ev);
    }
    callback(ev) {
        var _a, _b, _c, _d;
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.log('event:', ev);
            if (Array.isArray(ev)) {
                const selected = ev.filter(x => (x === null || x === void 0 ? void 0 : x.Selected) === true);
                this.dicts = Object.assign(this.dicts, { listChecked: selected });
                this.dicts = Object.assign(this.dicts, { listDataSelection: ev });
                this.publishDictionary();
                return;
            }
            if (ev === null || ev === void 0 ? void 0 : ev.Action) {
                const action = ev.Action;
                let params = [];
                this.dicts = Object.assign(this.dicts, { RowObj: ev.RowObj });
                this.publishDictionary();
                if (action === null || action === void 0 ? void 0 : action.param) {
                    for (const arg of action.param) {
                        const param = {
                            propName: arg.type,
                            propValue: arg.property
                        };
                        params.push(param);
                    }
                    action['params'] = params;
                }
                this.actionResult(action, ev);
                return;
            }
            if (this.ApvReady && ev.hasOwnProperty('Tasks')) {
                this.doSave({ Tasks: ev.Tasks });
                return;
            }
            if (ev.hasOwnProperty('key')) {
                const tables = this.templateObj.component.filter(x => x.hasOwnProperty('table'));
                for (const tableObj of tables) {
                    if ((_a = tableObj === null || tableObj === void 0 ? void 0 : tableObj.table) === null || _a === void 0 ? void 0 : _a.isFromApi) {
                        continue;
                    }
                    if ((ev === null || ev === void 0 ? void 0 : ev.propName) !== ((_b = tableObj === null || tableObj === void 0 ? void 0 : tableObj.table) === null || _b === void 0 ? void 0 : _b.resultData)) {
                        continue;
                    }
                    this.notifyUpdateTable.emit({ id: tableObj === null || tableObj === void 0 ? void 0 : tableObj.id, component: tableObj === null || tableObj === void 0 ? void 0 : tableObj.table });
                }
                if ((_c = this.handler) === null || _c === void 0 ? void 0 : _c.callback) {
                    this.handler.callback(ev);
                }
                return;
            }
            if (typeof ev === 'string' && ev === CallbackKeys.CB_UPDATE_CREATE_APV) {
                const _comp = this.listMapTypeToIdComponent.get("approvalcreate");
                if (_comp === undefined)
                    return;
                this.ApvRfaReady = false;
                yield this.constructCreateRfa(_comp.componentObj, _comp.id, false);
                if (!this.isHumanApproval) {
                    return;
                }
            }
            if (this.isStepper) {
                const obj = {};
                obj[this.templateObj.id] = this.dicts;
                const action = { type: ActionType.Callback };
                const eventData = { Actions: [action], Data: obj, Event: ev };
                this.next.emit(eventData);
                return;
            }
            if ((_d = this.handler) === null || _d === void 0 ? void 0 : _d.callback) {
                this.handler.callback(ev);
            }
            if (typeof ev === 'string') {
                this.formSubject.next(ev);
                this.publishDictionary();
            }
            this.templateService.publish(ev);
        });
    }
    btnListener(key, button) {
        if (button.btnType === "submit") {
            if (!this.Form.valid)
                return;
        }
        const act = (button === null || button === void 0 ? void 0 : button.action) || {};
        // add this before hasOwnProperty check
        if (!act === undefined) {
            this.onBtnClick.emit({ key: key, data: this.Form.getRawValue() });
            return;
        }
        // end
        if (!act.hasOwnProperty('type')) {
            this.onBtnClick.emit({ key: key, data: this.Form.getRawValue() });
            return;
        }
        const action = button.action;
        this.actionResult(action);
    }
    navigateUrl(nextUrl, params, state) {
        const extras = {
            queryParams: params,
            state: state
        };
        this.router.navigateByUrl(nextUrl, extras);
    }
    objectTransformer(obj, excludes, data) {
        const props = [];
        // Start Object transformer
        const params = obj || [];
        for (const param of params) {
            props.push({ property: param.propName, value: param.propValue });
        }
        const val = !!data ? data : this.getFormValue(true);
        let result = props.length === 0 ? val : this.transformToObject({ arr: props, data: data });
        if (result.hasOwnProperty('_form')) {
            const value = val;
            const { _form } = result, rest = __rest(result, ["_form"]);
            result = Object.assign(Object.assign({}, rest), value);
        }
        if (result.hasOwnProperty('[form]')) {
            const value = [...result["[form]"]];
            return value;
        }
        // end of object transformer
        // Start exclude properties
        const deletes = excludes || [];
        for (const prop of deletes) {
            delete result[prop.key];
        }
        // end of exclude properties
        return result;
    }
    actionResult(action, ev) {
        var _a;
        switch (action.type) {
            case ActionType.Link:
                this.linkAction(action);
                break;
            case ActionType.Function:
                this.funAction(action);
                break;
            case ActionType.Http:
                this.httpAction(action);
                break;
            case ActionType.Modal:
                this.modalAction(action);
                break;
            case ActionType.Switch:
                this.switchAction(action);
                break;
            case ActionType.Toaster:
                this.toasterAction(action);
                break;
            case ActionType.Confirm:
                this.confirmAction(action);
                break;
            case ActionType.Reload:
                window.location.reload();
                break;
            case ActionType.LocalStorage:
                this.localStorageAction(action);
                break;
            case ActionType.Callback:
                if (this.isStepper) {
                    const eventData = { Actions: [action], Data: this.dicts, Event: ev };
                    this.next.emit(eventData);
                    break;
                }
                if ((_a = this.handler) === null || _a === void 0 ? void 0 : _a.callback) {
                    this.logger.log(`callback self implment called!`, ev);
                    this.handler.callback(ev);
                }
                else {
                    this.logger.log(`callback not implemented! no handler for key ${ev.Key}`);
                }
                break;
            default:
                console.warn(`Action type ${action.type} not supported yet!`);
                break;
        }
    }
    localStorageAction(action) {
        var _a;
        const keys = action.key.split('.');
        const cache = this.pageCache[keys[0]];
        this.queryParams = (cache === null || cache === void 0 ? void 0 : cache.queryParams) || this.queryParams;
        let result;
        switch (action.mode) {
            case 'add':
                // Start Object transformer
                result = this.objectTransformer(action === null || action === void 0 ? void 0 : action.mapObj, action === null || action === void 0 ? void 0 : action.excObj);
                // end of object transformer
                this.LocalStorage.createOrUpdate(action.key, result);
                this.back(action.backUrl);
                break;
            case 'edit':
                // Start Object transformer
                result = this.objectTransformer(action === null || action === void 0 ? void 0 : action.mapObj, action === null || action === void 0 ? void 0 : action.excObj);
                // end of object transformer
                this.LocalStorage.createOrUpdate(action.key, result, 0, (_a = this.dicts) === null || _a === void 0 ? void 0 : _a.beforeUpdate);
                this.back(action.backUrl);
                break;
            case 'delete':
                const keys = action.key.split(';');
                for (const key of keys) {
                    this.LocalStorage.remove(key);
                }
                break;
            case 'clearAll':
                this.LocalStorage.clear();
                break;
        }
    }
    confirmAction(action) {
        const _dicts = {
            envi: {},
        };
        Object.assign(_dicts, this.dicts);
        Object.assign(_dicts.envi, this.templateService.envConfig);
        const message = this.textManipulation(action.message, _dicts);
        if (confirm(message)) {
            this.actionResult(action.result);
        }
    }
    linkAction(action) {
        var _a;
        const target = action.target;
        let params = {};
        const args = Object.keys(action.params).length === 0 ? [] : action.params;
        for (const arg of args) {
            params[arg.propName] = this.parseValue(this.dicts, arg.propValue);
        }
        let transformedPath = action.path;
        if (this.templateService.navConstant !== undefined) {
            transformedPath = (_a = this.templateService.navConstant[action.path]) !== null && _a !== void 0 ? _a : action.path;
        }
        // Transformed query params to safe query params
        const query = this.ngxRouter.createQueryParams(params);
        if (target === '_self') {
            this.router.navigate([transformedPath], { queryParams: query });
            return;
        }
        const baseUrl = (action === null || action === void 0 ? void 0 : action.environment) ? action.environment : window.location.href;
        const finalUrl = this.buildUrl(baseUrl, transformedPath, query);
        this.openUrl(finalUrl, action.target);
    }
    modalAction(action) {
        var e_3, _a;
        return __awaiter(this, void 0, void 0, function* () {
            let component;
            if (!action.isTemplate) {
                component = this.templateService.container.getComponent(action.component);
            }
            else {
                component = UcTemplateComponent;
            }
            const config = new MatDialogConfig();
            config.id = 'role-dialog';
            config.width = `${action.width}%`;
            config.backdropClass = action === null || action === void 0 ? void 0 : action.backdropClass;
            config.disableClose = true;
            config.maxHeight = '80vh';
            if (action["isSheet"]) {
                config.backdropClass = "";
                config.position = {
                    right: "0px"
                };
                config.panelClass = ['animate__animated', 'animate__slideInRight'];
                config.height = "100vh";
                config.maxHeight = '';
            }
            let data = {};
            try {
                for (var _b = __asyncValues(action.params), _c; _c = yield _b.next(), !_c.done;) {
                    const param = _c.value;
                    if (param.propValue.includes("formRaw")) { // ensure formRaw already defined on dicts
                        if (this.dicts.formRaw === undefined)
                            this.logger.log("waiting for formRaw to be created...");
                        yield this.waitFor(_ => this.dicts.formRaw != undefined);
                    }
                    data[param.propName] = this.parseValue(this.dicts, param.propValue);
                }
            }
            catch (e_3_1) { e_3 = { error: e_3_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) yield _a.call(_b);
                }
                finally { if (e_3) throw e_3.error; }
            }
            config.data = data;
            this.dialogRef = this.dialog.open(component, config);
            let dialogSubmitSubscription = [];
            if (action.isTemplate) {
                this.dialogRef.componentInstance['pageName'] = action.component;
                this.dialogRef.componentInstance['isDialog'] = true;
                this.dialogRef.componentInstance['dialogRef'] = this.dialogRef;
                this.dialogRef.componentInstance['handler'] = this.handler;
                this.dialogRef.componentInstance['notify'] = this.notify;
                dialogSubmitSubscription.push(this.dialogRef.componentInstance['notifyUpdateViewFileUpload'].subscribe(ev => {
                    this.updateViewFileDocLength(ev);
                }));
                dialogSubmitSubscription.push(this.dialogRef.componentInstance['onFormCreated'].subscribe(ev => {
                    this.onFormCreated.emit(ev);
                }));
            }
            const refreshFrom = (action === null || action === void 0 ? void 0 : action.refreshFrom) || '';
            const affectedTable = (action === null || action === void 0 ? void 0 : action.affectedTable) || '';
            const tableObj = this.templateObj.component.find(x => x.id === affectedTable);
            this.dialogRef.afterClosed().subscribe(result => {
                this.onDismissModal.emit({ result });
                dialogSubmitSubscription.forEach(item => {
                    item.unsubscribe();
                });
                if (result === undefined || result === "" || result === null)
                    return;
                if (refreshFrom === '') {
                    return;
                }
                const _data = (result === null || result === void 0 ? void 0 : result.data) || null;
                const _result = this.objectTransformer(action === null || action === void 0 ? void 0 : action.mapObj, action === null || action === void 0 ? void 0 : action.excObj, _data);
                this.notifyUpdateTable.emit({
                    id: affectedTable,
                    component: tableObj,
                    option: {
                        isAdd: result === null || result === void 0 ? void 0 : result.isModeAdd,
                        dataBefore: data === null || data === void 0 ? void 0 : data.RowObj,
                        dataAfter: _result
                    }
                });
            });
        });
    }
    funAction(action) {
        if (this.isStepper) {
            this.dicts = Object.assign(this.dicts, { formValid: this.Form.valid });
            const eventData = { Actions: [action], Data: this.dicts };
            this.next.emit(eventData);
            return;
        }
        let params = {};
        const args = Object.keys(action.params).length === 0 ? [] : action.params;
        for (const arg of args) {
            params[arg.propName] = arg.propValue;
        }
        const config = {
            target: action.target,
            alias: action.alias,
            methodName: action.methodName,
            args: params
        };
        this.invokeFunction(config);
    }
    httpAction(action) {
        var _a;
        if (!!((_a = this.templateObj) === null || _a === void 0 ? void 0 : _a.isOverrideSubmit) && this.LocalStorage.size > 0) {
            // Clear persistent page data
            this.LocalStorage.clear();
        }
        // let props: PropertyValue[] = [];
        const onError = action.onError;
        const onSuccess = Object.keys(action.onSuccess).length === 0 ? [] : action.onSuccess;
        const params = Object.keys(action.reqObj).length === 0 ? [] : action.reqObj;
        const mapData = (action === null || action === void 0 ? void 0 : action.mapResToDict) || [];
        // for (const param of params) {
        //   props.push({property: param.propName, value: param.propValue});
        // }
        let jsonRequest = this.objectTransformer(params, action === null || action === void 0 ? void 0 : action.excObj);
        // Check is json request have _form property
        // if (jsonRequest.hasOwnProperty('_form')) {
        //   const value = this.getFormValue();
        //   const { _form, ...rest } = jsonRequest as any;
        //   jsonRequest = { ...rest, ...value };
        // }
        const serviceUrl = this.getServiceUrl(action.environment, action.path);
        this.http.post(serviceUrl, jsonRequest, AdInsConstant.SpinnerOptions).subscribe(res => {
            this.dicts = Object.assign(this.dicts, res);
            this.publishDictionary();
            // Compile action result after success calling request
            const params = [];
            for (const param of mapData) {
                params.push({ property: param === null || param === void 0 ? void 0 : param.propName, value: param === null || param === void 0 ? void 0 : param.propValue, isFromDict: true });
            }
            const addData = this.transformToObject({ arr: params });
            const eventData = { Actions: onSuccess, Data: Object.assign(Object.assign({}, res), addData) };
            if (this.isDialog) {
                this.dialogRef.close(eventData);
                return;
            }
            if (this.isStepper) {
                this.next.emit(eventData);
                return;
            }
            this.onNext(eventData);
        }, error => {
            this.logger.log(`error on calling http request (${action.path})`, error);
            this.toasterAction(onError);
        });
    }
    onNext(ev) {
        if (ev === null || ev === void 0 ? void 0 : ev.Data) {
            this.dicts = Object.assign(this.dicts, ev.Data);
        }
        for (const next of ev.Actions) {
            const conditions = next.hasOwnProperty('conditions') ? next.conditions : []; //Object.keys(next?.conditions).length === 0 ? [] : next.conditions;
            const valid = this.switchCase(conditions);
            if (!valid) {
                continue;
            }
            this.actionResult((next === null || next === void 0 ? void 0 : next.result) || next, ev.Event || {});
        }
    }
    onDictionary(data) {
        this.dicts = Object.assign(this.dicts, data);
    }
    switchAction(action) {
        const cases = Object.keys(action.cases).length === 0 ? [] : action.cases;
        const breakIfFound = !!(action === null || action === void 0 ? void 0 : action.breakIfFound);
        for (const _case of cases) {
            const valid = this.switchCase(_case.conditions);
            if (!valid) {
                continue;
            }
            this.actionResult(_case.result);
            if (breakIfFound) {
                break;
            }
        }
    }
    toasterAction(action) {
        const message = action.message;
        if (!message) {
            return;
        }
        const mode = !!(action === null || action === void 0 ? void 0 : action.mode) ? action.mode : 'error';
        const _dicts = {
            envi: {},
        };
        Object.assign(_dicts, this.dicts);
        Object.assign(_dicts.envi, this.templateService.envConfig);
        const transformMessage = this.textManipulation(message, _dicts); //this.isStringManipulation(message) ? this.transformStringValue(message, this.dicts) : message;
        switch (mode) {
            case 'success':
                this.toastr.successMessage(transformMessage);
                break;
            case 'error':
                this.toastr.errorMessage(transformMessage);
                break;
            case 'warning':
                this.toastr.warningMessage(transformMessage);
                break;
            default:
                this.toastr.infoMessage(transformMessage);
                break;
        }
    }
    baseUrl(environment) {
        return this.templateService.envConfig[environment];
    }
    getValue(value) {
        let result = this.parseValue(this.dicts, value);
        if (typeof result === "string") {
            if (result === '') {
                return result;
            }
            if (result.toLowerCase() === 'null') {
                return "";
            }
            if (result.startsWith("00")) {
                return result;
            }
            if (result === "true" || result === "false") {
                result = value === "true";
            }
            else if (!isNaN(Number(value))) {
                result = Number(value);
            }
        }
        return result;
    }
    switchCase(conditions) {
        var _a, _b;
        let result = true;
        const conds = conditions || [];
        for (const criteria of conds) {
            const _pv = this.parseValue(this.dicts, (_a = criteria === null || criteria === void 0 ? void 0 : criteria.property) !== null && _a !== void 0 ? _a : "");
            const _gv = this.getValue((_b = criteria === null || criteria === void 0 ? void 0 : criteria.value) !== null && _b !== void 0 ? _b : "");
            if (criteria.restriction === 'EQ') {
                if (_pv === _gv) {
                    result = true;
                }
                else {
                    result = false;
                    break;
                }
            }
            else if (criteria.restriction === 'NEQ') {
                if (_pv !== _gv) {
                    result = true;
                }
                else {
                    result = false;
                    break;
                }
            }
            else if (criteria.restriction === 'GT') {
                if (_pv > _gv) {
                    result = true;
                }
                else {
                    result = false;
                    break;
                }
            }
            else if (criteria.restriction === 'GTE') {
                if (_pv >= _gv) {
                    result = true;
                }
                else {
                    result = false;
                    break;
                }
            }
            else if (criteria.restriction === 'LT') {
                if (_pv < _gv) {
                    result = true;
                }
                else {
                    result = false;
                    break;
                }
            }
            else if (criteria.restriction === 'LTE') {
                if (_pv <= _gv) {
                    result = true;
                }
                else {
                    result = false;
                    break;
                }
            }
            else if (criteria.restriction === 'IN') {
                const values = _pv;
                if (values.includes(_gv)) {
                    result = true;
                }
                else {
                    result = false;
                    break;
                }
            }
            else if (criteria.restriction === 'NOTIN') {
                const values = _pv;
                if (!values.includes(_gv)) {
                    result = true;
                }
                else {
                    result = false;
                    break;
                }
            }
            else if (criteria.restriction === 'IFFOUND') {
                const values = _pv;
                if (values !== criteria.property) {
                    result = true;
                }
                else {
                    result = false;
                    break;
                }
            }
            else if (criteria.restriction === 'IFNOTFOUND') {
                const values = _pv;
                if (values === criteria.property) {
                    result = true;
                }
                else {
                    result = false;
                    break;
                }
            }
            else {
                result = false;
                break;
            }
        }
        return result;
    }
    isBtnVisible(button) {
        const conditions = button.conditions || [];
        return this.switchCase(conditions);
    }
    gotoAddPage() {
        var _a, _b, _c, _d, _e, _f;
        this.logger.log('AddLink', (_a = this.templateObj) === null || _a === void 0 ? void 0 : _a.addLink);
        let transformedPath = (_b = this.templateObj) === null || _b === void 0 ? void 0 : _b.addLink;
        if (this.templateService.navConstant !== undefined) {
            transformedPath = (_e = this.templateService.navConstant[(_d = (_c = this.templateObj) === null || _c === void 0 ? void 0 : _c.addLink) !== null && _d !== void 0 ? _d : ""]) !== null && _e !== void 0 ? _e : (_f = this.templateObj) === null || _f === void 0 ? void 0 : _f.addLink;
        }
        this.router.navigate([transformedPath], { queryParams: this.queryParams });
    }
    onChangeTab(id, ev) {
        this.selectedIdxChange.emit(ev);
        this.logger.log('Current Tab Idx', ev);
        setTimeout(() => {
            var _a;
            const tabs = ((_a = this.getComponent(id)) === null || _a === void 0 ? void 0 : _a.tablist) || [];
            const tab = this.TabList[id][ev] || []; //tabs[ev];
            const _idx = tabs.indexOf(tab);
            const panels = (tab === null || tab === void 0 ? void 0 : tab.panel) || [];
            for (const panel of panels) {
                if (panel === null || panel === void 0 ? void 0 : panel.isTemplate) {
                    return;
                }
                const componentId = `${id}-${panel === null || panel === void 0 ? void 0 : panel.content}-${_idx}-Tab`; //id+'-'+tab?.content+'-Tab';
                const component = this.templateService.container.getComponent(panel === null || panel === void 0 ? void 0 : panel.content);
                const element = document.getElementById(componentId);
                const factory = this.resolver.resolveComponentFactory(component);
                const componentRef = factory.create(this.injector, [], element);
                if (panel === null || panel === void 0 ? void 0 : panel.params) {
                    const params = panel === null || panel === void 0 ? void 0 : panel.params;
                    for (const param of params) {
                        componentRef.instance[param.propName] = this.parseValue(this.dicts, param.propValue); //this.queryParams[input[key]];
                    }
                }
                componentRef.instance['dicts'] = this.dicts;
                componentRef.instance['parentForm'] = this.Form;
                if (componentRef.instance.hasOwnProperty('data')) {
                    componentRef.instance['data'].subscribe(event => {
                        this.dicts = Object.assign(this.dicts, event);
                        this.publishDictionary();
                        this.logger.log('Received data: ', event);
                        this.logger.log('Updated dicts: ', this.dicts);
                    });
                }
                this.appRef.attachView(componentRef.hostView);
                this.cdr.detectChanges();
                this.logger.log('element', element);
            }
        }, 300);
    }
    compileTemp(id, componentObj) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11;
        this.listTempService.clearAll();
        if (this.dicts.listTemp) {
            this.dicts.listTemp = [];
        }
        const viewObj = componentObj.component;
        const ucTempPagingObj = new UcTempPagingObj(this.templateService);
        this.logger.log('addtotemp', viewObj);
        const hasEnvironment = !!(viewObj === null || viewObj === void 0 ? void 0 : viewObj.environment);
        ucTempPagingObj.dataInput = viewObj === null || viewObj === void 0 ? void 0 : viewObj.pagingInput;
        ucTempPagingObj.enviromentUrl = hasEnvironment ? this.templateService.envConfig[viewObj.environment] + '/' + viewObj.apiVersion :
            ucTempPagingObj.enviromentUrl;
        ucTempPagingObj.apiQryPaging = this.templateService.urlConstant.GetPagingObjectBySQL;
        ucTempPagingObj.templateService = this.templateService;
        ucTempPagingObj.useSafeUrl = (_b = (_a = this.templateService.environment) === null || _a === void 0 ? void 0 : _a.useSafeUrl) !== null && _b !== void 0 ? _b : false;
        // EXPERIMENTAL for BasePaging API
        // TODO: remove as late as 18/12/23 | dd/mm/yy
        if ((_d = (_c = this.templateService.environment) === null || _c === void 0 ? void 0 : _c.experimental) === null || _d === void 0 ? void 0 : _d.paging) {
            const _environmentUrl = ucTempPagingObj.enviromentUrl.substring(0, ucTempPagingObj.enviromentUrl.length - 3);
            const _qryPaging = ucTempPagingObj.dataInput.querystring.name;
            ucTempPagingObj.enviromentUrl = _environmentUrl + "/v1";
            ucTempPagingObj.apiQryPaging = `/BasePaging/${_qryPaging}`;
        }
        // END EXPERIMENTAL
        if (this.templateObj.component.length === 1) {
            ucTempPagingObj.dataInput['title'] = (_e = this.templateObj) === null || _e === void 0 ? void 0 : _e.title;
        }
        if (viewObj === null || viewObj === void 0 ? void 0 : viewObj.fromValue) {
            for (const _from of viewObj === null || viewObj === void 0 ? void 0 : viewObj.fromValue) {
                const fromValueObj = new FromValueObj();
                fromValueObj.property = _from;
                fromValueObj.value = this.parseValue(this.dicts, _from); //this.queryParams[_from];
                ucTempPagingObj.fromValue.push(fromValueObj);
            }
        }
        if (viewObj === null || viewObj === void 0 ? void 0 : viewObj.whereValue) {
            for (const _where of viewObj === null || viewObj === void 0 ? void 0 : viewObj.whereValue) {
                const whereValueObj = new FromValueObj();
                whereValueObj.property = _where;
                whereValueObj.value = this.parseValue(this.dicts, _where);
                ucTempPagingObj.whereValue.push(whereValueObj);
            }
        }
        const useIntegration = !!(viewObj === null || viewObj === void 0 ? void 0 : viewObj.useIntegration);
        if (useIntegration) {
            ucTempPagingObj.isJoinExAPI = true;
            let requestObj;
            const integrationObj = new IntegrationObj();
            if (viewObj.integrationObj.integrationType === 'apv') {
                requestObj = {
                    CategoryCode: (_g = (_f = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _f === void 0 ? void 0 : _f.requestObj) === null || _g === void 0 ? void 0 : _g.CategoryCode,
                    Username: (_h = this.userAccess) === null || _h === void 0 ? void 0 : _h.UserName,
                    RoleCode: (_j = this.userAccess) === null || _j === void 0 ? void 0 : _j.RoleCode,
                };
                if (viewObj.integrationObj.useOffice) {
                    Object.assign(requestObj, { OfficeCode: this.userAccess.OfficeCode });
                }
            }
            else {
                const UserAccess = JSON.parse(this.templateService.getCookie(this.cookieService, CommonConstant.USER_ACCESS));
                requestObj = {
                    TaskDefinitionKey: (_l = (_k = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _k === void 0 ? void 0 : _k.requestObj) === null || _l === void 0 ? void 0 : _l.TaskDefinitionKey,
                    OfficeRoleCodes: [UserAccess[CommonConstant.ROLE_CODE],
                        UserAccess[CommonConstant.OFFICE_CODE],
                        UserAccess[CommonConstant.ROLE_CODE] + "-" + UserAccess[CommonConstant.OFFICE_CODE]]
                };
                const processKey = (_o = (_m = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _m === void 0 ? void 0 : _m.requestObj) === null || _o === void 0 ? void 0 : _o.ProcessKey.split(';');
                if (processKey.length > 1) {
                    const _processKey = [];
                    for (const val of _processKey) {
                        _processKey.push(this.parseValue(this.dicts, val));
                    }
                    requestObj.ProcessKeys = _processKey;
                }
                else {
                    // requestObj.ProcessKey = viewObj?.integrationObj?.requestObj?.ProcessKey;
                    const _processKey = this.textManipulation((_q = (_p = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _p === void 0 ? void 0 : _p.requestObj) === null || _q === void 0 ? void 0 : _q.ProcessKey, this.dicts);
                    requestObj.ProcessKey = _processKey;
                }
                // check postfix addition for TaskDefinitionKey
                if (((_s = (_r = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _r === void 0 ? void 0 : _r.requestObj) === null || _s === void 0 ? void 0 : _s.TaskDefinitionKeyPostFix) !== undefined
                    && ((_u = (_t = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _t === void 0 ? void 0 : _t.requestObj) === null || _u === void 0 ? void 0 : _u.TaskDefinitionKeyPostFix) !== "") {
                    const taskDefinitionKeyPostFix = this.parseValue(this.dicts, (_w = (_v = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _v === void 0 ? void 0 : _v.requestObj) === null || _w === void 0 ? void 0 : _w.TaskDefinitionKeyPostFix);
                    requestObj.TaskDefinitionKey = ((_y = (_x = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _x === void 0 ? void 0 : _x.requestObj) === null || _y === void 0 ? void 0 : _y.TaskDefinitionKey) + taskDefinitionKeyPostFix;
                }
                // check postfix addition for ProcessKey
                if (((_0 = (_z = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _z === void 0 ? void 0 : _z.requestObj) === null || _0 === void 0 ? void 0 : _0.ProcessKeyPostFix) !== undefined
                    && ((_2 = (_1 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _1 === void 0 ? void 0 : _1.requestObj) === null || _2 === void 0 ? void 0 : _2.ProcessKeyPostFix) !== "") {
                    const processKeyPostFix = this.parseValue(this.dicts, (_4 = (_3 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _3 === void 0 ? void 0 : _3.requestObj) === null || _4 === void 0 ? void 0 : _4.ProcessKeyPostFix);
                    if ((requestObj === null || requestObj === void 0 ? void 0 : requestObj.ProcessKeys) !== undefined && (requestObj === null || requestObj === void 0 ? void 0 : requestObj.ProcessKeys.length) > 0) {
                        requestObj.ProcessKeys.map((item) => item + processKeyPostFix);
                    }
                    else {
                        requestObj.ProcessKey = requestObj.ProcessKey + processKeyPostFix;
                    }
                }
            }
            const _integrationBaseUrl = this.envi[(_5 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _5 === void 0 ? void 0 : _5.baseUrl];
            const _integrationApiPath = this.templateService.urlConstant[(_6 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _6 === void 0 ? void 0 : _6.apiPath] || ((_7 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _7 === void 0 ? void 0 : _7.apiPath);
            integrationObj.baseUrl = _integrationApiPath;
            if (_integrationBaseUrl !== undefined) {
                integrationObj.baseUrl = _integrationBaseUrl + _integrationApiPath;
            }
            integrationObj.leftColumnToJoin = (_8 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _8 === void 0 ? void 0 : _8.leftColumnToJoin;
            integrationObj.rightColumnToJoin = (_9 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _9 === void 0 ? void 0 : _9.rightColumnToJoin;
            integrationObj.joinType = (_10 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _10 === void 0 ? void 0 : _10.joinType;
            integrationObj.requestObj = requestObj;
            ucTempPagingObj.integrationObj = integrationObj;
        }
        const arrCrit = [];
        if (viewObj === null || viewObj === void 0 ? void 0 : viewObj.criteria) {
            for (const criteria of viewObj.criteria) {
                // Support conditions in criteria
                const conditions = (criteria === null || criteria === void 0 ? void 0 : criteria.conditions) || [];
                const isValid = this.switchCase(conditions);
                if (!isValid) {
                    continue;
                }
                // end of support conditions criteria
                const critObj = new CriteriaObj();
                critObj.restriction = criteria === null || criteria === void 0 ? void 0 : criteria.restriction;
                critObj.propName = criteria === null || criteria === void 0 ? void 0 : criteria.propName;
                if ((criteria === null || criteria === void 0 ? void 0 : criteria.restriction.toUpperCase()) === 'IN' || (criteria === null || criteria === void 0 ? void 0 : criteria.restriction.toUpperCase()) === 'NOTIN') {
                    critObj.listValue = [];
                    const values = criteria === null || criteria === void 0 ? void 0 : criteria.value.split(';');
                    for (const val of values) {
                        if (!val) {
                            continue;
                        }
                        critObj.listValue.push(this.parseValue(this.dicts, val));
                    }
                    critObj.listValue = critObj.listValue.flat();
                }
                else {
                    critObj.value = this.parseValue(this.dicts, criteria === null || criteria === void 0 ? void 0 : criteria.value);
                }
                arrCrit.push(critObj);
            }
        }
        ucTempPagingObj.dicts = this.dicts;
        ucTempPagingObj.addCritInput = arrCrit;
        ucTempPagingObj.isReady = true;
        this.listIds.push(id);
        this.listMapComponent.set(id, { type: componentObj.type, component: ucTempPagingObj, conditions: (_11 = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _11 === void 0 ? void 0 : _11.conditions });
    }
    compileStepper(id, componentObj) {
        var _a, _b, _c, _d;
        this.logger.log(`container:${id}`, componentObj);
        const conditions = ((_a = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _a === void 0 ? void 0 : _a.conditions) || [];
        if (!this.switchCase(conditions)) {
            return;
        }
        this.listIds.push(id);
        this.listMapComponent.set(id, { type: componentObj.type, component: Object.assign({ id: id }, componentObj.component), conditions: conditions });
        this.AppStep = {};
        this.StepperObj = Object.assign({ id: id }, componentObj.component);
        for (const tab of (_b = this.StepperObj) === null || _b === void 0 ? void 0 : _b.tablist) {
            this.AppStep[(_c = tab === null || tab === void 0 ? void 0 : tab.step) === null || _c === void 0 ? void 0 : _c.code] = (_d = tab === null || tab === void 0 ? void 0 : tab.step) === null || _d === void 0 ? void 0 : _d.index;
        }
        this.logger.log('stepper', this.StepperObj);
        this.logger.log('components', this.listMapComponent);
    }
    compileTabs(id, componentObj) {
        var e_4, _a;
        var _b, _c, _d, _e;
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.log('debug tabs', componentObj.component);
            const conditions = ((_b = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _b === void 0 ? void 0 : _b.conditions) || [];
            if (!this.switchCase(conditions)) {
                return;
            }
            const tablist = ((_c = componentObj.component) === null || _c === void 0 ? void 0 : _c.tablist) || [];
            this.listIds.push(id);
            this.listMapComponent.set(id, {
                type: componentObj.type,
                component: componentObj.component,
                conditions: (_d = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _d === void 0 ? void 0 : _d.conditions
            });
            let i = 0;
            const Tabs = [];
            try {
                for (var tablist_1 = __asyncValues(tablist), tablist_1_1; tablist_1_1 = yield tablist_1.next(), !tablist_1_1.done;) {
                    const tab = tablist_1_1.value;
                    const visible = this.switchCase(((_e = tab === null || tab === void 0 ? void 0 : tab.panel[0]) === null || _e === void 0 ? void 0 : _e.conditions) || []);
                    if (visible) {
                        Tabs.push(tab);
                        this.TabList[id] = Tabs;
                    }
                    const panels = (tab === null || tab === void 0 ? void 0 : tab.panel) || [];
                    for (const panel of panels) {
                        if (!(panel === null || panel === void 0 ? void 0 : panel.isTemplate)) {
                            const input = {};
                            for (const param of panel.params) {
                                input[param.propName] = param.propValue;
                            }
                            const containerObj = {
                                conditions: panel === null || panel === void 0 ? void 0 : panel.conditions,
                                container: {
                                    key: `${id}-${panel === null || panel === void 0 ? void 0 : panel.content}-${i}-Tab`,
                                    className: panel === null || panel === void 0 ? void 0 : panel.content,
                                    cssClass: "",
                                    input: input
                                },
                                id: `${id}-${panel === null || panel === void 0 ? void 0 : panel.content}-${i}`
                            };
                            yield this.compile([containerObj], 'tabs');
                        }
                    }
                    i = ++i;
                }
            }
            catch (e_4_1) { e_4 = { error: e_4_1 }; }
            finally {
                try {
                    if (tablist_1_1 && !tablist_1_1.done && (_a = tablist_1.return)) yield _a.call(tablist_1);
                }
                finally { if (e_4) throw e_4.error; }
            }
        });
    }
    chooseStep(idx) {
        this.StepperView.to(idx);
    }
    compileContainer(id, componentObj, recompile = false) {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            let component, componentId;
            const containerObj = componentObj.component;
            componentId = containerObj === null || containerObj === void 0 ? void 0 : containerObj.key;
            const conditions = (containerObj === null || containerObj === void 0 ? void 0 : containerObj.conditions) || [];
            for (const criteria of conditions) {
                if (!(criteria === null || criteria === void 0 ? void 0 : criteria.property.includes('form.')) && !(criteria === null || criteria === void 0 ? void 0 : criteria.property.includes('formRaw.'))) {
                    continue;
                }
                const keys = criteria === null || criteria === void 0 ? void 0 : criteria.property.split('.');
                const observable = keys[keys.length - 1];
                const subscriber = this.controlObservable[observable] === undefined ? [] : this.controlObservable[observable];
                if (subscriber.indexOf(id) === -1) {
                    subscriber.push(id);
                }
                this.controlObservable[observable] = subscriber;
                this.logger.log(`${observable} has subscriber: `, this.controlObservable[observable]);
            }
            const isForm = containerObj === null || containerObj === void 0 ? void 0 : containerObj.hasForm;
            if (isForm) {
                this.componentTypes.push(componentObj.type + 'form');
            }
            if (containerObj === null || containerObj === void 0 ? void 0 : containerObj.className) {
                component = this.templateService.container.getComponent(containerObj === null || containerObj === void 0 ? void 0 : containerObj.className);
                this.logger.log('ModuleX', component);
            }
            else {
                component = (_a = this.container.find(x => x.key === componentId)) === null || _a === void 0 ? void 0 : _a.component;
            }
            if (containerObj === null || containerObj === void 0 ? void 0 : containerObj.cssClass) {
                this.customClass[componentId] = containerObj.cssClass;
            }
            this.logger.log(`container:${id}`, componentObj);
            if (!recompile) {
                if (((_b = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _b === void 0 ? void 0 : _b.type) === 'page')
                    this.listIds.push(id);
                this.listMapComponent.set(id, { type: componentObj.type, component: { key: componentId }, conditions: (_c = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _c === void 0 ? void 0 : _c.conditions });
                this.logger.log('components', this.listMapComponent);
            }
            if (!component) {
                return;
            }
            if (!this.switchCase(conditions) && this.isDialog) {
                return;
            }
            setTimeout(() => {
                var _a, _b;
                const element = document.getElementById(componentId);
                const factory = this.resolver.resolveComponentFactory(component);
                const componentRef = factory.create(this.injector, [], element);
                if ((_a = componentObj.component) === null || _a === void 0 ? void 0 : _a.input) {
                    const input = (_b = componentObj.component) === null || _b === void 0 ? void 0 : _b.input;
                    Object.keys(input).forEach(key => {
                        componentRef.instance[key] = this.parseValue(this.dicts, input[key]); //_getValue(input, input[key]); //this.queryParams[input[key]];
                    });
                }
                componentRef.instance['dicts'] = this.dicts;
                componentRef.instance['parentForm'] = this.Form;
                // Setup next event handler
                if (componentRef.instance.hasOwnProperty('next')) {
                    componentRef.instance['next'].subscribe(event => {
                        this.onNext(event);
                    });
                }
                if (componentRef.instance.hasOwnProperty('handler')) {
                    componentRef.instance['next'].subscribe(event => {
                        this.onNext(event);
                    });
                }
                if (componentRef.instance.hasOwnProperty('data')) {
                    componentRef.instance['data'].subscribe(event => {
                        this.dicts = Object.assign(this.dicts, event);
                        this.publishDictionary();
                        this.logger.log('Received data: ', event);
                        this.logger.log('Updated dicts: ', this.dicts);
                    });
                }
                // deprecated set value
                // if (isForm) {
                //   componentRef.instance['parentForm'] = this.Form;
                // }
                this.appRef.attachView(componentRef.hostView);
                this.cdr.detectChanges();
                this.logger.log('element', element);
            }, 10);
        });
    }
    compileFormArray(id, componentObj) {
        var e_5, _a;
        var _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q;
        return __awaiter(this, void 0, void 0, function* () {
            const isFromApi = componentObj.component.hasOwnProperty('isFromApi') === false ? true : componentObj.component.isFromApi;
            const inputFormArray = new InputFormArrayObj(this.templateService);
            inputFormArray.formId = ((_b = componentObj.component) === null || _b === void 0 ? void 0 : _b.formGroupName) || `FormId${id}`;
            inputFormArray.title = (_c = componentObj.component) === null || _c === void 0 ? void 0 : _c.title;
            inputFormArray.IsSubsection = (_d = componentObj.component) === null || _d === void 0 ? void 0 : _d.isSubsection;
            inputFormArray.formInput = (_e = componentObj.component) === null || _e === void 0 ? void 0 : _e.formInput;
            inputFormArray.formJson = (_f = componentObj.component) === null || _f === void 0 ? void 0 : _f.formJson;
            inputFormArray.dicts = this.dicts;
            inputFormArray.navigationConst = this.templateService.navConstant;
            inputFormArray.CustomObjName = isFromApi ? (_g = componentObj.component) === null || _g === void 0 ? void 0 : _g.customObjName : (_h = componentObj.component) === null || _h === void 0 ? void 0 : _h.resultData;
            inputFormArray.isPageFromService = this.environment.isPageFromService;
            inputFormArray.pagesUrl = this.envi.PagesURL;
            const isModeAdd = (_j = componentObj.component) === null || _j === void 0 ? void 0 : _j.isModeAdd;
            if (isModeAdd !== undefined) {
                this.IsAdd = isModeAdd;
            }
            const queries = this.ngxRouter.getQueryParams(this.queryParams);
            if (queries && queries.hasOwnProperty('mode')) {
                if (queries['mode'] === 'edit') {
                    this.IsAdd = false;
                }
            }
            this.IsAdd = ((_k = this.dicts) === null || _k === void 0 ? void 0 : _k.mode) === undefined ? this.IsAdd : this.dicts.mode !== 'edit';
            if (!this.IsAdd) {
                let act = [];
                if ((_l = componentObj.component) === null || _l === void 0 ? void 0 : _l.getData.hasOwnProperty("action")) {
                    act = componentObj.component.getData.action;
                }
                inputFormArray.onloadAct = act;
                if (componentObj.component.conditionalDel !== undefined) {
                    inputFormArray.conditionalDel = componentObj.component.conditionalDel;
                }
            }
            // Default value form object
            const datasource = {};
            const objectKey = inputFormArray.CustomObjName || "ReturnObject";
            datasource[objectKey] = this.dicts[objectKey] || [];
            inputFormArray.ColumnObject = datasource;
            const lookups = (_m = inputFormArray.formInput) === null || _m === void 0 ? void 0 : _m.bodyList.filter(x => x.Type === 'LOOKUP');
            try {
                for (var lookups_1 = __asyncValues(lookups), lookups_1_1; lookups_1_1 = yield lookups_1.next(), !lookups_1_1.done;) {
                    const lookup = lookups_1_1.value;
                    // this.setLookupObject(lookup);
                    yield this.setLookupObject(lookup, true);
                }
            }
            catch (e_5_1) { e_5 = { error: e_5_1 }; }
            finally {
                try {
                    if (lookups_1_1 && !lookups_1_1.done && (_a = lookups_1.return)) yield _a.call(lookups_1);
                }
                finally { if (e_5) throw e_5.error; }
            }
            const detail = (_o = componentObj.component) === null || _o === void 0 ? void 0 : _o.getData;
            if (!this.IsAdd && (detail === null || detail === void 0 ? void 0 : detail.environment)) {
                const serviceUrl = this.getServiceUrl(detail === null || detail === void 0 ? void 0 : detail.environment, detail === null || detail === void 0 ? void 0 : detail.apiPath);
                const reqObjRaw = detail === null || detail === void 0 ? void 0 : detail.reqObj;
                const reqBody = {};
                const x = (val, object) => {
                    if (typeof val === 'boolean') {
                        return val;
                    }
                    if (typeof val === 'string' && val.includes(';')) {
                        const values = val.split(';');
                        const listValue = [];
                        for (const v of values) {
                            if (v === "")
                                continue;
                            listValue.push(this.parseValue(this.dicts, v));
                        }
                        return listValue;
                    }
                    return this.parseValue(object, val);
                };
                Object.keys(reqObjRaw).forEach(k => {
                    reqBody[k] = x(reqObjRaw[k], this.dicts);
                });
                const req = this.http.post(serviceUrl, reqBody);
                inputFormArray.ColumnObject = yield lastValueFrom(req);
                inputFormArray.isReady = true;
            }
            else {
                inputFormArray.isReady = true;
            }
            this.logger.log('formarray component', inputFormArray);
            this.listIds.push(id);
            this.listMapComponent.set(id, { type: componentObj.type,
                component: Object.assign({ canAdd: !!((_p = componentObj.component) === null || _p === void 0 ? void 0 : _p.canAdd) }, inputFormArray),
                conditions: (_q = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _q === void 0 ? void 0 : _q.conditions });
        });
    }
    compileFileUpload(id, componentObj) {
        var _a;
        const component = componentObj.component;
        const inputObj = new FileUploadObj();
        inputObj.label = component === null || component === void 0 ? void 0 : component.label;
        inputObj.propName = component === null || component === void 0 ? void 0 : component.variable;
        inputObj.docuploadType = component === null || component === void 0 ? void 0 : component.docuploadType;
        inputObj.limitFileSize = (component === null || component === void 0 ? void 0 : component.limitFileSize) || 1024;
        inputObj.allowedExt = component === null || component === void 0 ? void 0 : component.allowedExt;
        inputObj.isRequired = (component === null || component === void 0 ? void 0 : component.isRequired) || false;
        inputObj.metadata = (component === null || component === void 0 ? void 0 : component.metadata) || [];
        inputObj.isSubsection = component === null || component === void 0 ? void 0 : component.isSubsection;
        inputObj.subsectionTitle = component === null || component === void 0 ? void 0 : component.subsectionTitle;
        if (this.dicts.hasOwnProperty('RowObj')) {
            const obj = {};
            obj[inputObj.propName] = this.dicts.RowObj[inputObj.propName];
            this.dicts = Object.assign(this.dicts, { beforeUpdate: obj });
        }
        this.listIds.push(id);
        this.listMapComponent.set(id, { type: componentObj.type, component: inputObj, conditions: (_a = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _a === void 0 ? void 0 : _a.conditions });
    }
    compileViewFileUpload(id, componentObj) {
        var _a, _b, _c, _d;
        const component = componentObj.component;
        const inputObj = new ViewFileUploadObj();
        inputObj.code = component === null || component === void 0 ? void 0 : component.code;
        inputObj.fullPath = this.getServiceUrl(component === null || component === void 0 ? void 0 : component.environment, component === null || component === void 0 ? void 0 : component.apiPath);
        inputObj.fullPathDownload = this.getServiceUrl(component === null || component === void 0 ? void 0 : component.environment, component === null || component === void 0 ? void 0 : component.apiPathDownload);
        inputObj.metadata = (component === null || component === void 0 ? void 0 : component.metadata) || [];
        inputObj.isSubsection = component === null || component === void 0 ? void 0 : component.isSubsection;
        inputObj.subsectionTitle = component === null || component === void 0 ? void 0 : component.subsectionTitle;
        inputObj.canDelete = (_a = component === null || component === void 0 ? void 0 : component.canDelete) !== null && _a !== void 0 ? _a : false;
        inputObj.deletePath = this.getServiceUrl(component === null || component === void 0 ? void 0 : component.environment, (_b = component === null || component === void 0 ? void 0 : component.deleteApiPath) !== null && _b !== void 0 ? _b : "");
        inputObj.hideWhenEmpty = (_c = component === null || component === void 0 ? void 0 : component.hideWhenEmpty) !== null && _c !== void 0 ? _c : false;
        this.listIds.push(id);
        this.listMapComponent.set(id, { type: componentObj.type, component: inputObj, conditions: (_d = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _d === void 0 ? void 0 : _d.conditions });
    }
    compileUpload(id, componentObj) {
        var _a, _b, _c;
        const mUpload = componentObj.component;
        const uploadObj = new UcUploadObj(this.templateService);
        const _downloadTmpltOpt = (mUpload === null || mUpload === void 0 ? void 0 : mUpload.downloadTmpltOpt) || [];
        uploadObj.title = mUpload === null || mUpload === void 0 ? void 0 : mUpload.title;
        uploadObj.UploadTypeCode = mUpload === null || mUpload === void 0 ? void 0 : mUpload.uploadTypeCode;
        uploadObj.ErrorDownloadUrl = this.templateService.urlConstant[mUpload === null || mUpload === void 0 ? void 0 : mUpload.errorDownloadUrl] || (mUpload === null || mUpload === void 0 ? void 0 : mUpload.errorDownloadUrl);
        uploadObj.TemplateName = mUpload === null || mUpload === void 0 ? void 0 : mUpload.templateName;
        uploadObj.FileErrorName = mUpload === null || mUpload === void 0 ? void 0 : mUpload.fileErrorName;
        uploadObj.environmentUrl = (this.envi[mUpload === null || mUpload === void 0 ? void 0 : mUpload.environment] || uploadObj.environmentUrl) + "/v2";
        uploadObj.dataInput = mUpload === null || mUpload === void 0 ? void 0 : mUpload.pagingInput;
        uploadObj.downloadTmpltOpt = _downloadTmpltOpt.length == 0 ? uploadObj.downloadTmpltOpt : mUpload === null || mUpload === void 0 ? void 0 : mUpload.downloadTmpltOpt;
        uploadObj.formatsAllowed = (mUpload === null || mUpload === void 0 ? void 0 : mUpload.formatsAllowed) || uploadObj.formatsAllowed;
        if (mUpload === null || mUpload === void 0 ? void 0 : mUpload.useCustomApi) {
            const _envi = this.envi[mUpload === null || mUpload === void 0 ? void 0 : mUpload.customUploadEnvironment];
            const _apiPath = mUpload === null || mUpload === void 0 ? void 0 : mUpload.customUploadApiPath;
            uploadObj.url = _envi + _apiPath;
        }
        // EXPERIMENTAL for BasePaging API
        // TODO: remove as late as 18/12/23 | dd/mm/yy
        if ((_b = (_a = this.templateService.environment) === null || _a === void 0 ? void 0 : _a.experimental) === null || _b === void 0 ? void 0 : _b.paging) {
            const _environmentUrl = uploadObj.environmentUrl.substring(0, uploadObj.environmentUrl.length - 3);
            const _qryPaging = uploadObj.dataInput.querystring.name;
            uploadObj.environmentUrl = _environmentUrl + "/v1";
            uploadObj.apiQryPaging = `/BasePaging/${_qryPaging}`;
        }
        // END EXPERIMENTAL
        this.listIds.push(id);
        this.listMapComponent.set(id, { type: componentObj.type, component: uploadObj, conditions: (_c = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _c === void 0 ? void 0 : _c.conditions });
    }
    compileReport(id, componentObj) {
        var _a, _b, _c;
        const component = componentObj.component;
        const inputReportObj = new InputReportObj(this.templateService);
        inputReportObj.dataInput = component === null || component === void 0 ? void 0 : component.pagingInput;
        inputReportObj.ApiReportPath = component === null || component === void 0 ? void 0 : component.apiReportPath;
        if ((component === null || component === void 0 ? void 0 : component.apiEnvironmentUrl) != "" && (component === null || component === void 0 ? void 0 : component.apiEnvironmentUrl) != undefined && (component === null || component === void 0 ? void 0 : component.apiEnvironmentUrl) != null) {
            inputReportObj.EnvironmentUrl = this.envi[component === null || component === void 0 ? void 0 : component.apiEnvironmentUrl];
        }
        inputReportObj.useSubReport = component === null || component === void 0 ? void 0 : component.useSubReport;
        inputReportObj.subReport = (_a = component === null || component === void 0 ? void 0 : component.subReport) !== null && _a !== void 0 ? _a : {};
        if (inputReportObj.subReport.hasOwnProperty("useApi")) {
            if (inputReportObj.subReport.useApi) {
                const subReportEnviUrl = (_b = this.envi[inputReportObj.subReport.subReportEnviUrl]) !== null && _b !== void 0 ? _b : inputReportObj.subReport.subReportEnviUrl;
                inputReportObj.subReport.subReportUrl = subReportEnviUrl + inputReportObj.subReport.subReportPath;
            }
        }
        this.listIds.push(id);
        this.listMapComponent.set(id, { type: componentObj.type, component: inputReportObj, conditions: (_c = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _c === void 0 ? void 0 : _c.conditions });
    }
    compileGridView(id, componentObj) {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        return __awaiter(this, void 0, void 0, function* () {
            const tableObj = componentObj.component;
            const isFromApi = !!(tableObj === null || tableObj === void 0 ? void 0 : tableObj.isFromApi);
            const inputGridObj = new InputGridviewObj(this.templateService);
            inputGridObj.id = id;
            inputGridObj.isSubsection = tableObj === null || tableObj === void 0 ? void 0 : tableObj.isSubsection;
            inputGridObj.title = tableObj === null || tableObj === void 0 ? void 0 : tableObj.title;
            inputGridObj.dataInput = tableObj.tableInput;
            inputGridObj.listBtn = (tableObj === null || tableObj === void 0 ? void 0 : tableObj.listBtn) || [];
            inputGridObj.usePagination = (_a = tableObj === null || tableObj === void 0 ? void 0 : tableObj.usePagination) !== null && _a !== void 0 ? _a : true;
            inputGridObj.defaultChecked = (_b = tableObj === null || tableObj === void 0 ? void 0 : tableObj.defaultChecked) !== null && _b !== void 0 ? _b : false;
            inputGridObj.useSafeUrl = (_d = (_c = this.templateService.environment) === null || _c === void 0 ? void 0 : _c.useSafeUrl) !== null && _d !== void 0 ? _d : false;
            // Set Environment Delete
            const hasDeleteEnv = !!(tableObj === null || tableObj === void 0 ? void 0 : tableObj.deleteObj) && (tableObj === null || tableObj === void 0 ? void 0 : tableObj.deleteObj.hasOwnProperty('deleteEnvi'));
            if (hasDeleteEnv) {
                inputGridObj.deleteUrl = this.getServiceUrl((_e = tableObj === null || tableObj === void 0 ? void 0 : tableObj.deleteObj) === null || _e === void 0 ? void 0 : _e.deleteEnvi, (_f = tableObj === null || tableObj === void 0 ? void 0 : tableObj.deleteObj) === null || _f === void 0 ? void 0 : _f.deleteApiPath);
            }
            if (!isFromApi) {
                const data = tableObj.resultData === '' ? [] : (this.dicts[tableObj.resultData] || []);
                inputGridObj.serviceObj = { objName: tableObj.resultData };
                inputGridObj.resultData = { Data: data };
                inputGridObj.isReady = true;
            }
            else {
                const reqdetail = tableObj['getData'];
                const conditions = (reqdetail === null || reqdetail === void 0 ? void 0 : reqdetail.conditions) || [];
                const valid = this.switchCase(conditions);
                if (valid) {
                    const arrObj = [];
                    for (let param of reqdetail.reqObj) {
                        arrObj.push({ property: param === null || param === void 0 ? void 0 : param.propName, value: param === null || param === void 0 ? void 0 : param.propValue });
                    }
                    const reqObject = this.transformToObject({ arr: arrObj });
                    const serviceUrl = this.getServiceUrl(reqdetail === null || reqdetail === void 0 ? void 0 : reqdetail.environment, reqdetail.apiPath);
                    const objectName = (reqdetail === null || reqdetail === void 0 ? void 0 : reqdetail.customObjName) || 'ReturnObject';
                    inputGridObj.serviceObj = { serviceUrl: serviceUrl, payload: reqObject, objName: objectName };
                    this.http.post(serviceUrl, reqObject).subscribe(res => {
                        inputGridObj.resultData = { Data: res[objectName] };
                        inputGridObj.isReady = true;
                    });
                }
            }
            inputGridObj.isFromApi = isFromApi;
            inputGridObj.dicts = this.dicts;
            this.logger.log(`Table_${id}`, inputGridObj);
            if (((_g = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _g === void 0 ? void 0 : _g.type) === 'page')
                this.listIds.push(id);
            this.listMapComponent.set(id, { type: componentObj.type, component: inputGridObj, conditions: (_h = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _h === void 0 ? void 0 : _h.conditions });
        });
    }
    compilePaging(id, componentObj) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13;
        this.logger.log('compile', 'paging');
        const viewObj = componentObj.component;
        const ucPagingObj = new UcPagingObj(this.templateService);
        ucPagingObj.dataInput = viewObj === null || viewObj === void 0 ? void 0 : viewObj.pagingInput;
        let environmentUrl = ucPagingObj.enviromentUrl;
        if ((viewObj === null || viewObj === void 0 ? void 0 : viewObj.environment) && (viewObj === null || viewObj === void 0 ? void 0 : viewObj.environment) !== '') {
            environmentUrl = this.envi[viewObj === null || viewObj === void 0 ? void 0 : viewObj.environment] + '/' + (viewObj === null || viewObj === void 0 ? void 0 : viewObj.apiVersion);
        }
        ucPagingObj.enviromentUrl = environmentUrl;
        ucPagingObj.navigationConst = this.templateService.navConstant;
        ucPagingObj.useSafeUrl = (_b = (_a = this.templateService.environment) === null || _a === void 0 ? void 0 : _a.useSafeUrl) !== null && _b !== void 0 ? _b : false;
        // EXPERIMENTAL for BasePaging API
        // TODO: remove as late as 18/12/23 | dd/mm/yy
        if ((_d = (_c = this.templateService.environment) === null || _c === void 0 ? void 0 : _c.experimental) === null || _d === void 0 ? void 0 : _d.paging) {
            const _environmentUrl = ucPagingObj.enviromentUrl.substring(0, ucPagingObj.enviromentUrl.length - 3);
            const _qryPaging = ucPagingObj.dataInput.querystring.name;
            ucPagingObj.enviromentUrl = _environmentUrl + "/v1";
            ucPagingObj.apiQryPaging = `/BasePaging/${_qryPaging}`;
        }
        // END EXPERIMENTAL
        if (viewObj === null || viewObj === void 0 ? void 0 : viewObj.isUseCustomApi) {
            ucPagingObj.apiQryPaging = viewObj.customApiQryPaging;
        }
        // Fill paging page title in uc component
        if (this.templateObj.component.length === 1) {
            ucPagingObj.dataInput['title'] = (_e = this.templateObj) === null || _e === void 0 ? void 0 : _e.title;
        }
        // Set Environment Delete
        const hasDeleteEnv = !!(viewObj === null || viewObj === void 0 ? void 0 : viewObj.deleteObj) && (viewObj === null || viewObj === void 0 ? void 0 : viewObj.deleteObj.hasOwnProperty('deleteEnvi'));
        if (hasDeleteEnv) {
            ucPagingObj.deleteUrl = this.getServiceUrl((_f = viewObj === null || viewObj === void 0 ? void 0 : viewObj.deleteObj) === null || _f === void 0 ? void 0 : _f.deleteEnvi, (_g = viewObj === null || viewObj === void 0 ? void 0 : viewObj.deleteObj) === null || _g === void 0 ? void 0 : _g.deleteApiPath);
        }
        const arrCrit = [];
        if (viewObj === null || viewObj === void 0 ? void 0 : viewObj.criteria) {
            for (const criteria of viewObj.criteria) {
                // Support conditions in criteria
                const conditions = (criteria === null || criteria === void 0 ? void 0 : criteria.conditions) || [];
                const isValid = this.switchCase(conditions);
                if (!isValid) {
                    continue;
                }
                // end of support conditions criteria
                const critObj = new CriteriaObj();
                critObj.restriction = criteria === null || criteria === void 0 ? void 0 : criteria.restriction;
                critObj.propName = criteria === null || criteria === void 0 ? void 0 : criteria.propName;
                if ((criteria === null || criteria === void 0 ? void 0 : criteria.restriction.toUpperCase()) === 'IN' || (criteria === null || criteria === void 0 ? void 0 : criteria.restriction.toUpperCase()) === 'NOTIN') {
                    critObj.listValue = [];
                    const values = criteria === null || criteria === void 0 ? void 0 : criteria.value.split(';');
                    for (const val of values) {
                        if (!val) {
                            continue;
                        }
                        critObj.listValue.push(this.parseValue(this.dicts, val));
                    }
                    critObj.listValue = critObj.listValue.flat();
                }
                else {
                    critObj.value = this.parseValue(this.dicts, criteria === null || criteria === void 0 ? void 0 : criteria.value);
                }
                arrCrit.push(critObj);
            }
        }
        if (viewObj === null || viewObj === void 0 ? void 0 : viewObj.fromValue) {
            for (const _from of viewObj === null || viewObj === void 0 ? void 0 : viewObj.fromValue) {
                const fromValueObj = new FromValueObj();
                fromValueObj.property = _from;
                fromValueObj.value = this.parseValue(this.dicts, _from); //this.queryParams[_from];
                ucPagingObj.fromValue.push(fromValueObj);
            }
        }
        // Added: 24 Jul 2023
        if (viewObj === null || viewObj === void 0 ? void 0 : viewObj.whereValue) {
            for (const _where of viewObj === null || viewObj === void 0 ? void 0 : viewObj.whereValue) {
                const whereValueObj = new FromValueObj();
                whereValueObj.property = _where;
                whereValueObj.value = this.parseValue(this.dicts, _where);
                ucPagingObj.whereValue.push(whereValueObj);
            }
        }
        const useIntegration = !!(viewObj === null || viewObj === void 0 ? void 0 : viewObj.useIntegration);
        if (useIntegration) {
            ucPagingObj.isJoinExAPI = true;
            let requestObj;
            const integrationObj = new IntegrationObj();
            if (viewObj.integrationObj.integrationType === 'apv') {
                requestObj = {
                    CategoryCode: (_j = (_h = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _h === void 0 ? void 0 : _h.requestObj) === null || _j === void 0 ? void 0 : _j.CategoryCode,
                    Username: (_k = this.userAccess) === null || _k === void 0 ? void 0 : _k.UserName,
                    RoleCode: (_l = this.userAccess) === null || _l === void 0 ? void 0 : _l.RoleCode,
                };
                if (viewObj.integrationObj.useOffice) {
                    Object.assign(requestObj, { OfficeCode: this.userAccess.OfficeCode });
                }
            }
            else {
                const UserAccess = JSON.parse(this.templateService.getCookie(this.cookieService, CommonConstant.USER_ACCESS));
                requestObj = {
                    TaskDefinitionKey: (_o = (_m = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _m === void 0 ? void 0 : _m.requestObj) === null || _o === void 0 ? void 0 : _o.TaskDefinitionKey,
                    OfficeRoleCodes: [UserAccess[CommonConstant.ROLE_CODE],
                        UserAccess[CommonConstant.OFFICE_CODE],
                        UserAccess[CommonConstant.ROLE_CODE] + "-" + UserAccess[CommonConstant.OFFICE_CODE]]
                };
                const processKey = (_q = (_p = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _p === void 0 ? void 0 : _p.requestObj) === null || _q === void 0 ? void 0 : _q.ProcessKey.split(';');
                if (processKey.length > 1) {
                    const _processKey = [];
                    for (const val of _processKey) {
                        _processKey.push(this.parseValue(this.dicts, val));
                    }
                    requestObj.ProcessKeys = _processKey;
                }
                else {
                    // requestObj.ProcessKey = viewObj?.integrationObj?.requestObj?.ProcessKey;
                    const _processKey = this.textManipulation((_s = (_r = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _r === void 0 ? void 0 : _r.requestObj) === null || _s === void 0 ? void 0 : _s.ProcessKey, this.dicts);
                    requestObj.ProcessKey = _processKey;
                }
                // check postfix addition for TaskDefinitionKey
                if (((_u = (_t = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _t === void 0 ? void 0 : _t.requestObj) === null || _u === void 0 ? void 0 : _u.TaskDefinitionKeyPostFix) !== undefined
                    && ((_w = (_v = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _v === void 0 ? void 0 : _v.requestObj) === null || _w === void 0 ? void 0 : _w.TaskDefinitionKeyPostFix) !== "") {
                    const taskDefinitionKeyPostFix = this.parseValue(this.dicts, (_y = (_x = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _x === void 0 ? void 0 : _x.requestObj) === null || _y === void 0 ? void 0 : _y.TaskDefinitionKeyPostFix);
                    requestObj.TaskDefinitionKey = ((_0 = (_z = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _z === void 0 ? void 0 : _z.requestObj) === null || _0 === void 0 ? void 0 : _0.TaskDefinitionKey) + taskDefinitionKeyPostFix;
                }
                // check postfix addition for ProcessKey
                if (((_2 = (_1 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _1 === void 0 ? void 0 : _1.requestObj) === null || _2 === void 0 ? void 0 : _2.ProcessKeyPostFix) !== undefined
                    && ((_4 = (_3 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _3 === void 0 ? void 0 : _3.requestObj) === null || _4 === void 0 ? void 0 : _4.ProcessKeyPostFix) !== "") {
                    const processKeyPostFix = this.parseValue(this.dicts, (_6 = (_5 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _5 === void 0 ? void 0 : _5.requestObj) === null || _6 === void 0 ? void 0 : _6.ProcessKeyPostFix);
                    if ((requestObj === null || requestObj === void 0 ? void 0 : requestObj.ProcessKeys) !== undefined && (requestObj === null || requestObj === void 0 ? void 0 : requestObj.ProcessKeys.length) > 0) {
                        requestObj.ProcessKeys.map((item) => item + processKeyPostFix);
                    }
                    else {
                        requestObj.ProcessKey = requestObj.ProcessKey + processKeyPostFix;
                    }
                }
            }
            const _integrationBaseUrl = this.envi[(_7 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _7 === void 0 ? void 0 : _7.baseUrl];
            const _integrationApiPath = this.templateService.urlConstant[(_8 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _8 === void 0 ? void 0 : _8.apiPath] || ((_9 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _9 === void 0 ? void 0 : _9.apiPath);
            integrationObj.baseUrl = _integrationApiPath;
            if (_integrationBaseUrl !== undefined) {
                integrationObj.baseUrl = _integrationBaseUrl + _integrationApiPath;
            }
            integrationObj.leftColumnToJoin = (_10 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _10 === void 0 ? void 0 : _10.leftColumnToJoin;
            integrationObj.rightColumnToJoin = (_11 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _11 === void 0 ? void 0 : _11.rightColumnToJoin;
            integrationObj.joinType = (_12 = viewObj === null || viewObj === void 0 ? void 0 : viewObj.integrationObj) === null || _12 === void 0 ? void 0 : _12.joinType;
            integrationObj.requestObj = requestObj;
            ucPagingObj.integrationObj = integrationObj;
        }
        ucPagingObj.isHideSearch = !!(viewObj === null || viewObj === void 0 ? void 0 : viewObj.isHideSearch);
        ucPagingObj.isSearched = !!(viewObj === null || viewObj === void 0 ? void 0 : viewObj.isSearched);
        if (viewObj === null || viewObj === void 0 ? void 0 : viewObj.delay) {
            ucPagingObj.delay = viewObj === null || viewObj === void 0 ? void 0 : viewObj.delay;
        }
        ucPagingObj.dicts = this.dicts;
        ucPagingObj.addCritInput = arrCrit;
        this.listIds.push(id);
        this.listMapComponent.set(id, { type: componentObj.type, component: ucPagingObj, conditions: (_13 = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _13 === void 0 ? void 0 : _13.conditions });
    }
    compileAttr(id, componentObj) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const component = componentObj.component;
            const conditions = (component === null || component === void 0 ? void 0 : component.conditions) || [];
            for (const criteria of conditions) {
                if (!(criteria === null || criteria === void 0 ? void 0 : criteria.property.includes('form.')) && !(criteria === null || criteria === void 0 ? void 0 : criteria.property.includes('formRaw.'))) {
                    continue;
                }
                const keys = criteria === null || criteria === void 0 ? void 0 : criteria.property.split('.');
                const observable = keys[keys.length - 1];
                const subscriber = this.controlObservable[observable] === undefined ? [] : this.controlObservable[observable];
                if (subscriber.indexOf(id) === -1) {
                    subscriber.push(id);
                }
                this.controlObservable[observable] = subscriber;
                this.logger.log(`${observable} has subscriber: `, this.controlObservable[observable]);
            }
            const attrSettingObj = new RefAttrSettingObj(this.templateService);
            attrSettingObj.Variable = component === null || component === void 0 ? void 0 : component.variable;
            attrSettingObj.Title = component === null || component === void 0 ? void 0 : component.title;
            attrSettingObj.IsVertical = !!(component === null || component === void 0 ? void 0 : component.isVertical);
            attrSettingObj.UrlGetListAttr = this.getServiceUrl(component === null || component === void 0 ? void 0 : component.environment, component === null || component === void 0 ? void 0 : component.apiPath);
            const params = [];
            for (const param of component === null || component === void 0 ? void 0 : component.reqObj) {
                const propValue = {
                    property: param === null || param === void 0 ? void 0 : param.propName,
                    value: param === null || param === void 0 ? void 0 : param.propValue
                };
                params.push(propValue);
            }
            if (this.queryParams['mode'] != null) {
                if (this.queryParams['mode'] !== 'edit') {
                    attrSettingObj.IsAdd = false;
                }
            }
            attrSettingObj.IsAdd = ((_a = this.dicts) === null || _a === void 0 ? void 0 : _a.mode) === undefined ? this.IsAdd : this.dicts.mode !== 'edit';
            attrSettingObj.ReqGetListAttrObj = this.transformToObject({ arr: params });
            // Get Edit Object values
            let res = [];
            const onload = (component === null || component === void 0 ? void 0 : component.onLoad) ? component === null || component === void 0 ? void 0 : component.onLoad[0] : null;
            if (onload && !onload.isUseApi) {
                const src = onload === null || onload === void 0 ? void 0 : onload.dataSource;
                if (src === 'dicts') {
                    res = this.parseValue(this.dicts, onload === null || onload === void 0 ? void 0 : onload.propName);
                }
                else {
                    res = this.LocalStorage.find(onload === null || onload === void 0 ? void 0 : onload.propName);
                }
                attrSettingObj.EditObj = res || [];
            }
            this.listIds.push(id);
            this.listMapComponent.set(id, { type: componentObj.type, component: attrSettingObj, conditions: (_b = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _b === void 0 ? void 0 : _b.conditions });
        });
    }
    compileForm(id, componentObj) {
        var e_6, _a;
        var _b, _c, _d, _e;
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.log('formObj' + id, componentObj.component);
            const conditions = ((_b = componentObj.component) === null || _b === void 0 ? void 0 : _b.conditions) || [];
            for (const criteria of conditions) {
                if (!(criteria === null || criteria === void 0 ? void 0 : criteria.property.includes('form.')) && !(criteria === null || criteria === void 0 ? void 0 : criteria.property.includes('formRaw.'))) {
                    continue;
                }
                const keys = criteria === null || criteria === void 0 ? void 0 : criteria.property.split('.');
                const observable = keys[keys.length - 1];
                const subscriber = this.controlObservable[observable] === undefined ? [] : this.controlObservable[observable];
                if (subscriber.indexOf(id) === -1) {
                    subscriber.push(id);
                }
                this.controlObservable[observable] = subscriber;
                this.logger.log(`${observable} has subscriber: `, this.controlObservable[observable]);
            }
            const formObj = componentObj.component.subsection;
            if ((formObj === null || formObj === void 0 ? void 0 : formObj.isModeAdd) !== undefined) {
                this.IsAdd = formObj === null || formObj === void 0 ? void 0 : formObj.isModeAdd;
            }
            const queries = this.ngxRouter.getQueryParams(this.queryParams);
            if (queries && queries.hasOwnProperty('mode')) {
                if (queries['mode'] === 'edit' && !this.isDialog) {
                    this.IsAdd = false;
                }
                this.dicts['mode'] = this.isDialog ? this.refData['mode'] || 'add' : queries['mode'];
                this.IsAdd = this.dicts['mode'] === 'add';
            }
            console.log('dicts', this.dicts);
            console.log('isAdd', this.IsAdd);
            // this.IsAdd = this.dicts?.mode === undefined ? this.IsAdd : this.dicts.mode !== 'edit';
            this.formCriteria = formObj === null || formObj === void 0 ? void 0 : formObj.criteria;
            const formInput = new UcInputFormObj(this.templateService);
            formInput.formId = `FormId${id}`;
            formInput.title = formObj.title;
            formInput.IsModeAdd = this.IsAdd;
            formInput.IsVertical = formObj.isVertical;
            formInput.IsSubsection = formObj.isSubsection;
            formInput.IsCollapsed = (_c = formObj.isCollapsed) !== null && _c !== void 0 ? _c : false;
            formInput.formInput = formObj.formInput;
            formInput.dicts = this.dicts;
            formInput.initAction = (formObj === null || formObj === void 0 ? void 0 : formObj.initAction) || [];
            formInput.isPageFromService = this.environment.isPageFromService;
            formInput.pagesUrl = this.envi.PagesURL;
            formInput.pageName = this.templateObj.id || 'default';
            if (!this.IsAdd) {
                formInput.onloadAct = formObj.onLoad.map(x => x.action);
            }
            const addresses = formObj.formInput.filter(x => x.Type === 'ADDRESS');
            const lookups = formObj.formInput.filter(x => x.Type === 'LOOKUP');
            for (const address of addresses) {
                // this.setInputAddressObj(address.Variable);
                const UcAddressFill = new UcAddressObj();
                const inputFieldObj = new InputFieldObj();
                inputFieldObj.inputLookupObj = new InputLookupObj(this.templateService);
                const addressObj = new InputAddressObj(this.templateService);
                addressObj.default = UcAddressFill;
                addressObj.inputField = inputFieldObj;
                addressObj.useFourColl = (_d = address.UseFourColl) !== null && _d !== void 0 ? _d : false;
                this.AddressService.SetNewInputAddressObj(address.Variable, addressObj);
            }
            try {
                for (var lookups_2 = __asyncValues(lookups), lookups_2_1; lookups_2_1 = yield lookups_2.next(), !lookups_2_1.done;) {
                    const lookup = lookups_2_1.value;
                    // this.setLookupObject(lookup);
                    yield this.setLookupObject(lookup);
                }
            }
            catch (e_6_1) { e_6 = { error: e_6_1 }; }
            finally {
                try {
                    if (lookups_2_1 && !lookups_2_1.done && (_a = lookups_2.return)) yield _a.call(lookups_2);
                }
                finally { if (e_6) throw e_6.error; }
            }
            this.listIds.push(id);
            this.listMapComponent.set(id, { type: componentObj.type, component: formInput, conditions: (_e = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _e === void 0 ? void 0 : _e.conditions });
            const mapCookies = (formObj === null || formObj === void 0 ? void 0 : formObj.mapCookie) || [];
            if (mapCookies.length > 0 && !this.IsAdd) {
                let patchValueObjForm = {};
                mapCookies.forEach(cookie => {
                    const value = this.cleansingParams(cookie === null || cookie === void 0 ? void 0 : cookie.cookieName);
                    patchValueObjForm[cookie === null || cookie === void 0 ? void 0 : cookie.variableName] = this.parseValue(this.dicts, value, false, !!(cookie === null || cookie === void 0 ? void 0 : cookie.isEmptyNotFound));
                });
                const trees = formObj.formInput.filter(x => x.Type === 'TREE') || [];
                if (trees.length > 0) {
                    for (const tree of trees) {
                        if (!patchValueObjForm.hasOwnProperty(tree === null || tree === void 0 ? void 0 : tree.Variable)) {
                            continue;
                        }
                        patchValueObjForm = this.flattenObject(patchValueObjForm, tree.Variable);
                    }
                }
                this.logger.log('Update patch form value', patchValueObjForm);
                formInput.FormEditObject = this.FormSettingService.SetFormEditObj(formInput.FormEditObject, patchValueObjForm);
                this.FormSettingService.notify(true, formInput.formId);
            }
            if (!this.IsAdd) {
                yield this.getSetEditObj(id, formObj);
            }
            else {
                formInput.FormEditObject = this.FormSettingService.SetFormEditObj(formInput.FormEditObject, {});
                this.IsReady = true;
            }
        });
    }
    inflateView(identifier, content, params) {
        // const element = document.getElementById(identifier);
        // const factory = this.resolver.resolveComponentFactory(component);
        // const componentRef = factory.create(this.injector, [], element);
        //
        // if (componentObj.component?.input) {
        //   const input = componentObj.component?.input;
        //   Object.keys(componentObj.component?.input).forEach(key => {
        //     componentRef.instance[key] = _getValue(input, input[key]); //this.queryParams[input[key]];
        //   });
        // }
        //
        // if (isForm) {
        //   componentRef.instance['parentForm'] = this.Form;
        // }
        //
        // this.appRef.attachView(componentRef.hostView);
        // this.cdr.detectChanges();
        // this.logger.log('element', element);
    }
    setLookupObject(lookup, isFormArray) {
        var _a, _b, _c, _d;
        return __awaiter(this, void 0, void 0, function* () {
            let lookupObj = new InputLookupObj(this.templateService);
            this.logger.log('lookup.pagingInput', lookup === null || lookup === void 0 ? void 0 : lookup.pagingInput);
            if (lookup === null || lookup === void 0 ? void 0 : lookup.pagingInput) {
                Object.assign(lookupObj, { dataInput: lookup.pagingInput });
            }
            else {
                const lookupName = lookup.LookupName.slice(2, -1);
                const lookupReq = this.http.get(`${this.templateService.baseUrl}/assets/form-template/lookup/${lookupName}.json`);
                const lookupJson = yield lastValueFrom(lookupReq);
                lookupObj = Object.assign(lookupObj, { dataInput: lookupJson });
            }
            // Nendi: 08 Juni 2023 | Add override urlEnviPaging
            if (((_a = lookupObj === null || lookupObj === void 0 ? void 0 : lookupObj.dataInput) === null || _a === void 0 ? void 0 : _a.environment) && ((_b = lookupObj === null || lookupObj === void 0 ? void 0 : lookupObj.dataInput) === null || _b === void 0 ? void 0 : _b.environment) !== '') {
                lookupObj.urlEnviPaging = this.envi[(_c = lookupObj === null || lookupObj === void 0 ? void 0 : lookupObj.dataInput) === null || _c === void 0 ? void 0 : _c.environment] + '/' + ((_d = lookupObj === null || lookupObj === void 0 ? void 0 : lookupObj.dataInput) === null || _d === void 0 ? void 0 : _d.apiVersion);
            }
            this.lookupMap[lookup.Variable] = lookupObj;
            this.logger.log('lookupObj', lookupObj);
            const criteriaList = [];
            if (lookup.Criteria) {
                for (const criteria of lookup.Criteria) {
                    const criteriaObj = new CriteriaObj();
                    criteriaObj.restriction = criteria.restriction;
                    criteriaObj.propName = criteria.propName;
                    if ((criteria === null || criteria === void 0 ? void 0 : criteria.restriction.toUpperCase()) === 'IN' || (criteria === null || criteria === void 0 ? void 0 : criteria.restriction.toUpperCase()) === 'NOTIN') {
                        criteriaObj.listValue = [];
                        const values = criteria === null || criteria === void 0 ? void 0 : criteria.value.split(';');
                        for (const val of values) {
                            if (!val) {
                                continue;
                            }
                            criteriaObj.listValue.push(this.parseValue(this.dicts, val));
                        }
                        criteriaObj.listValue = criteriaObj.listValue.flat();
                    }
                    else {
                        criteriaObj.value = this.parseValue(this.dicts, criteria === null || criteria === void 0 ? void 0 : criteria.value);
                    }
                    criteriaList.push(criteriaObj);
                }
                lookupObj.addCritInput = criteriaList;
            }
            if (isFormArray) {
                this.LookupFAService.SetNewInputLookupObj(lookup.Variable, lookupObj);
                this.LookupFAService.SetIsReady(lookup.Variable);
            }
            else {
                this.LookupService.SetNewInputLookupObj(lookup.Variable, lookupObj);
                this.LookupService.SetIsReady(lookup.Variable);
            }
        });
    }
    compileView(id, componentObj) {
        var _a, _b, _c, _d, _e, _f;
        const bsDate = new Date(this.userAccess.BusinessDt);
        const view = componentObj.component.subsection;
        const tables = (view === null || view === void 0 ? void 0 : view.gridViews) || [];
        for (const table of tables) {
            const tableReqObj = ((_a = table === null || table === void 0 ? void 0 : table.getData) === null || _a === void 0 ? void 0 : _a.reqObj) || [];
            let transformTableReq = {};
            // Transform Request Object
            for (const tReq of tableReqObj) {
                transformTableReq[tReq.propName] = this.parseValue(this.dicts, tReq.propValue);
            }
            table.getData.reqObj = transformTableReq;
        }
        this.parseTitle(view, bsDate);
        this.logger.log(view.subSectionId, view);
        const viewInputObj = new UcViewGenericObj(this.templateService);
        if ((view === null || view === void 0 ? void 0 : view.environment) && (view === null || view === void 0 ? void 0 : view.environment) !== '') {
            viewInputObj.viewEnvironment = this.templateService.envConfig[view === null || view === void 0 ? void 0 : view.environment] + '/' + (view === null || view === void 0 ? void 0 : view.apiVersion) || viewInputObj.viewEnvironment;
        }
        viewInputObj.viewEnvironment = (view === null || view === void 0 ? void 0 : view.environmentUrl) || viewInputObj.viewEnvironment;
        viewInputObj.dataInput = {
            subsection: [view]
        };
        viewInputObj.environment = this.templateService.environment;
        if ((view === null || view === void 0 ? void 0 : view.whereValue) && ((_b = view === null || view === void 0 ? void 0 : view.whereValue) === null || _b === void 0 ? void 0 : _b.length) > 0) {
            const whereValues = [];
            for (const value of view === null || view === void 0 ? void 0 : view.whereValue) {
                whereValues.push(this.parseValue(this.dicts, value));
            }
            viewInputObj.whereValue = whereValues;
        }
        // Add data dictionary to view instance
        viewInputObj.dicts = this.dicts;
        // EXPERIMENTAL for BaseView API
        // TODO: remove as late as 18/12/23 | dd/mm/yy
        viewInputObj.Experimental = ((_d = (_c = this.templateService.environment) === null || _c === void 0 ? void 0 : _c.experimental) === null || _d === void 0 ? void 0 : _d.view) || false;
        // END EXPERIMENTAL
        if (((_e = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _e === void 0 ? void 0 : _e.type) === 'page')
            this.listIds.push(id);
        this.listMapComponent.set(id, { type: componentObj.type, component: viewInputObj, conditions: (_f = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _f === void 0 ? void 0 : _f.conditions });
    }
    compileCreateRfa(id, componentObj) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            this.ApvRfaReady = false;
            this.isHumanApproval = ((_a = this.dicts) === null || _a === void 0 ? void 0 : _a.isHumanApproval) === undefined ? true : this.dicts.isHumanApproval;
            yield this.constructCreateRfa(componentObj, id, true);
        });
    }
    constructCreateRfa(componentObj, id, isInit) {
        var e_7, _a;
        var _b, _c, _d, _e, _f;
        return __awaiter(this, void 0, void 0, function* () {
            const component = componentObj.component;
            const loads = (component === null || component === void 0 ? void 0 : component.onLoad) || [];
            this.onSubmit = component === null || component === void 0 ? void 0 : component.onSubmit;
            if (loads.length > 0) {
                for (let onload of loads) {
                    const envUrlInit = this.templateService.envConfig[onload === null || onload === void 0 ? void 0 : onload.environment];
                    const apiUrl = `${envUrlInit}${onload === null || onload === void 0 ? void 0 : onload.apiPath}`;
                    const reqObj = (onload === null || onload === void 0 ? void 0 : onload.reqObj) || [];
                    let reqBody = {};
                    if (reqObj && reqObj.length > 0) {
                        for (let obj of reqObj) {
                            let defaultValue = this.queryParams[obj === null || obj === void 0 ? void 0 : obj.propValue] === undefined ? obj === null || obj === void 0 ? void 0 : obj.propValue : this.queryParams[obj === null || obj === void 0 ? void 0 : obj.propValue];
                            reqBody[obj === null || obj === void 0 ? void 0 : obj.propName] = (obj === null || obj === void 0 ? void 0 : obj.isFromDict) === true ? this.dicts[obj === null || obj === void 0 ? void 0 : obj.propValue] : defaultValue;
                        }
                    }
                    const req = this.http.post(apiUrl, reqBody);
                    const res = yield lastValueFrom(req);
                    this.dicts = Object.assign(this.dicts, res);
                    this.publishDictionary();
                    this.isHumanApproval = res['IsHumanApproval'] === undefined ? true : res['IsHumanApproval'];
                }
            }
            if (!this.isHumanApproval) {
                return;
            }
            // Check RFAObj input
            const RFAObj = this.dicts['RFAObj'] || null;
            const initRfaObj = (schemeCode, isInit) => __awaiter(this, void 0, void 0, function* () {
                var _j, _k, _l, _m, _o;
                const inputObj = new UcInputRFAObj(this.templateService, this.http, this.cookieService);
                inputObj.CategoryCode = component === null || component === void 0 ? void 0 : component.categoryCode;
                inputObj.SchemeCode = schemeCode;
                inputObj.IsHideTrxNo = true;
                inputObj.TrxNo = !RFAObj ? ' ' : (RFAObj === null || RFAObj === void 0 ? void 0 : RFAObj.TrxNo) || ' ';
                if (inputObj.TrxNo === ' ') {
                    inputObj.TrxNo = this.parseValue(this.dicts, (_j = component === null || component === void 0 ? void 0 : component.trxNo) !== null && _j !== void 0 ? _j : " ") || ' ';
                }
                inputObj.OfficeCodes = !RFAObj ? [] : !RFAObj['OfficeCode'] ? [] : [RFAObj['OfficeCode']];
                inputObj.ApvTypecodes = component === null || component === void 0 ? void 0 : component.apvTypecodes;
                inputObj.dicts = this.dicts;
                inputObj.requiredNotes = (_k = component === null || component === void 0 ? void 0 : component.requiredNotes) !== null && _k !== void 0 ? _k : true;
                inputObj.defaultApprover = this.parseValue(this.dicts, (_l = component === null || component === void 0 ? void 0 : component.defaultApprover) !== null && _l !== void 0 ? _l : "");
                inputObj.IsHideNewRfa = (_m = component === null || component === void 0 ? void 0 : component.isHideNewRfa) !== null && _m !== void 0 ? _m : false;
                if (isInit) {
                    this.listIds.push(id);
                }
                this.listMapComponent.set(id, { type: componentObj.type, component: inputObj, conditions: (_o = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _o === void 0 ? void 0 : _o.conditions });
                this.listMapTypeToIdComponent.set(componentObj.type, { id: id, componentObj: componentObj });
                yield this.setApprovalTypesAndAttributes(id, component);
                yield this.setApprovalObjReason(id, component);
            });
            const isSchemeCodeFromApi = !!component.fromApi;
            if (isSchemeCodeFromApi) {
                const envUrl = this.templateService.envConfig[(_b = component === null || component === void 0 ? void 0 : component.setApprovalObj) === null || _b === void 0 ? void 0 : _b.environment];
                const serviceUrl = `${envUrl}${(_c = component.setApprovalObj) === null || _c === void 0 ? void 0 : _c.apiPath}`;
                this.logger.log('serviceUrl approval scheme', serviceUrl);
                let props = [];
                try {
                    for (var _g = __asyncValues(Object.keys((_d = component === null || component === void 0 ? void 0 : component.setApprovalObj) === null || _d === void 0 ? void 0 : _d.reqObj)), _h; _h = yield _g.next(), !_h.done;) {
                        const key = _h.value;
                        if ((_e = component === null || component === void 0 ? void 0 : component.setApprovalObj) === null || _e === void 0 ? void 0 : _e.reqObj[key].includes("formRaw")) {
                            if (this.dicts.formRaw === undefined)
                                this.logger.log("waiting for formRaw to be created...");
                            yield this.waitFor(_ => this.dicts.formRaw != undefined);
                        }
                        props.push({ property: key, value: (_f = component === null || component === void 0 ? void 0 : component.setApprovalObj) === null || _f === void 0 ? void 0 : _f.reqObj[key] });
                    }
                }
                catch (e_7_1) { e_7 = { error: e_7_1 }; }
                finally {
                    try {
                        if (_h && !_h.done && (_a = _g.return)) yield _a.call(_g);
                    }
                    finally { if (e_7) throw e_7.error; }
                }
                const reqObj = this.transformToObject({ arr: props });
                Object.assign(reqObj, { OfficeCode: this.userAccess.OfficeCode });
                this.logger.log('setAppObj reqObj', reqObj);
                yield this.http.post(serviceUrl, reqObj).toPromise().then((response) => __awaiter(this, void 0, void 0, function* () {
                    yield initRfaObj(response, isInit);
                }));
            }
            else {
                yield initRfaObj(component === null || component === void 0 ? void 0 : component.schmCode, isInit);
            }
        });
    }
    waitFor(conditions) {
        const vote = resolve => {
            if (conditions())
                resolve();
            else
                setTimeout(_ => vote(resolve), 50);
        };
        return new Promise(vote);
    }
    waitForInterval(interval) {
        const res = resolve => {
            setTimeout(_ => resolve(), interval);
        };
        return new Promise(res);
    }
    compileCreateRfaManualDeviation(id, componentObj) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            let autoDevApvAt, maxApvAt, apvScheme, recomendations, totalCostAmt;
            this.ApvRfaReady = false;
            this.isHumanApproval = ((_a = this.dicts) === null || _a === void 0 ? void 0 : _a.isHumanApproval) === undefined ? true : this.dicts.isHumanApproval;
            const component = componentObj.component;
            const loads = (component === null || component === void 0 ? void 0 : component.onLoad) || [];
            this.onSubmit = component === null || component === void 0 ? void 0 : component.onSubmit;
            if (loads.length > 0) {
                for (let onload of loads) {
                    const envUrlInit = this.templateService.envConfig[onload === null || onload === void 0 ? void 0 : onload.environment];
                    const apiUrl = `${envUrlInit}${onload === null || onload === void 0 ? void 0 : onload.apiPath}`;
                    const reqObj = (onload === null || onload === void 0 ? void 0 : onload.reqObj) || [];
                    let reqBody = {};
                    if (reqObj && reqObj.length > 0) {
                        for (let obj of reqObj) {
                            let defaultValue = this.queryParams[obj === null || obj === void 0 ? void 0 : obj.propValue] === undefined ? obj === null || obj === void 0 ? void 0 : obj.propValue : this.queryParams[obj === null || obj === void 0 ? void 0 : obj.propValue];
                            reqBody[obj === null || obj === void 0 ? void 0 : obj.propName] = (obj === null || obj === void 0 ? void 0 : obj.isFromDict) === true ? this.dicts[obj === null || obj === void 0 ? void 0 : obj.propValue] : defaultValue;
                        }
                    }
                    const req = this.http.post(apiUrl, reqBody);
                    const res = yield lastValueFrom(req);
                    this.dicts = Object.assign(this.dicts, res);
                    this.publishDictionary();
                    this.isHumanApproval = res['IsHumanApproval'] === undefined ? true : res['IsHumanApproval'];
                }
            }
            if (!this.isHumanApproval) {
                return;
            }
            // Check RFAObj input
            // const RFAObj = this.dicts['RFAObj'] || null;
            const TrxNo = this.parseValue(this.dicts, component === null || component === void 0 ? void 0 : component.trxNo) || '';
            const initRfaObj = (schemeCode, totalCostAmt, maxApvAt) => __awaiter(this, void 0, void 0, function* () {
                var _b, _c;
                const Attributes = [];
                const attribute1 = {
                    "AttributeName": "Approval Amount",
                    "AttributeValue": totalCostAmt
                };
                Attributes.push(attribute1);
                const listTypeCode = [];
                const TypeCode = {
                    "TypeCode": "APV_LIMIT",
                    "Attributes": Attributes
                };
                listTypeCode.push(TypeCode);
                if (maxApvAt != null) {
                    const Attributes2 = [];
                    const attribute2 = {
                        "AttributeName": "APPROVAL AT",
                        "AttributeValue": maxApvAt
                    };
                    Attributes2.push(attribute2);
                    const TypeCode2 = {
                        "TypeCode": "MANUAL_DEV",
                        "Attributes": Attributes2
                    };
                    listTypeCode.push(TypeCode2);
                }
                const inputObj = new UcInputRFAObj(this.templateService, this.http, this.cookieService);
                inputObj.CategoryCode = component === null || component === void 0 ? void 0 : component.categoryCode;
                inputObj.ApvTypecodes = listTypeCode;
                inputObj.SchemeCode = schemeCode;
                inputObj.Reason = recomendations;
                inputObj.TrxNo = TrxNo;
                inputObj.dicts = this.dicts;
                inputObj.requiredNotes = (_b = component === null || component === void 0 ? void 0 : component.requiredNotes) !== null && _b !== void 0 ? _b : true;
                this.listIds.push(id);
                this.listMapComponent.set(id, { type: componentObj.type, component: inputObj, conditions: (_c = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _c === void 0 ? void 0 : _c.conditions });
                this.listMapTypeToIdComponent.set(componentObj.type, { id: id, componentObj: componentObj });
                setTimeout(() => {
                    this.ApvRfaReady = true;
                }, 300);
            });
            const GetDeviationResultData = (getDeviationObj) => __awaiter(this, void 0, void 0, function* () {
                const url = this.getServiceUrl(getDeviationObj === null || getDeviationObj === void 0 ? void 0 : getDeviationObj.environment, getDeviationObj === null || getDeviationObj === void 0 ? void 0 : getDeviationObj.apiPath);
                const dat = getDeviationObj === null || getDeviationObj === void 0 ? void 0 : getDeviationObj.reqObj;
                const payload = Object.assign({}, dat);
                Object.keys(dat).forEach(prop => {
                    payload[prop] = this.parseValue(this.dicts, dat[prop]);
                });
                const req = this.http.post(url, payload);
                const res = yield lastValueFrom(req);
                const listTypeCodes = res['ApvTypecodes'] || [];
                if (!listTypeCodes || listTypeCodes.length === 0) {
                    return;
                }
                listTypeCodes.forEach(apv => {
                    if (apv['Attributes']) {
                        apv.Attributes.forEach(attr => {
                            autoDevApvAt = attr.AttributeValue;
                            maxApvAt = attr.AttributeValue;
                        });
                    }
                });
            });
            const getApvScheme = component === null || component === void 0 ? void 0 : component.getApvScheme;
            const GetApvScheme = (getApvScheme) => __awaiter(this, void 0, void 0, function* () {
                const url = this.getServiceUrl(getApvScheme === null || getApvScheme === void 0 ? void 0 : getApvScheme.environment, getApvScheme === null || getApvScheme === void 0 ? void 0 : getApvScheme.apiPath);
                const dat = getApvScheme === null || getApvScheme === void 0 ? void 0 : getApvScheme.reqObj;
                const payload = Object.assign({}, dat);
                Object.keys(dat).forEach(prop => {
                    payload[prop] = this.parseValue(this.dicts, dat[prop]);
                });
                const req = this.http.post(url, payload);
                const res = yield lastValueFrom(req);
                apvScheme = res['CompntValue'];
            });
            const getRecommendation = component === null || component === void 0 ? void 0 : component.getRecommendation;
            const FetchRecommendation = (getRecommendation) => __awaiter(this, void 0, void 0, function* () {
                if (!getRecommendation) {
                    return;
                }
                const url = this.getServiceUrl(getRecommendation === null || getRecommendation === void 0 ? void 0 : getRecommendation.environment, getRecommendation === null || getRecommendation === void 0 ? void 0 : getRecommendation.apiPath);
                const dat = getRecommendation === null || getRecommendation === void 0 ? void 0 : getRecommendation.reqObj;
                const payload = Object.assign({}, dat);
                Object.keys(dat).forEach(prop => {
                    payload[prop] = this.parseValue(this.dicts, dat[prop]);
                });
                const req = this.http.post(url, payload);
                const res = yield lastValueFrom(req);
                recomendations = res['ReturnObject'];
            });
            const getApvAmt = component === null || component === void 0 ? void 0 : component.getApvAmt;
            const FetchApvAmt = (getApvAmt) => __awaiter(this, void 0, void 0, function* () {
                if (!getApvAmt) {
                    return;
                }
                const url = this.getServiceUrl(getApvAmt === null || getApvAmt === void 0 ? void 0 : getApvAmt.environment, getApvAmt === null || getApvAmt === void 0 ? void 0 : getApvAmt.apiPath);
                const dat = getApvAmt === null || getApvAmt === void 0 ? void 0 : getApvAmt.reqObj;
                const payload = Object.assign({}, dat);
                Object.keys(dat).forEach(prop => {
                    payload[prop] = this.parseValue(this.dicts, dat[prop]);
                });
                const req = this.http.post(url, payload);
                const res = yield lastValueFrom(req);
                // Update Form
                totalCostAmt = res['ApvAmt'];
                this.Form.patchValue({
                    ApvAmt: res['ApvAmt']
                });
            });
            const isSchemeCodeFromApi = !!component.fromApi;
            const getDeviationObj = component === null || component === void 0 ? void 0 : component.getDeviationResultData;
            // Get Deviation Result Data
            yield GetDeviationResultData(getDeviationObj);
            // Get Approval Scheme
            if (isSchemeCodeFromApi) {
                yield GetApvScheme(getApvScheme);
            }
            else {
                apvScheme = component === null || component === void 0 ? void 0 : component.schmCode;
            }
            // Get Recommendation
            yield FetchRecommendation(getRecommendation);
            // Get Approval Amount
            yield FetchApvAmt(getApvAmt);
            yield initRfaObj(apvScheme, totalCostAmt, maxApvAt);
        });
    }
    compileApprovalHistory(id, componentObj) {
        var _a;
        const cmpObj = componentObj.component;
        const apvHistory = new UcInputApprovalHistoryObj(this.templateService);
        apvHistory.EnvUrl = this.templateService.envConfig[cmpObj === null || cmpObj === void 0 ? void 0 : cmpObj.environment] || apvHistory.EnvUrl;
        apvHistory.PathUrl = (cmpObj === null || cmpObj === void 0 ? void 0 : cmpObj.apiPath) || apvHistory.PathUrl;
        const queryparams = componentObj.component.queryParams;
        apvHistory.RequestId = this.parseValue(this.dicts, this.cleansingParams(queryparams['RequestId']));
        this.listIds.push(id);
        this.listMapComponent.set(id, { type: componentObj.type, component: apvHistory, conditions: (_a = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _a === void 0 ? void 0 : _a.conditions });
    }
    compileApprovalGeneralInfo(id, componentObj) {
        var _a;
        const cmpObj = componentObj.component;
        const apvGeneralInfo = new UcInputApprovalGeneralInfoObj(this.templateService);
        apvGeneralInfo.EnvUrl = this.templateService.envConfig[cmpObj === null || cmpObj === void 0 ? void 0 : cmpObj.environment] || apvGeneralInfo.EnvUrl;
        apvGeneralInfo.PathUrl = (cmpObj === null || cmpObj === void 0 ? void 0 : cmpObj.apiPath) || apvGeneralInfo.PathUrl;
        apvGeneralInfo.TaskId = this.parseValue(this.dicts, 'TaskId'); //this.queryParams['TaskId'];
        this.listIds.push(id);
        this.listMapComponent.set(id, { type: componentObj.type, component: apvGeneralInfo, conditions: (_a = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _a === void 0 ? void 0 : _a.conditions });
    }
    compileApproval(id, componentObj) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
        const apvObj = new UcInputApprovalObj(this.templateService);
        const params = (_a = componentObj.component) === null || _a === void 0 ? void 0 : _a.queryParams;
        this.onSubmit = (_b = componentObj.component) === null || _b === void 0 ? void 0 : _b.onSubmit;
        apvObj.requiredNotes = (_d = (_c = componentObj.component) === null || _c === void 0 ? void 0 : _c.requiredNotes) !== null && _d !== void 0 ? _d : true;
        apvObj.notesReqWhen = (_f = (_e = componentObj.component) === null || _e === void 0 ? void 0 : _e.notesReqWhen) !== null && _f !== void 0 ? _f : [];
        apvObj.showApvHistory = (_h = (_g = componentObj.component) === null || _g === void 0 ? void 0 : _g.showApvHistory) !== null && _h !== void 0 ? _h : true;
        apvObj.dicts = this.dicts;
        apvObj.IsReturnToRequestorOnly = (_k = (_j = componentObj.component) === null || _j === void 0 ? void 0 : _j.isReturnToRequestorOnly) !== null && _k !== void 0 ? _k : false;
        Object.keys(params).forEach(key => {
            apvObj[key] = this.dicts[params[key]] !== undefined ? this.dicts[params[key]] : params[key];
        });
        this.ApvReady = true;
        this.listIds.push(id);
        this.listMapComponent.set(id, { type: componentObj.type, component: apvObj, conditions: (_l = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _l === void 0 ? void 0 : _l.conditions });
        this.logger.log(componentObj.type, this.listMapComponent.get(id));
    }
    compileApprovalMulti(id, componentObj) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q;
        const apvObj = new UcInputApprovalObj(this.templateService);
        const params = (_a = componentObj.component) === null || _a === void 0 ? void 0 : _a.queryParams;
        this.onSubmit = (_b = componentObj.component) === null || _b === void 0 ? void 0 : _b.onSubmit;
        apvObj.requiredNotes = (_d = (_c = componentObj.component) === null || _c === void 0 ? void 0 : _c.requiredNotes) !== null && _d !== void 0 ? _d : true;
        apvObj.notesReqWhen = (_f = (_e = componentObj.component) === null || _e === void 0 ? void 0 : _e.notesReqWhen) !== null && _f !== void 0 ? _f : [];
        apvObj.showApvHistory = false;
        apvObj.isMultiApv = true;
        apvObj.dicts = this.dicts;
        apvObj.listApproveProp = (_h = (_g = componentObj.component) === null || _g === void 0 ? void 0 : _g.listApproveProp) !== null && _h !== void 0 ? _h : "listTemp"; // will default to listTemp - assuming approval multi came from temp paging
        apvObj.IsReturnToRequestorOnly = (_k = (_j = componentObj.component) === null || _j === void 0 ? void 0 : _j.isReturnToRequestorOnly) !== null && _k !== void 0 ? _k : false;
        // #region set apv grid obj
        apvObj.apvGridObj = new InputGridviewObj(this.templateService);
        apvObj.apvGridObj.id = id + "multiapvlist";
        apvObj.apvGridObj.isSubsection = true;
        apvObj.apvGridObj.title = "list approve";
        apvObj.apvGridObj.dataInput = (_l = componentObj.component) === null || _l === void 0 ? void 0 : _l.tableInput;
        apvObj.apvGridObj.usePagination = false;
        apvObj.apvGridObj.defaultChecked = false;
        apvObj.apvGridObj.useSafeUrl = (_o = (_m = this.templateService.environment) === null || _m === void 0 ? void 0 : _m.useSafeUrl) !== null && _o !== void 0 ? _o : false;
        const data = ((_p = componentObj.component) === null || _p === void 0 ? void 0 : _p.listApproveProp) === '' ? [] : (this.dicts[apvObj.listApproveProp] || []);
        apvObj.apvGridObj.serviceObj = { objName: apvObj.listApproveProp };
        apvObj.apvGridObj.resultData = { Data: data };
        apvObj.apvGridObj.isReady = true;
        // #endregion set apv grid obj
        Object.keys(params).forEach(key => {
            apvObj[key] = this.dicts[params[key]] !== undefined ? this.dicts[params[key]] : params[key];
        });
        this.ApvReady = true;
        this.listIds.push(id);
        this.listMapComponent.set(id, { type: componentObj.type, component: apvObj, conditions: (_q = componentObj === null || componentObj === void 0 ? void 0 : componentObj.component) === null || _q === void 0 ? void 0 : _q.conditions });
        this.logger.log(componentObj.type, this.listMapComponent.get(id));
    }
    setApprovalTypesAndAttributes(id, componentObj) {
        return __awaiter(this, void 0, void 0, function* () {
            let typeCodes = componentObj === null || componentObj === void 0 ? void 0 : componentObj.typeCodes;
            if (!typeCodes) {
                let types = [];
                componentObj.apvTypecodes.forEach(obj => {
                    Object.keys(obj).forEach(key => {
                        types.push({ property: key, value: obj[key] });
                    });
                });
                typeCodes = types;
            }
            const apvTypeCode = this.transformToObject({ arr: typeCodes });
            const immApvTypeCode = this.transformToObject({ arr: typeCodes, compType: "approvalcreate" });
            const component = this.listMapComponent.get(id);
            const inputObj = component.component;
            inputObj.ApvTypecodes = [apvTypeCode];
            inputObj.ImmutableApvTypecodes = [immApvTypeCode];
        });
    }
    setApprovalObjReason(id, componentObj) {
        return __awaiter(this, void 0, void 0, function* () {
            const reasonType = componentObj === null || componentObj === void 0 ? void 0 : componentObj.refReasonTypeCode;
            const component = this.listMapComponent.get(id);
            const inputObj = component.component;
            yield inputObj.setListReason(reasonType);
            this.ApvRfaReady = true;
            // this.logger.log('IsReady', this.ApvRfaReady);
            // this.logger.log(id, this.getComponent(id));
        });
    }
    parseTitle(view, bsDate) {
        const formatDate = (view === null || view === void 0 ? void 0 : view.formatDate) || 'DD/MM/YYYY';
        if (view === null || view === void 0 ? void 0 : view.subSectionTitle.includes('{BusinessDate}')) {
            view['subSectionTitle'] = view === null || view === void 0 ? void 0 : view.subSectionTitle.replace('{BusinessDate}', this.parseDate(bsDate, formatDate));
        }
        else {
            view['subSectionTitle'] = this.transformStringValue(view === null || view === void 0 ? void 0 : view.subSectionTitle, this.dicts, formatDate);
        }
    }
    getPanel(tablist, index) {
        return tablist.find(tab => tab.step.index === index) || null;
    }
    ChangeTab(Code, Tab) {
        var _a, _b;
        let identifier, component, className, panel, tab;
        const onChange = !!((_a = this.StepperObj) === null || _a === void 0 ? void 0 : _a.onChange) === true ? this.StepperObj.onChange : [];
        // Execute onChange actions
        for (const event of onChange) {
            const { cons } = event, action = __rest(event, ["cons"]);
            const conditions = cons || [];
            const valid = this.switchCase(conditions);
            if (!valid) {
                continue;
            }
            this.actionResult(action);
        }
        setTimeout(() => {
            const stepperScroll = document.querySelector(`div[data-target="#${Code}-tab"]`);
            stepperScroll.scrollIntoView({
                behavior: 'smooth',
                inline: 'center'
            });
        }, 10);
        this.logger.log('Step Code: ', Code);
        this.StepIndex = this.AppStep[Code];
        this.StepperView.to(this.StepIndex);
        this.dicts = Object.assign(this.dicts, { isLastStep: this.isLastStep() });
        tab = this.getPanel((_b = this.StepperObj) === null || _b === void 0 ? void 0 : _b.tablist, this.StepIndex);
        panel = tab.panel;
        let num = 0;
        if (this.StepperObj.linear) {
            num = this.StepIndex - 1;
        }
        for (let i = num; i < this.StepperObj.tablist.length; i++) {
            this.StepperObj.tablist[i].completed = false;
        }
        if (this.StepIndex > 1 && this.StepperObj.linear) {
            this.StepperObj.tablist[this.StepIndex - 2].completed = true;
        }
        for (const view of panel) {
            if ((view === null || view === void 0 ? void 0 : view.isTemplate) === true) {
                this.selectedIdxChange.emit(this.StepIndex);
                continue;
            }
            setTimeout(() => {
                identifier = `${tab.step.code}-${view === null || view === void 0 ? void 0 : view.content}`;
                className = view === null || view === void 0 ? void 0 : view.content;
                component = this.templateService.container.getComponent(className);
                const element = document.getElementById(identifier);
                const factory = this.resolver.resolveComponentFactory(component);
                const componentRef = factory.create(this.injector, [], element);
                // Setup next event handler
                componentRef.instance['next'].subscribe(event => {
                    this.onNext(event);
                });
                if ((view === null || view === void 0 ? void 0 : view.params.length) > 0) {
                    const params = view === null || view === void 0 ? void 0 : view.params;
                    for (const prop of params) {
                        componentRef.instance[prop.propName] = this.parseValue(this.dicts, prop.propValue);
                    }
                }
                componentRef.instance['dicts'] = this.dicts;
                this.appRef.attachView(componentRef.hostView);
                this.cdr.detectChanges();
                this.logger.log('element', element);
            }, 10);
        }
    }
    NextStep(Code) {
        var _a;
        if (!Code) {
            const NextIndex = this.getNextIndexByValue(this.AppStep, this.StepIndex);
            Code = this.getKeyByIndex(this.AppStep, NextIndex);
        }
        const onNext = !!((_a = this.StepperObj) === null || _a === void 0 ? void 0 : _a.onNext) === true ? this.StepperObj.onNext : [];
        // Add next step code to dict
        this.dicts = Object.assign(this.dicts, { NextStepCode: Code });
        // Execute onNext actions
        for (const event of onNext) {
            const { cons } = event, action = __rest(event, ["cons"]);
            const conditions = cons || [];
            const valid = this.switchCase(conditions);
            if (!valid) {
                continue;
            }
            this.actionResult(action);
        }
        this.ChangeTab(Code);
    }
    getNextIndex(dictionary, currentIndex) {
        const keys = Object.keys(dictionary);
        const currentIndexPos = keys.indexOf(currentIndex.toString());
        if (currentIndexPos !== -1 && currentIndexPos < keys.length - 1) {
            return dictionary[keys[currentIndexPos + 1]];
        }
        // Return null or handle the case when the current index is the last one
        return -1;
    }
    getNextIndexByValue(dictionary, currentValue) {
        const keys = Object.keys(dictionary);
        const values = Object.values(dictionary);
        const currentIndex = values.indexOf(currentValue);
        if (currentIndex !== -1 && currentIndex < values.length - 1) {
            return values[currentIndex + 1];
        }
        // Return null or handle the case when the current value is the last one
        return -1;
    }
    getKeyByIndex(dictionary, targetIndex) {
        const keys = Object.keys(dictionary);
        const values = Object.values(dictionary);
        const index = values.indexOf(targetIndex);
        if (index !== -1) {
            return keys[index];
        }
        // Return null or handle the case when the index is not found
        return keys[0];
    }
    isLastStep() {
        const values = Object.values(this.AppStep);
        const lastIndex = values.length - 1;
        return values[lastIndex] === this.StepIndex;
    }
    parseDate(dateObj, format) {
        return this.templateService.moment(dateObj).format(format);
    }
    isNumber(value) {
        if (value === null || value === undefined)
            return false;
        if (value === true || value === false)
            return false;
        if (value.length > 1 && value[0] === "0")
            return false;
        return !isNaN(Number(value));
    }
    ;
    isBoolean(value) {
        return typeof value === "string" && (value.toLowerCase() === "true" || value.toLowerCase() === "false");
    }
    ;
    parseValue(object, property, isFromCookie = false, isEmpty = false) {
        if (property === "") {
            return property;
        }
        if (property !== "" && this.isNumber(property)) {
            return parseFloat(property);
        }
        if (this.isBoolean(property)) {
            return property.toLowerCase() === "true";
        }
        if (isFromCookie) {
            return this.templateService.getCookie(this.cookieService, property);
        }
        if (typeof property === 'boolean') {
            return property;
        }
        const properties = property.split(".");
        let value = object;
        for (const prop of properties) {
            if (value.hasOwnProperty(prop)) {
                value = value[prop];
            }
            else {
                return this.queryParams.hasOwnProperty(property) ? this.queryParams[property] : isEmpty ? '' : property;
            }
        }
        // if (value !== "" && this.isNumber(value)) {
        //   value =  parseFloat(value);
        // }
        if (this.isBoolean(value)) {
            value = value.toLowerCase() === "true";
        }
        if (value === null || value === "null") {
            value = "";
        }
        return value;
    }
    generateParams(params) {
        return this.dicts;
    }
    transformToObject(opts = {
        arr: [],
        data: undefined,
        compType: "",
    }) {
        const { arr, data, compType } = opts;
        const transformedObject = {};
        for (const item of arr) {
            const { property, value } = item;
            const keys = this.cleansingParams(property).split(".");
            let currentObject = transformedObject;
            for (let i = 0; i < keys.length - 1; i++) {
                const key = keys[i];
                if (!currentObject[key]) {
                    if (Number.isInteger(Number(keys[i + 1]))) {
                        currentObject[key] = [];
                    }
                    else {
                        currentObject[key] = {};
                    }
                }
                currentObject = currentObject[key];
            }
            const x = (val, object) => {
                if (typeof val === 'boolean') {
                    return val;
                }
                if (typeof val === 'string' && val.includes(';')) {
                    const values = val.split(';');
                    const listValue = [];
                    for (const v of values) {
                        if (v === "")
                            continue;
                        listValue.push(this.parseValue(!!data ? data : this.dicts, v));
                    }
                    return listValue;
                }
                if (compType === "approvalcreate" || compType === "approvalcreate_manualdeviation") {
                    if (typeof val === 'string' && val.includes('_footer')) { //should been .endswith() but doubt with polyfill
                        return val;
                    }
                }
                return this.parseValue(object, val);
            };
            const lastKey = keys[keys.length - 1];
            currentObject[lastKey] = x(value, !!data ? data : this.dicts);
        }
        return transformedObject;
    }
    cleansingParams(params) {
        return params.replace(/\[(\d+)\]/g, '.$1');
    }
    textManipulation(input, data) {
        return input.replace(/\${(.*?)}/g, (match, placeholder) => {
            this.logger.log('match', match);
            this.logger.log('plaecholder', placeholder);
            const value = this.parseValue(data, this.cleansingParams(placeholder.trim()));
            return value !== undefined ? String(value) : match;
        });
    }
    transformStringValue(statement, dicts, dateFormat) {
        // Extract placeholder names
        const s = statement.match(/\${(.*?)}/g) || [];
        let v = [];
        for (let i of s) {
            v.push({ anchor: i, property: i.slice(2, -1) });
        }
        let r = statement;
        v.forEach(x => {
            const value = dateFormat ? this.parseDate(new Date(this.parseValue(dicts, x.property)), dateFormat) : this.parseValue(dicts, x.property);
            r = r.replace(x.anchor, value);
        });
        return r;
    }
    isStringManipulation(statement) {
        const s = statement.match(/\${(.*?)}/g) || [];
        return s.length !== 0;
    }
    buildUrl(baseUrl, path, params) {
        const queryParams = new URLSearchParams(params).toString();
        const url = new URL(path, baseUrl);
        url.search = queryParams;
        return url.href;
    }
    openUrl(url, target = '_self') {
        window.open(url, target);
    }
    getServiceUrl(environment, servicePath) {
        return !!this.templateService.urlConstant[servicePath] ? this.templateService.urlConstant[servicePath]
            : this.templateService.envConfig[environment] + servicePath;
    }
    invokeFunction(config) {
        const { target, methodName, args } = config;
        const transformedArgs = {};
        let params = transformedArgs;
        Object.keys(args).forEach(k => {
            const injector = this[args[k]];
            if (injector) {
                params[k] = injector;
            }
            else {
                params[k] = this.parseValue(this.dicts, this.cleansingParams(args[k]));
            }
        });
        if (target === 'self' && typeof this[methodName] === 'function') {
            return this[methodName](...Object.values(params));
        }
        // Invoke external method
        this.executor.invokeMethod(config, params);
    }
    httpExecutor(executor, dict) {
        const reqObj = (executor === null || executor === void 0 ? void 0 : executor.reqObj) || [];
        let props = [];
        reqObj.forEach(obj => {
            Object.keys(obj).forEach(key => {
                props.push({ property: key, value: obj[key] });
            });
        });
        this.dicts = Object.assign(this.dicts, dict);
        this.publishDictionary();
        const payload = this.transformToObject({ arr: props });
        const redirect = executor === null || executor === void 0 ? void 0 : executor.redirect;
        const path = redirect === null || redirect === void 0 ? void 0 : redirect.path;
        const params = (redirect === null || redirect === void 0 ? void 0 : redirect.param) || [];
        let _param = {};
        for (let param of params) {
            _param[param.property] = this.parseValue(dict, param.type);
        }
        const serviceUrl = this.getServiceUrl(executor.environment, executor.apiPath);
        this.http.post(serviceUrl, payload, AdInsConstant.SpinnerOptions).subscribe(() => {
            this.router.navigate([path], { queryParams: _param });
        }, err => {
            this.logger.log('something when wrong!', err);
        });
    }
    publishDictionary() {
        this.dicts = Object.assign(this.dicts, { formValid: this.Form.valid });
        this.dictionary.emit(this.dicts);
    }
    removeFormControl(controlName) {
        this.Form.removeControl(controlName);
    }
    flattenObject(obj, keyToFlatten) {
        const result = {};
        for (const key in obj) {
            if (key === keyToFlatten && typeof obj[key] === 'object') {
                // Flatten the nested object under the specified key
                const nestedObj = obj[key];
                for (const nestedKey in nestedObj) {
                    result[nestedKey] = nestedObj[nestedKey];
                }
            }
            else {
                // Keep other properties as they are
                result[key] = obj[key];
            }
        }
        return result;
    }
    setBorderRadius() {
        const _docElForm = document.getElementById("formComponent");
        const _docElDefault = document.getElementById("defaultComponent");
        if (_docElForm != undefined) {
            var __elForm = _docElForm.querySelector("div > :first-child").getElementsByTagName("lib-ucsubsection");
            setTimeout(() => {
                if (__elForm.length > 0) {
                    var __docElForm = __elForm[0].firstChild;
                    __docElForm.style.borderTopRightRadius = "8px";
                    __docElForm.style.borderTopLeftRadius = "8px";
                }
            }, 1);
        }
        if (_docElDefault != undefined) {
            var __elDefault = _docElDefault.querySelector("div > :first-child").getElementsByTagName("lib-ucsubsection");
            setTimeout(() => {
                if (__elDefault.length > 0) {
                    var __docElDefault = __elDefault[0].firstChild;
                    __docElDefault.style.borderTopRightRadius = "8px";
                    __docElDefault.style.borderTopLeftRadius = "8px";
                }
            }, 1);
        }
    }
    // function to format from yyyy-mm-dd to yyyy-mm
    FormatDateToYYYYMM(date) {
        const year = date.getFullYear();
        const month = (date.getMonth() + 1).toString().padStart(2, '0'); // Months are zero-based
        return `${year}-${month}`;
    }
}
UcTemplateComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: UcTemplateComponent, deps: [{ token: i1$1.FormBuilder }, { token: i2.Router }, { token: i2.ActivatedRoute }, { token: i3.HttpClient }, { token: i2$1.CookieService }, { token: i5.LocationStrategy }, { token: i6.FormAddressService }, { token: i0.ChangeDetectorRef }, { token: i6.FormLookupService }, { token: i7.FormArrayLookupService }, { token: i0.ComponentFactoryResolver }, { token: i0.Injector }, { token: i0.ApplicationRef }, { token: NGXToastrService }, { token: i6.UcFormSettingService }, { token: UcTemplateService }, { token: TempSelectionService }, { token: ExecutorService }, { token: i12.MatDialog }, { token: MAT_DIALOG_DATA }, { token: LocalStorageService }, { token: i14.Ucattribute2Service }, { token: i15.NgxRouterService }, { token: ScrollToErrService }, { token: LogService }], target: i0.ɵɵFactoryTarget.Component });
UcTemplateComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.3.12", type: UcTemplateComponent, selector: "adins-uctemplate", inputs: { data: "data", Form: "Form", pageName: "pageName", isDialog: "isDialog", isStepper: "isStepper", container: "container", params: "params", handler: "handler", selfCustom: "selfCustom", dialogRef: "dialogRef", idx: "idx", selectedIdxChange: "selectedIdxChange", parentDicts: "parentDicts", notify: "notify", notifyUpdateTableFooter: "notifyUpdateTableFooter", notifyUpdateTable: "notifyUpdateTable" }, outputs: { onBtnClick: "onBtnClick", next: "next", cbLookupManual: "cbLookupManual", dictionary: "dictionary", onFormCreated: "onFormCreated", onRefresh: "onRefresh", notifyUpdateDict: "notifyUpdateDict", notifyUpdateViewFileUpload: "notifyUpdateViewFileUpload", notifyOnReadyForm: "notifyOnReadyForm", onDismissModal: "onDismissModal" }, ngImport: i0, template: "<button *ngIf=\"isDialog\" style=\"position: relative; z-index: 9999; cursor: pointer\" aria-label=\"Close\" mat-dialog-close class=\"close\" translate=\"\" type=\"button\"><span aria-hidden=\"true\">\u00D7</span></button>\n\n<ng-container *ngIf=\"listIds.length === 1 && !hasFormComponent() && !isDialog; else detailTemplate\">\n  <div class=\"ucSearch-Button-Right\">\n    <span style=\"margin-right: 16px\">\n      <button type=\"button\" class=\"backButton\" (click)=\"back()\" *ngIf=\"templateObj?.backButton\">\n        <i class=\"fa fa-arrow-left\"> </i>&nbsp;<span translate>Back</span>\n      </button>\n\n      <ng-container *ngFor=\"let btn of topBtns\">\n        <button [type]=\"btn?.btnType\" class=\"addButton btn btn-raised mr-1\" [ngClass]=\"btn?.cssClass\" *ngIf=\"isBtnVisible(btn)\" (click)=\"btnListener(btn?.key, btn)\" translate>\n          <em class=\"far\" [ngClass]=\"btn?.icon\"></em> {{btn?.displayName}}\n        </button>\n      </ng-container>\n\n      <button type=\"button\" class=\"addButton\" (click)=\"gotoAddPage()\" *ngIf=\"templateObj?.addButton\">\n          <i class=\"ft-plus-circle\"></i>&nbsp;<span translate>Add</span>\n      </button>\n    </span>\n  </div>\n  <ng-container *ngTemplateOutlet=\"noFormComponent\"></ng-container>\n</ng-container>\n\n<ng-template #detailTemplate>\n  <div class=\"container-fluid\" [style.padding-left]=\"isDialog || isStepper ? '0' : '15px'\" [style.padding-right]=\"isDialog || isStepper ? '0' : '15px'\">\n    <div class=\"row text-left\">\n      <div class=\"col-md-12\" [style.padding-left]=\"isDialog || isStepper ? '4px' : '15px'\" [style.padding-right]=\"isDialog || isStepper ? '4px' : '15px'\">\n        <div class=\"card\" [style.box-shadow]=\"isDialog || isStepper ? 'none' : '0 6px 0px 0 rgba(0, 0, 0, 0.01), 0 15px 32px 0 rgba(0, 0, 0, 0.06)'\">\n          <div class=\"card-header header-title\" *ngIf=\"pageTitle\">\n            <div class=\"row\">\n              <div class=\"col-md-6\">\n                <div class=\"pl-3 mb-2 mt-2\">\n                  <h4 *ngIf=\"!templateObj?.hideTitle\" class=\"card-title\" id=\"horz-layout-colored-controls\" translate>{{pageTitle}}</h4>\n                </div>\n              </div>\n              <div class=\"col-md-6\">\n                <div class=\"px-3 ucSearch-Button-Right\">\n                  <span class=\"mr-1\">\n                    <button type=\"button\" class=\"backButton\" (click)=\"back()\" *ngIf=\"templateObj?.backButton\">\n                      <i class=\"fa fa-arrow-left\"> </i>&nbsp;<span translate>Back</span>\n                    </button>\n\n                    <ng-container *ngFor=\"let btn of topBtns\">\n                      <button type=\"button\" class=\"addButton btn btn-raised mr-1\" [ngClass]=\"btn?.cssClass\" *ngIf=\"isBtnVisible(btn)\" (click)=\"btnListener(btn?.key, btn)\" translate>\n                        <em class=\"far\" [ngClass]=\"btn?.icon\"></em> {{btn?.displayName}}\n                      </button>\n                    </ng-container>\n\n                    <button type=\"button\" class=\"addButton\" (click)=\"gotoAddPage()\" *ngIf=\"templateObj?.addButton\">\n                        <i class=\"ft-plus-circle\"></i>&nbsp;<span translate>Add</span>\n                    </button>\n                  </span>\n                </div>\n              </div>\n            </div>\n          </div>\n\n          <div class=\"card-body\">\n            <div [class.px-3]=\"!isDialog\">\n              <form *ngIf=\"hasFormComponent(); else noFormComponent\" class=\"form form-horizontal\" [formGroup]=\"Form\"\n                    (ngSubmit)=\"Form.valid && SaveForm()\" #enjiForm=\"ngForm\">\n\n                <ng-container *ngFor=\"let id of listIds\">\n                  <ng-container *ngTemplateOutlet=\"defaultComponent; context: {id: id}\"></ng-container>\n                  <ng-container *ngIf=\"getComponentType(id) === 'container' && isVisible(id)\">\n                    <div [attr.id]=\"getComponent(id, enjiForm)?.key\" class=\"uc-container\" [ngClass]=\"getCssClass(getComponent(id)?.key)\"></div>\n                  </ng-container>\n\n                  <div class=\"px-3 ucattr-class\" *ngIf=\"getComponentType(id) === 'attr' && isVisible(id)\">\n                    <lib-ucattribute [identifier]=\"getComponent(id)?.Variable\" [parentForm]=\"Form\" [enjiForm]=\"enjiForm\"\n                                     [AttrSetting]=\"getComponent(id)\"></lib-ucattribute>\n                  </div>\n\n                  <div class=\"px-3\" *ngIf=\"getComponentType(id) === 'form' && isVisible(id)\">\n                    <lib-ucform *ngIf=\"IsReady\" [inputObj]=\"getComponent(id, enjiForm)\" [parentForm]=\"Form\" [formAction]=\"callbackAction\"\n                                [enjiForm]=\"enjiForm\" [onDestroy]=\"onDestroyForm\"\n                                (callback)=\"callback($event)\" (cbLookupManual)=\"callbackLookup($event)\"\n                                (cbUpdateToFormArray)=\"callbackUpdateFormArr($event)\"\n                                (cbUpdateDict)=\"callbackUpdateDict($event)\"></lib-ucform>\n                  </div>\n\n                  <div class=\"px-3\" *ngIf=\"getComponentType(id) === 'formarray' && isVisible(id)\">\n                    <lib-ucformarray [inputObj]=\"getComponent(id, enjiForm)\" [parentForm]=\"Form\"\n                                     [enjiForm]=\"enjiForm\" [isCanAdd]=\"getComponent(id)?.canAdd\"\n                                     [addExternalNotify]=\"notifyUpdateFormArray\"\n                                     (cbUpdateDict)=\"callbackUpdateDict($event)\"></lib-ucformarray>\n                  </div>\n\n                  <ng-container *ngIf=\"(getComponentType(id) === 'approvalcreate' || getComponentType(id) === 'approvalcreate_manualdeviation') && isVisible(id)\">\n                    <lib-ucapprovalcreate [enjiForm]=\"enjiForm\" [InputObj]=\"getComponent(id)\"\n                                          *ngIf=\"ApvRfaReady && isHumanApproval\" [parentForm]=\"Form\"\n                                          [dictsSubscriber]=\"notifyUpdateDict\"></lib-ucapprovalcreate>\n                  </ng-container>\n\n                  <ng-container *ngIf=\"getComponentType(id) === 'approvalr3' && isVisible(id)\">\n                    <lib-ucapprovalR3 [InputObj]=\"getComponent(id)\" *ngIf=\"ApvReady\" (onCancel)=\"back()\"\n                                      (result)=\"callback($event)\">\n                    </lib-ucapprovalR3>\n                  </ng-container>\n                </ng-container>\n\n                <div class=\"form-actions right\" *ngIf=\"!ApvReady\">\n                  <button *ngIf=\"!hideCancelButton\" type=\"button\" class=\"btn btn-raised btn-warning mr-1\" (click)=\"back()\" translate>\n                    <em class=\"far fa-window-close\"></em> Cancel\n                  </button>\n\n                  <ng-container *ngFor=\"let btn of botBtns\">\n                    <button *ngIf=\"isBtnVisible(btn)\" [type]=\"btn?.btnType\" class=\"btn btn-raised mr-1\" [ngClass]=\"btn?.cssClass\" (click)=\"btnListener(btn?.key, btn)\" translate>\n                      <em class=\"far\" [ngClass]=\"btn?.icon\"></em> {{btn?.displayName}}\n                    </button>\n                  </ng-container>\n\n                  <button *ngIf=\"!hideSubmitButton\" type=\"submit\" class=\"btn btn-raised btn-primary\" translate>\n                    <em class=\"far fa-check-square\"></em> Submit\n                  </button>\n                </div>\n\n              </form>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</ng-template>\n\n<ng-template #noFormComponent>\n  <ng-container *ngFor=\"let id of listIds\">\n    <ng-container *ngIf=\"getComponentType(id) === 'container' && isVisible(id)\">\n      <div [attr.id]=\"getComponent(id, enjiForm)?.key\" class=\"uc-container\" [ngClass]=\"getCssClass(getComponent(id)?.key)\"></div>\n    </ng-container>\n    <ng-container *ngTemplateOutlet=\"defaultComponent; context: {id: id}\"></ng-container>\n  </ng-container>\n\n  <div class=\"form-actions text-right\">\n    <ng-container *ngFor=\"let btn of botBtns\">\n      <button *ngIf=\"isBtnVisible(btn)\" type=\"button\" class=\"btn btn-raised mr-1\" [ngClass]=\"btn?.cssClass\" (click)=\"btnListener(btn?.key, btn)\" translate>\n        <em class=\"far\" [ngClass]=\"btn?.icon\"></em> {{btn?.displayName}}\n      </button>\n    </ng-container>\n  </div>\n</ng-template>\n\n<ng-template #defaultComponent let-id=\"id\">\n  <lib-ucviewgeneric *ngIf=\"getComponentType(id) === 'view' && isVisible(id)\" [viewGenericObj]=\"getComponent(id)\"\n                     (callback)=\"callback($event)\"></lib-ucviewgeneric>\n\n  <ng-container *ngIf=\"getComponentType(id) === 'addtotemp' && isVisible(id)\">\n    <lib-ucaddtotemp [tempPagingObj]=\"getComponent(id)\" (callback)=\"getListTemp($event)\"\n                     (getSelected)=\"callback($event)\"></lib-ucaddtotemp>\n  </ng-container>\n\n  <ng-container *ngIf=\"getComponentType(id) === 'table' && isVisible(id)\">\n    <lib-uctable *ngIf=\"getComponent(id).isReady\" [id]=\"id\" [gridObj]=\"getComponent(id)\" \n    [notify]=\"notifyUpdateTable\" [dicts]=\"dicts\" (callback)=\"callback($event)\"\n    (cbUpdateDict)=\"callbackUpdateDict($event)\"></lib-uctable>\n  </ng-container>\n\n  <ng-container *ngIf=\"getComponentType(id) === 'paging' && isVisible(id)\">\n    <lib-ucpaging [searchObj]=\"getComponent(id)\" (callback)=\"callback($event)\"></lib-ucpaging>\n  </ng-container>\n\n  <lib-ucapprovalHistory [InputObj]=\"getComponent(id)\" *ngIf=\"getComponentType(id) === 'approvalhistory' && isVisible(id)\">\n  </lib-ucapprovalHistory>\n\n  <lib-ucapprovalgeneralinfo [InputObj]=\"getComponent(id)\" *ngIf=\"getComponentType(id) === 'approvalgeneralinfo' && isVisible(id)\">\n  </lib-ucapprovalgeneralinfo>\n\n  <lib-ucreport *ngIf=\"getComponentType(id) === 'report' && isVisible(id)\" [ReportInput]=\"getComponent(id)\"></lib-ucreport>\n\n  <lib-ucupload *ngIf=\"getComponentType(id) === 'upload' && isVisible(id)\" [uploadObj]='getComponent(id)'></lib-ucupload>\n\n  <div *ngIf=\"getComponentType(id) === 'stepper' && isVisible(id)\" [attr.id]=\"id\" class=\"bs-stepper\">\n    <div class=\"bs-stepper-header\" role=\"tablist\" style=\"overflow-x: auto;\">\n      <ng-container *ngFor=\"let tab of getComponent(id)?.tablist; let i = index; let isLast = last\">\n        <div class=\"step\" [attr.data-target]=\"'#' + tab.step.code + '-tab'\">\n          <button type=\"button\" class=\"step-trigger\" role=\"tab\" [attr.aria-controls]=\"tab.step.code + '-tab'\"\n                  [attr.id]=\"tab.step.code + '-tab-trigger'\" [disabled]=\"getComponent(id)?.linear === true ? !(StepIndex >= tab.step.index) : false\"\n                  (click)=\"ChangeTab(tab.step.code, tab)\">\n            <span *ngIf=\"!tab.completed\" class=\"bs-stepper-circle\">{{ tab.step.index }}</span>\n            <span *ngIf=\"tab.completed\" class=\"bs-stepper-circle completed\">\n              <i class=\"ft-check\"></i>\n            </span>\n            <span class=\"bs-stepper-label\">{{ tab.label }}</span>\n          </button>\n        </div>\n        <div *ngIf=\"!isLast\" class=\"line\" [ngClass]=\"{'completed-line': tab.completed && getComponent(id)?.linear === true}\"></div>\n      </ng-container>\n    </div>\n    <br/>\n    <div class=\"bs-stepper-content\" style=\"padding: 0 !important;\">\n      <!-- your steps content here -->\n      <div *ngFor=\"let tab of getComponent(id)?.tablist; let i = index\" [attr.id]=\"tab.step.code + '-tab'\" class=\"content\" role=\"tabpanel\" [attr.aria-labelledby]=\"tab.step.code + '-tab-trigger'\">\n        <ng-container *ngFor=\"let panel of tab?.panel\">\n          <adins-uctemplate *ngIf=\"StepIndex === tab.step.index && panel?.isTemplate\" [isStepper]=\"true\" [params]=\"generateParams(panel?.params)\"\n                            [pageName]=\"panel?.content\" [selectedIdxChange]=\"selectedIdxChange\"\n                            (dictionary)=\"onDictionary($event)\" (next)=\"onNext($event)\"></adins-uctemplate>\n          <div *ngIf=\"StepIndex === tab.step.index && !panel?.isTemplate\" [attr.id]=\"tab.step.code + '-' + panel?.content\" class=\"uc-container\"></div>\n        </ng-container>\n      </div>\n    </div>\n  </div>\n\n  <mat-tab-group *ngIf=\"getComponentType(id) === 'tabs' && isVisible(id)\" [attr.id]=\"id\" (selectedIndexChange)=\"onChangeTab(id, $event)\">\n    <ng-container *ngFor=\"let tab of getComponent(id)?.tablist; let i = index\">\n      <mat-tab [label]=\"tab?.label\" *ngIf=\"switchCase(tab?.panel[0]?.conditions)\">\n        <ng-container *ngFor=\"let panel of tab?.panel; let j = index\">\n          <adins-uctemplate *ngIf=\"panel?.isTemplate\" [isStepper]=\"true\" [params]=\"generateParams(panel?.params)\"\n                            [pageName]=\"panel?.content\" [selectedIdxChange]=\"selectedIdxChange\" (next)=\"onNext($event)\"></adins-uctemplate>\n          <div *ngIf=\"!panel?.isTemplate\" [attr.id]=\"getComponent(id+'-'+panel?.content+'-'+i, enjiForm)?.key\" class=\"uc-container mt-3\"\n               [ngClass]=\"getComponent(id+'-'+panel?.content+'-'+i, enjiForm)?.key\"></div>\n        </ng-container>\n      </mat-tab>\n    </ng-container>\n  </mat-tab-group>\n</ng-template>\n", styles: [".ucSearch-Button-Right{z-index:1;position:absolute;right:30px}.mat-dialog-container{background-color:#fff!important;color:#212121!important}.uc-container{margin-left:3px;margin-right:3px}.m-19{margin:3px 19px 0}.m-20{margin:3px 20px 0}::ng-deep .bs-stepper-label{margin-left:6px;color:#636e72}::ng-deep .bs-stepper-circle{color:#636e72;background-color:#fff!important;border:1px solid #636e72;align-items:center}::ng-deep .active .bs-stepper-circle{background-color:#007bff!important;color:#fff;border:1px solid #007bff;align-items:center}::ng-deep .step-trigger{padding:8px!important}::ng-deep .bs-stepper .line,.bs-stepper-line{flex:1 0 100px}::ng-deep .completed{background-color:var(--white, #fdfeff)!important;color:var(--blue-primary, #246cfe)!important;border:1px solid var(--blue-primary, #246cfe)!important;align-items:center}.completed-line{background-color:#007bff!important;align-items:center}ps-scrollbar-y-rail{display:none!important}::-webkit-scrollbar{width:12px}::-webkit-scrollbar-track{box-shadow:inset 0 0 10px 10px #fff0;border:solid 3px transparent}::-webkit-scrollbar-thumb{box-shadow:inset 0 0 10px 10px #c6c6c6;border:solid 3px transparent;border-radius:1em}::-webkit-scrollbar-button{height:290px}\n"], components: [{ type: i14.Ucattribute2Component, selector: "lib-ucattribute", inputs: ["enjiForm", "parentForm", "identifier", "AttrSetting", "dicts"] }, { type: i6.UcFormComponent, selector: "lib-ucform", inputs: ["inputObj", "parentForm", "enjiForm", "formAction", "onDestroy", "isPersist", "localStorageSvc", "formSubject"], outputs: ["callback", "cbLookupManual", "cbUpdateToFormArray", "cbUpdateDict", "cbOnReadyForm"] }, { type: i7.UcformarrayComponent, selector: "lib-ucformarray", inputs: ["inputObj", "parentForm", "enjiForm", "isCanAdd", "addExternalNotify"], outputs: ["callback", "cbLookupManual", "callbackBtn", "cbUpdateDict"] }, { type: i16.UcapprovalcreateComponent, selector: "lib-ucapprovalcreate", inputs: ["InputObj", "parentForm", "enjiForm", "dictsSubscriber"], outputs: ["result"] }, { type: i17.UcapprovalR3Component, selector: "lib-ucapprovalR3", inputs: ["InputObj"], outputs: ["result", "onCancel"] }, { type: i18.UcviewgenericComponent, selector: "lib-ucviewgeneric", inputs: ["viewGenericObj", "gridViewObj", "refresh"], outputs: ["callback"] }, { type: i19.UcaddtotempComponent, selector: "lib-ucaddtotemp", inputs: ["tempPagingObj"], outputs: ["callback", "getSelected", "viewcallback", "callbackReqGetAllData"] }, { type: i20.UctableComponent, selector: "lib-uctable", inputs: ["pageSize", "gridObj", "notify", "notifyUpdateFooter", "btnCallback", "dicts", "standalone", "classPadding"], outputs: ["callback", "cbUpdateDict"] }, { type: i21.UcpagingComponent, selector: "lib-ucpaging", inputs: ["searchObj"], outputs: ["callback", "callbackCheckBox", "callbackReqGetAllData", "callbackPageChange", "callbackPagingResult"] }, { type: i22.UcapprovalHistoryComponent, selector: "lib-ucapprovalHistory", inputs: ["InputObj"] }, { type: i23.UcapprovalgeneralinfoComponent, selector: "lib-ucapprovalgeneralinfo", inputs: ["InputObj"] }, { type: i24.UcreportComponent, selector: "lib-ucreport", inputs: ["ReportInput"] }, { type: i25.UcuploadComponent, selector: "lib-ucupload", inputs: ["uploadObj", "resetUpload"], outputs: ["ApiResponse"] }, { type: UcTemplateComponent, selector: "adins-uctemplate", inputs: ["data", "Form", "pageName", "isDialog", "isStepper", "container", "params", "handler", "selfCustom", "dialogRef", "idx", "selectedIdxChange", "parentDicts", "notify", "notifyUpdateTableFooter", "notifyUpdateTable"], outputs: ["onBtnClick", "next", "cbLookupManual", "dictionary", "onFormCreated", "onRefresh", "notifyUpdateDict", "notifyUpdateViewFileUpload", "notifyOnReadyForm", "onDismissModal"] }, { type: i26.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "disableRipple"], exportAs: ["matTabGroup"] }, { type: i26.MatTab, selector: "mat-tab", inputs: ["disabled", "label", "aria-label", "aria-labelledby", "labelClass", "bodyClass"], exportAs: ["matTab"] }], directives: [{ type: i5.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i12.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { type: i5.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i5.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { type: i5.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet"] }, { type: i1$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { type: i1$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { type: i1$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: UcTemplateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'adins-uctemplate', template: "<button *ngIf=\"isDialog\" style=\"position: relative; z-index: 9999; cursor: pointer\" aria-label=\"Close\" mat-dialog-close class=\"close\" translate=\"\" type=\"button\"><span aria-hidden=\"true\">\u00D7</span></button>\n\n<ng-container *ngIf=\"listIds.length === 1 && !hasFormComponent() && !isDialog; else detailTemplate\">\n  <div class=\"ucSearch-Button-Right\">\n    <span style=\"margin-right: 16px\">\n      <button type=\"button\" class=\"backButton\" (click)=\"back()\" *ngIf=\"templateObj?.backButton\">\n        <i class=\"fa fa-arrow-left\"> </i>&nbsp;<span translate>Back</span>\n      </button>\n\n      <ng-container *ngFor=\"let btn of topBtns\">\n        <button [type]=\"btn?.btnType\" class=\"addButton btn btn-raised mr-1\" [ngClass]=\"btn?.cssClass\" *ngIf=\"isBtnVisible(btn)\" (click)=\"btnListener(btn?.key, btn)\" translate>\n          <em class=\"far\" [ngClass]=\"btn?.icon\"></em> {{btn?.displayName}}\n        </button>\n      </ng-container>\n\n      <button type=\"button\" class=\"addButton\" (click)=\"gotoAddPage()\" *ngIf=\"templateObj?.addButton\">\n          <i class=\"ft-plus-circle\"></i>&nbsp;<span translate>Add</span>\n      </button>\n    </span>\n  </div>\n  <ng-container *ngTemplateOutlet=\"noFormComponent\"></ng-container>\n</ng-container>\n\n<ng-template #detailTemplate>\n  <div class=\"container-fluid\" [style.padding-left]=\"isDialog || isStepper ? '0' : '15px'\" [style.padding-right]=\"isDialog || isStepper ? '0' : '15px'\">\n    <div class=\"row text-left\">\n      <div class=\"col-md-12\" [style.padding-left]=\"isDialog || isStepper ? '4px' : '15px'\" [style.padding-right]=\"isDialog || isStepper ? '4px' : '15px'\">\n        <div class=\"card\" [style.box-shadow]=\"isDialog || isStepper ? 'none' : '0 6px 0px 0 rgba(0, 0, 0, 0.01), 0 15px 32px 0 rgba(0, 0, 0, 0.06)'\">\n          <div class=\"card-header header-title\" *ngIf=\"pageTitle\">\n            <div class=\"row\">\n              <div class=\"col-md-6\">\n                <div class=\"pl-3 mb-2 mt-2\">\n                  <h4 *ngIf=\"!templateObj?.hideTitle\" class=\"card-title\" id=\"horz-layout-colored-controls\" translate>{{pageTitle}}</h4>\n                </div>\n              </div>\n              <div class=\"col-md-6\">\n                <div class=\"px-3 ucSearch-Button-Right\">\n                  <span class=\"mr-1\">\n                    <button type=\"button\" class=\"backButton\" (click)=\"back()\" *ngIf=\"templateObj?.backButton\">\n                      <i class=\"fa fa-arrow-left\"> </i>&nbsp;<span translate>Back</span>\n                    </button>\n\n                    <ng-container *ngFor=\"let btn of topBtns\">\n                      <button type=\"button\" class=\"addButton btn btn-raised mr-1\" [ngClass]=\"btn?.cssClass\" *ngIf=\"isBtnVisible(btn)\" (click)=\"btnListener(btn?.key, btn)\" translate>\n                        <em class=\"far\" [ngClass]=\"btn?.icon\"></em> {{btn?.displayName}}\n                      </button>\n                    </ng-container>\n\n                    <button type=\"button\" class=\"addButton\" (click)=\"gotoAddPage()\" *ngIf=\"templateObj?.addButton\">\n                        <i class=\"ft-plus-circle\"></i>&nbsp;<span translate>Add</span>\n                    </button>\n                  </span>\n                </div>\n              </div>\n            </div>\n          </div>\n\n          <div class=\"card-body\">\n            <div [class.px-3]=\"!isDialog\">\n              <form *ngIf=\"hasFormComponent(); else noFormComponent\" class=\"form form-horizontal\" [formGroup]=\"Form\"\n                    (ngSubmit)=\"Form.valid && SaveForm()\" #enjiForm=\"ngForm\">\n\n                <ng-container *ngFor=\"let id of listIds\">\n                  <ng-container *ngTemplateOutlet=\"defaultComponent; context: {id: id}\"></ng-container>\n                  <ng-container *ngIf=\"getComponentType(id) === 'container' && isVisible(id)\">\n                    <div [attr.id]=\"getComponent(id, enjiForm)?.key\" class=\"uc-container\" [ngClass]=\"getCssClass(getComponent(id)?.key)\"></div>\n                  </ng-container>\n\n                  <div class=\"px-3 ucattr-class\" *ngIf=\"getComponentType(id) === 'attr' && isVisible(id)\">\n                    <lib-ucattribute [identifier]=\"getComponent(id)?.Variable\" [parentForm]=\"Form\" [enjiForm]=\"enjiForm\"\n                                     [AttrSetting]=\"getComponent(id)\"></lib-ucattribute>\n                  </div>\n\n                  <div class=\"px-3\" *ngIf=\"getComponentType(id) === 'form' && isVisible(id)\">\n                    <lib-ucform *ngIf=\"IsReady\" [inputObj]=\"getComponent(id, enjiForm)\" [parentForm]=\"Form\" [formAction]=\"callbackAction\"\n                                [enjiForm]=\"enjiForm\" [onDestroy]=\"onDestroyForm\"\n                                (callback)=\"callback($event)\" (cbLookupManual)=\"callbackLookup($event)\"\n                                (cbUpdateToFormArray)=\"callbackUpdateFormArr($event)\"\n                                (cbUpdateDict)=\"callbackUpdateDict($event)\"></lib-ucform>\n                  </div>\n\n                  <div class=\"px-3\" *ngIf=\"getComponentType(id) === 'formarray' && isVisible(id)\">\n                    <lib-ucformarray [inputObj]=\"getComponent(id, enjiForm)\" [parentForm]=\"Form\"\n                                     [enjiForm]=\"enjiForm\" [isCanAdd]=\"getComponent(id)?.canAdd\"\n                                     [addExternalNotify]=\"notifyUpdateFormArray\"\n                                     (cbUpdateDict)=\"callbackUpdateDict($event)\"></lib-ucformarray>\n                  </div>\n\n                  <ng-container *ngIf=\"(getComponentType(id) === 'approvalcreate' || getComponentType(id) === 'approvalcreate_manualdeviation') && isVisible(id)\">\n                    <lib-ucapprovalcreate [enjiForm]=\"enjiForm\" [InputObj]=\"getComponent(id)\"\n                                          *ngIf=\"ApvRfaReady && isHumanApproval\" [parentForm]=\"Form\"\n                                          [dictsSubscriber]=\"notifyUpdateDict\"></lib-ucapprovalcreate>\n                  </ng-container>\n\n                  <ng-container *ngIf=\"getComponentType(id) === 'approvalr3' && isVisible(id)\">\n                    <lib-ucapprovalR3 [InputObj]=\"getComponent(id)\" *ngIf=\"ApvReady\" (onCancel)=\"back()\"\n                                      (result)=\"callback($event)\">\n                    </lib-ucapprovalR3>\n                  </ng-container>\n                </ng-container>\n\n                <div class=\"form-actions right\" *ngIf=\"!ApvReady\">\n                  <button *ngIf=\"!hideCancelButton\" type=\"button\" class=\"btn btn-raised btn-warning mr-1\" (click)=\"back()\" translate>\n                    <em class=\"far fa-window-close\"></em> Cancel\n                  </button>\n\n                  <ng-container *ngFor=\"let btn of botBtns\">\n                    <button *ngIf=\"isBtnVisible(btn)\" [type]=\"btn?.btnType\" class=\"btn btn-raised mr-1\" [ngClass]=\"btn?.cssClass\" (click)=\"btnListener(btn?.key, btn)\" translate>\n                      <em class=\"far\" [ngClass]=\"btn?.icon\"></em> {{btn?.displayName}}\n                    </button>\n                  </ng-container>\n\n                  <button *ngIf=\"!hideSubmitButton\" type=\"submit\" class=\"btn btn-raised btn-primary\" translate>\n                    <em class=\"far fa-check-square\"></em> Submit\n                  </button>\n                </div>\n\n              </form>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</ng-template>\n\n<ng-template #noFormComponent>\n  <ng-container *ngFor=\"let id of listIds\">\n    <ng-container *ngIf=\"getComponentType(id) === 'container' && isVisible(id)\">\n      <div [attr.id]=\"getComponent(id, enjiForm)?.key\" class=\"uc-container\" [ngClass]=\"getCssClass(getComponent(id)?.key)\"></div>\n    </ng-container>\n    <ng-container *ngTemplateOutlet=\"defaultComponent; context: {id: id}\"></ng-container>\n  </ng-container>\n\n  <div class=\"form-actions text-right\">\n    <ng-container *ngFor=\"let btn of botBtns\">\n      <button *ngIf=\"isBtnVisible(btn)\" type=\"button\" class=\"btn btn-raised mr-1\" [ngClass]=\"btn?.cssClass\" (click)=\"btnListener(btn?.key, btn)\" translate>\n        <em class=\"far\" [ngClass]=\"btn?.icon\"></em> {{btn?.displayName}}\n      </button>\n    </ng-container>\n  </div>\n</ng-template>\n\n<ng-template #defaultComponent let-id=\"id\">\n  <lib-ucviewgeneric *ngIf=\"getComponentType(id) === 'view' && isVisible(id)\" [viewGenericObj]=\"getComponent(id)\"\n                     (callback)=\"callback($event)\"></lib-ucviewgeneric>\n\n  <ng-container *ngIf=\"getComponentType(id) === 'addtotemp' && isVisible(id)\">\n    <lib-ucaddtotemp [tempPagingObj]=\"getComponent(id)\" (callback)=\"getListTemp($event)\"\n                     (getSelected)=\"callback($event)\"></lib-ucaddtotemp>\n  </ng-container>\n\n  <ng-container *ngIf=\"getComponentType(id) === 'table' && isVisible(id)\">\n    <lib-uctable *ngIf=\"getComponent(id).isReady\" [id]=\"id\" [gridObj]=\"getComponent(id)\" \n    [notify]=\"notifyUpdateTable\" [dicts]=\"dicts\" (callback)=\"callback($event)\"\n    (cbUpdateDict)=\"callbackUpdateDict($event)\"></lib-uctable>\n  </ng-container>\n\n  <ng-container *ngIf=\"getComponentType(id) === 'paging' && isVisible(id)\">\n    <lib-ucpaging [searchObj]=\"getComponent(id)\" (callback)=\"callback($event)\"></lib-ucpaging>\n  </ng-container>\n\n  <lib-ucapprovalHistory [InputObj]=\"getComponent(id)\" *ngIf=\"getComponentType(id) === 'approvalhistory' && isVisible(id)\">\n  </lib-ucapprovalHistory>\n\n  <lib-ucapprovalgeneralinfo [InputObj]=\"getComponent(id)\" *ngIf=\"getComponentType(id) === 'approvalgeneralinfo' && isVisible(id)\">\n  </lib-ucapprovalgeneralinfo>\n\n  <lib-ucreport *ngIf=\"getComponentType(id) === 'report' && isVisible(id)\" [ReportInput]=\"getComponent(id)\"></lib-ucreport>\n\n  <lib-ucupload *ngIf=\"getComponentType(id) === 'upload' && isVisible(id)\" [uploadObj]='getComponent(id)'></lib-ucupload>\n\n  <div *ngIf=\"getComponentType(id) === 'stepper' && isVisible(id)\" [attr.id]=\"id\" class=\"bs-stepper\">\n    <div class=\"bs-stepper-header\" role=\"tablist\" style=\"overflow-x: auto;\">\n      <ng-container *ngFor=\"let tab of getComponent(id)?.tablist; let i = index; let isLast = last\">\n        <div class=\"step\" [attr.data-target]=\"'#' + tab.step.code + '-tab'\">\n          <button type=\"button\" class=\"step-trigger\" role=\"tab\" [attr.aria-controls]=\"tab.step.code + '-tab'\"\n                  [attr.id]=\"tab.step.code + '-tab-trigger'\" [disabled]=\"getComponent(id)?.linear === true ? !(StepIndex >= tab.step.index) : false\"\n                  (click)=\"ChangeTab(tab.step.code, tab)\">\n            <span *ngIf=\"!tab.completed\" class=\"bs-stepper-circle\">{{ tab.step.index }}</span>\n            <span *ngIf=\"tab.completed\" class=\"bs-stepper-circle completed\">\n              <i class=\"ft-check\"></i>\n            </span>\n            <span class=\"bs-stepper-label\">{{ tab.label }}</span>\n          </button>\n        </div>\n        <div *ngIf=\"!isLast\" class=\"line\" [ngClass]=\"{'completed-line': tab.completed && getComponent(id)?.linear === true}\"></div>\n      </ng-container>\n    </div>\n    <br/>\n    <div class=\"bs-stepper-content\" style=\"padding: 0 !important;\">\n      <!-- your steps content here -->\n      <div *ngFor=\"let tab of getComponent(id)?.tablist; let i = index\" [attr.id]=\"tab.step.code + '-tab'\" class=\"content\" role=\"tabpanel\" [attr.aria-labelledby]=\"tab.step.code + '-tab-trigger'\">\n        <ng-container *ngFor=\"let panel of tab?.panel\">\n          <adins-uctemplate *ngIf=\"StepIndex === tab.step.index && panel?.isTemplate\" [isStepper]=\"true\" [params]=\"generateParams(panel?.params)\"\n                            [pageName]=\"panel?.content\" [selectedIdxChange]=\"selectedIdxChange\"\n                            (dictionary)=\"onDictionary($event)\" (next)=\"onNext($event)\"></adins-uctemplate>\n          <div *ngIf=\"StepIndex === tab.step.index && !panel?.isTemplate\" [attr.id]=\"tab.step.code + '-' + panel?.content\" class=\"uc-container\"></div>\n        </ng-container>\n      </div>\n    </div>\n  </div>\n\n  <mat-tab-group *ngIf=\"getComponentType(id) === 'tabs' && isVisible(id)\" [attr.id]=\"id\" (selectedIndexChange)=\"onChangeTab(id, $event)\">\n    <ng-container *ngFor=\"let tab of getComponent(id)?.tablist; let i = index\">\n      <mat-tab [label]=\"tab?.label\" *ngIf=\"switchCase(tab?.panel[0]?.conditions)\">\n        <ng-container *ngFor=\"let panel of tab?.panel; let j = index\">\n          <adins-uctemplate *ngIf=\"panel?.isTemplate\" [isStepper]=\"true\" [params]=\"generateParams(panel?.params)\"\n                            [pageName]=\"panel?.content\" [selectedIdxChange]=\"selectedIdxChange\" (next)=\"onNext($event)\"></adins-uctemplate>\n          <div *ngIf=\"!panel?.isTemplate\" [attr.id]=\"getComponent(id+'-'+panel?.content+'-'+i, enjiForm)?.key\" class=\"uc-container mt-3\"\n               [ngClass]=\"getComponent(id+'-'+panel?.content+'-'+i, enjiForm)?.key\"></div>\n        </ng-container>\n      </mat-tab>\n    </ng-container>\n  </mat-tab-group>\n</ng-template>\n", styles: [".ucSearch-Button-Right{z-index:1;position:absolute;right:30px}.mat-dialog-container{background-color:#fff!important;color:#212121!important}.uc-container{margin-left:3px;margin-right:3px}.m-19{margin:3px 19px 0}.m-20{margin:3px 20px 0}::ng-deep .bs-stepper-label{margin-left:6px;color:#636e72}::ng-deep .bs-stepper-circle{color:#636e72;background-color:#fff!important;border:1px solid #636e72;align-items:center}::ng-deep .active .bs-stepper-circle{background-color:#007bff!important;color:#fff;border:1px solid #007bff;align-items:center}::ng-deep .step-trigger{padding:8px!important}::ng-deep .bs-stepper .line,.bs-stepper-line{flex:1 0 100px}::ng-deep .completed{background-color:var(--white, #fdfeff)!important;color:var(--blue-primary, #246cfe)!important;border:1px solid var(--blue-primary, #246cfe)!important;align-items:center}.completed-line{background-color:#007bff!important;align-items:center}ps-scrollbar-y-rail{display:none!important}::-webkit-scrollbar{width:12px}::-webkit-scrollbar-track{box-shadow:inset 0 0 10px 10px #fff0;border:solid 3px transparent}::-webkit-scrollbar-thumb{box-shadow:inset 0 0 10px 10px #c6c6c6;border:solid 3px transparent;border-radius:1em}::-webkit-scrollbar-button{height:290px}\n"] }]
        }], ctorParameters: function () {
        return [{ type: i1$1.FormBuilder }, { type: i2.Router }, { type: i2.ActivatedRoute }, { type: i3.HttpClient }, { type: i2$1.CookieService }, { type: i5.LocationStrategy }, { type: i6.FormAddressService }, { type: i0.ChangeDetectorRef }, { type: i6.FormLookupService }, { type: i7.FormArrayLookupService }, { type: i0.ComponentFactoryResolver }, { type: i0.Injector }, { type: i0.ApplicationRef }, { type: NGXToastrService }, { type: i6.UcFormSettingService }, { type: UcTemplateService }, { type: TempSelectionService }, { type: ExecutorService }, { type: i12.MatDialog }, { type: undefined, decorators: [{
                        type: Inject,
                        args: [MAT_DIALOG_DATA]
                    }] }, { type: LocalStorageService }, { type: i14.Ucattribute2Service }, { type: i15.NgxRouterService }, { type: ScrollToErrService }, { type: LogService }];
    }, propDecorators: { data: [{
                type: Input
            }], Form: [{
                type: Input
            }], pageName: [{
                type: Input
            }], isDialog: [{
                type: Input
            }], isStepper: [{
                type: Input
            }], container: [{
                type: Input
            }], params: [{
                type: Input
            }], handler: [{
                type: Input
            }], selfCustom: [{
                type: Input
            }], dialogRef: [{
                type: Input
            }], idx: [{
                type: Input
            }], selectedIdxChange: [{
                type: Input
            }], parentDicts: [{
                type: Input
            }], notify: [{
                type: Input
            }], notifyUpdateTableFooter: [{
                type: Input
            }], notifyUpdateTable: [{
                type: Input
            }], onBtnClick: [{
                type: Output
            }], next: [{
                type: Output
            }], cbLookupManual: [{
                type: Output
            }], dictionary: [{
                type: Output
            }], onFormCreated: [{
                type: Output
            }], onRefresh: [{
                type: Output
            }], notifyUpdateDict: [{
                type: Output
            }], notifyUpdateViewFileUpload: [{
                type: Output
            }], notifyOnReadyForm: [{
                type: Output
            }], onDismissModal: [{
                type: Output
            }] } });

class UcTemplateModule {
}
UcTemplateModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: UcTemplateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
UcTemplateModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: UcTemplateModule, declarations: [UcTemplateComponent], imports: [CommonModule,
        ReactiveFormsModule,
        FormsModule,
        NgbModule,
        UcDirectiveUpperCaseModule,
        UcpagingModule,
        UcgridviewModule,
        UcformModule,
        UcformarrayModule,
        UcaddtotempModule,
        UcviewgenericModule,
        UcSubsectionModule,
        UcreportModule,
        UcuploadModule,
        UcapprovalcreateModule,
        UcapprovalR3Module,
        UctableModule,
        Ucattribute2Module,
        UcapprovalgeneralinfoModule,
        UcapprovalHistoryModule,
        UcFileUploadModule,
        UcviewfileuploadModule,
        MatDialogModule,
        MatTabsModule,
        NgbModalModule,
        NgbCollapseModule,
        RouterModule], exports: [UcTemplateComponent] });
UcTemplateModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: UcTemplateModule, providers: [
        { provide: MAT_DIALOG_DATA, useValue: {} },
        NGXToastrService
    ], imports: [[
            CommonModule,
            ReactiveFormsModule,
            FormsModule,
            NgbModule,
            UcDirectiveUpperCaseModule,
            UcpagingModule,
            UcgridviewModule,
            UcformModule,
            UcformarrayModule,
            UcaddtotempModule,
            UcviewgenericModule,
            UcSubsectionModule,
            UcreportModule,
            UcuploadModule,
            UcapprovalcreateModule,
            UcapprovalR3Module,
            UctableModule,
            Ucattribute2Module,
            UcapprovalgeneralinfoModule,
            UcapprovalHistoryModule,
            UcFileUploadModule,
            UcviewfileuploadModule,
            MatDialogModule,
            MatTabsModule,
            NgbModalModule,
            NgbCollapseModule,
            RouterModule,
        ]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: UcTemplateModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        UcTemplateComponent
                    ],
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        FormsModule,
                        NgbModule,
                        UcDirectiveUpperCaseModule,
                        UcpagingModule,
                        UcgridviewModule,
                        UcformModule,
                        UcformarrayModule,
                        UcaddtotempModule,
                        UcviewgenericModule,
                        UcSubsectionModule,
                        UcreportModule,
                        UcuploadModule,
                        UcapprovalcreateModule,
                        UcapprovalR3Module,
                        UctableModule,
                        Ucattribute2Module,
                        UcapprovalgeneralinfoModule,
                        UcapprovalHistoryModule,
                        UcFileUploadModule,
                        UcviewfileuploadModule,
                        MatDialogModule,
                        MatTabsModule,
                        NgbModalModule,
                        NgbCollapseModule,
                        RouterModule,
                    ],
                    exports: [
                        UcTemplateComponent
                    ],
                    providers: [
                        { provide: MAT_DIALOG_DATA, useValue: {} },
                        NGXToastrService
                    ]
                }]
        }] });

/*
 * Public API Surface of uctemplate
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ActiveSessionService, BroadcastReceiverService, ContainerService, ExecutorService, LogService, ScrollToErrService, TempSelectionService, UcTemplateComponent, UcTemplateModule, UcTemplateService };
//# sourceMappingURL=adins-uctemplate.mjs.map
