# UcTemplate

This library was generated with [Angular CLI](https://github.com/angular/angular-cli) version 13.3.0.

## Code scaffolding

Run `ng generate component component-name --project uctemplate` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module --project uctemplate`.
> Note: Don't forget to add `--project uctemplate` or else it will be added to the default project in your `angular.json` file. 

## Version
notes:new ui under canary.x tags

Version 1.12.60
1. Fix Zero value parsed to empty string

Version 1.12.59
1. expose notifyUpdateTable
2. expose list component via listMapComponent on uctemplateservice
3. fix re-compile container after component hidden

Vesion 1.12.58
1. Fix mapping object to form

Versino 1.12.57
1. fix form edit in modal dialog

Version 1.12.56
1. support return array from modal with form array

Version 1.12.55
1. fix form edit in modal dialog

Version 1.12.54
1. fix callback action not work in stepper content

Version 1.12.53
1. fix form when multiple page has been loaded

Version 1.12.52
1. fix dict data in dialog mode template
2. fix return data of empty array object

Version 1.12.51
1. fix modal form not loaded in production and safeUrl mode

Version 1.12.50
1. fix duplicate submit on safeUrl mode

Version 1.12.49
1. fix modal form not loaded in stepper

Version 1.12.48
1. fix override form edit mode in stepper

Version 1.12.47
1. add safeUrl for action button link

Version 1.12.46
1. pass data for subreport on compileReport

Version 1.12.45
1. add option closeButton on toastr
2. add waitFor on modalAction if params inlcudes formRaw

Version 1.12.44
1. fix waitFor if includes formRaw

Version 1.12.43
1. fix navconstant for compile add to temp

Version 1.12.42
1. fix queryparams data values to dictionary data

Version 1.12.41
1. fix cannot call callback.handler from tab component

Version 1.12.40
1. fix transform payload for set approval object

Version 1.12.39
1. add new output `onDismissModal`
2. add new type `cbUpdateCreateApvScheme` for input notify - will re-render createRFA component

Version 1.12.38
1. pass enviconfig information for textManipulation (toastr)

Version 1.12.37
1. fix callback - will emit callback handler if value has a key property
2. add scrollToErrService
3. enable html for toastr

Version 1.12.36
1. fix conditional title

Version 1.12.35
1. pass hideWhenEmpty property for compileviewfileupload

Version 1.12.34
1. add IsReturnToRequestorOnly property - on compile approval multi component

Version 1.12.33
1. set disableClose to true on modal action
2. add isCollapsed property - on form - for configurable subsection collapse
3. add IsHideNewRfa property - on compile createrfa component
4. add IsReturnToRequestorOnly property - on compile approval component
5. fix createInitialForm - not return on recompile createRfa
6. fix notify subscriber - now won't throw error when subscribe multiple times

Version 1.12.32
1. add dicts to persistData (now only 'ApproverUsername' - configurable in the future)

Version 1.12.31
1. fix parseValue and getValue - now null or "null" value will treated as ""

Version 1.12.30
1. add notify input - will run a function for certain type

Version 1.12.29
1. fix modal action - now also emit onFormCreated and notifyUpdateViewFileUpload
2. pass formSubject input to ucform

Version 1.12.28
1. add method isDisable component button

Version 1.12.27
1. add new input `notifyUpdateTableFooter`

Version 1.12.26
1. add new component - approvalr3_multi

Version 1.12.25
1. on/off safe url with useSafeUrl property

Version 1.12.23
1. add output notifyOnReadyForm, from the form callback - cbOnReadyForm

Version 1.12.22
1. change deleteEnvironment to environment on compileViewFileUpload

Version 1.12.21
1. pass property canDelete, deleteEnvironment, and deleteApiPath for ucviewfileupload
2. add new output `updateViewFileDocLength` - will emit info of ucviewfileupload 
3. fix fromValue for compilePaging

Version 1.12.20
1. fix notify form parameter - now send boolean and formId
2. new output notifyUpdateDict
3. bump minimum version of ucform peer deps to 3.7.19

Version 1.12.19
1. support text format for ProcessKey using `${some_var_here}` keyword

Version 1.12.18
1. fix set trxno on compileCreateRfa

Version 1.12.17
1. pass trx no to compileCreateRfa

Version 1.12.16
1. pass defaultApprover on compileCreateRfa & compileCreateRfaManualDeviation

Version 1.12.15
1. add feature integration obj for add to temp
2. fix additional request on submit apv
3. pass show approval history & notes required when on compileApproval

Version 1.12.14
1. add support to read dicts from tab (stored on dicts.childDicts)
2. add support to change display name for submit button

Version 1.12.13
1. set defaultChecked on compile gridview (for uctable)

Version 1.12.12
1. fix switch case guard

Version 1.12.11
1. fix uctable pagination logic

Version 1.12.10
1. pass local storage service to ucform
2. fix form on multiple tabs component (line commented)

Version 1.12.9
1. add support for callback action type cbUpdateCreateApvScheme
2. add guard if navconstant undefined

Version 1.12.8
1. fix formarray callback not handled properly

Version 1.12.7
1. fix button path can use variable from navconstant

Version 1.12.6
1. pass templateService to ucTempPagingObj
2. support viewCallback output from ucaddtotemp

Version 1.12.5
1. pass isPersist Prop to form
2. Add modal on side feature
3. padding adjustment on modal

Version 1.12.4
1. Add on destroy event emitter

Version 1.12.3
1. Add support notifyUpdateDict in input data dictionary

Version 1.12.2
1. add support auto scroll to active step
2. pass useFourColl option for address

Version 1.12.1
1. add support for postfix concatination on ProcessKey, ProcessKeys, and TaskDefinitionKey
2. pass requiredNotes props on compileapproval, compilecreaterfa, and compilecreaterfamanualdev

Version 1.12.0
1. Add support component create approval manual deviation

Version 1.11.4
1. fix set ownership code value - will set to empty string if value is null

Version 1.11.3
1. set environment for ucaddress - used to get business date inside ucaddress
2. fix guard for set address stay since
3. add custom environment url for component report

Version 1.11.2
1. fix set address stay since date format

Version 1.11.1
1. add guard clause for getSetEditObj on hide component subscriber

Version 1.11.0
1. Add new service Active Session
2. Add new service Broadcast Receiver
3. Add fetch data from local storage using index key

Version 1.10.32
1. Add custom upload url in compile upload

Version 1.10.31
1. Fix localStorage persistent page

Version 1.10.30
1. Add breakable switch case action

Version 1.10.29
1. fix button class size for btn-primary-2, btn-outline-2, and btn-danger-2

Version 1.10.28
1. add rounded border for top-most subsection
2. add rounded corner for card

Version 1.10.27
1. Fix form reset after open modal view
2. Fix file upload component mode edit in modal view
3. Add api method for notify update view component
4. Add NextStepCode into dictionary
5. Add NotifyUpdateView input event

Version 1.10.26
1. fix downloadTmpltOpt when undefined on compileUpload 

Version 1.10.25
1. add formatsAllowed and downloadTmpltOpt on compileUpload

Version 1.10.24
1. Fix UcForm instance for singleton UcTemplate, add reset UcForm instance once get new template

Version 1.10.23
1. Change font size on button and title

Version 1.10.22
1. Fix button margin and icon

Vesrion 1.10.21
1. Fix lookup and custom component resource for MFE support

Vesrion 1.10.20
1. create listChecked to dictionary on first init

Version 1.10.19
1. fix conflict version

Version 1.10.18
1. legacy support mfe arch

Version 1.10.17
1. fix initial value creation - now can exclude fields (hardcoded)
2. excluded "RFAInfo" fields when initial value creation

Version 1.10.16
1. add experimental flag for new paging & view API

Version 1.10.15
1. add validation for custom button with type submit - won't continue `btnListener` if `Form.valid` is `false`

Version 1.10.14
1. Add support mfe arch

Version 1.10.12
1. Add method onSubmitModal
2. Add default value max limit file size for upload file component

Version 1.10.11
1. fix create approval exclude strings with "_footer", now should use options

Version 1.10.10
1. fix close modal when result empty string
2. fix create approval exclude strings with "_footer"
3. fix component conditions in container component

Version 1.10.9
1. add support to notify dicts changes from ucformarray

Version 1.10.8
1. Optimize persistent page

Version 1.10.7
1. Fix onload form localStorage

Version 1.10.6
1. Add View Upload File Component
2. Add on load Form from dictionary datasource
3. Add attributes transformer json payload
4. Fix object transformer

Version 1.10.5
1. Add Object Mapping for Local Storage action
2. Add Object Mapping for Modal action
3. Add Exclude properties for JSON request payload
4. Add Auto mapping properties for input type tree

Version 1.10.4
1. fix undefined result on cancel modal action

Version 1.10.3
1. Add component File Upload
2. Remove `uc-container` class from new ui css
3. Clearer error message on submit function when url is undefined

Version 1.10.2
1. add `dicts` for `approval create` component
2. add support to notify dicts changes using `notifyUpdateDict`

Version 1.10.1
1. Add feature localStorage datasource in on init form  
2. Add persistent page query params cache
3. Enhance getFormValue for persistent page
4. Fix data flow in persistent page
5. Enhance Local Storage service

Version 1.10.0
1. Add feature persistance page
2. Add local storage service
3. Add action type local storage add, edit, delete and clear

Version 1.9.35
1. pass isPageFromService & pagesUrl to input form obj
2. pass isPageFromService & pagesUrl to input form array obj

Version 1.9.34
1. add support for patch form array value from external component

Version 1.9.33
1. Add component UcAttribute2 (Repeater - Form)

Version 1.9.32
1. fix action type callback inside tabs
2. fix fallback table component data into empty array if not found from result data
3. add usePagination option for table component

Version 1.9.31
1. fix compile form array send navigationConst

Version 1.9.30
1. fix form array edit mode from queryparam
2. support on load action for form array
3. support conditional delete button for form array 
4. add guard for btnListener when action is undefined

Version 1.9.29
1. fix callback function inside tabs component
2. add guard clause to isNumber function

Version 1.9.28
1. Add handler action in modal component
2. Fix btnListener event handler
3. Fix isNumber function

Version 1.9.27
1. fix conditional title
2. fix add button for modal data options
3. Support array value onload form array request parameter, separator ';'

Version 1.9.26
1. add mapping data to dict from response api in http action
2. fix conditional component

Version 1.9.25
1. add button in component
2. add background card for noFormComponent
3. fix top button default style
4. add title for page with 1 component only

Version 1.9.24
1. Add support conditions in criteria search component
2. Add conditional title

Version 1.9.23
1. Update new UI
2. Add action type reload page
3. Add event add/edit/delete refresh table
4. Support array value onload request parameter, separator ';'
5. Support temporary data table
6. Fix container on tabs-x and stepper-x not compiled
7. Fix tabs conditions always set true

Version 1.9.22
1. add switch case condition IF FOUND
2. add switch case condition IF NOT FOUND
3. fix parseValue return boolean
4. add navigation event refresh
5. fix tabs component

Version 1.9.21
1. add condition in custom component

Version 1.9.20
1. add dictionary to funAction if stepper true
2. add clear listTemp when compile add to temp component
3. add next function from external function
4. update stepper UI

Version 1.9.19
1. Fix mapping data to form
2. Fix conditions component with control form criteria

Version 1.9.18
1. Add dictionary from localStorage
2. Add get value from dictionary in condition value
3. Add init action form
4. Add form created output event
5. Add next event handler in container component
6. Fix form criteria
7. Fix Custom Component with Container in Stepper Component
8. Fix Multiple Component stepper with conditions
9. Fix Parameters input in Tabs component from template source

Version 1.9.17
1. fix tabs container component not rendered

Version 1.9.16
1. add support modal scrollable

Version 1.9.15
1. fix issue mapRes undefined

Version 1.9.14
1. fix onload action not work properly (onload action now manage by ucform)

Version 1.9.13
1. fix form cannot enter mode edit

Version 1.9.12
1. Add Contain Condition Restriction
2. Add Not Contain Condition Restriction
3. Add Lookup callback manual input
4. Add Form Raw Value to dictionary data
5. Fix set form edit mode from parameter in dialog component
6. Fix isEmpty value mapping data dictionary
7. Fix form callback overrided by callback form variable observer
8. Fix Get Value empty string converted to 0 value

Version 1.9.11
1. Fix hardcode value not patched

Version 1.9.10
1. Form Input Callback to Component Conditions
2. Add hardcode opsi for set value in map data to form
3. Add support mapping data for UcAddress in Form Component
4. Add delete environment support in Table component
5. Add condition support onload data in Table component
6. Fix Assigned useraccess dictionary initalization
7. Fix criteria restriction IN and NOTIN listvalue

Version 1.9.9
1. Add support state condition component berdasarkan value dari sebuah form input
2. Support date from dictionary for ucview sub title
3. Support array list value in object request value property
4. Support OfficeCodes in create rfa object
5. Fix List Value Paging Criteria and Add to temp criteria
6. Fix onload form action when form component is not visible
7. Fix create rfa jump action submit failed

Version 1.9.8
1. Add Condition in Page Init
2. Add Condition in On load form
3. Add list selection table to dictionary object as 'listChecked'
4. Change Container data output as optional property
5. Enhance Component Condition
6. Fix Condition Not Work in Tabs Component
7. Fix Call function in stepper mode

Version 1.9.7
1. add dictionary output data event
2. fix override data dictionary in input data event

Version 1.9.6
1. add hide cancel button option
2. add two way data binding in uctemplate input property
3. fix compile upload
4. fix criteria with list value not set properly
5. fix change tab component not rendered
6. fix call function on override submit

Version 1.9.5
1. Add two way data binding container component to uctemplate
2. Add onload form action callback
3. Fix Override Cancel 
4. Fix Container not loaded in tabs component

Version 1.9.4
1. Tabs component final release

Version 1.9.3
1. fix delete url on paging (compilePaging)

Version 1.9.2
1. Fix useOffice option for integration obj type apv

Version 1.9.1
1. Fix integration obj set base url and API path

Version 1.9.0
1. Add Tabs component preview version
2. Add support override delete environment in paging component
3. Add onNext event trigger in stepper component
4. Add onChange event trigger in stepper component
5. Add support dictionary data for array input criteria value in paging component
6. Add support dictionary data for array input criteria value in add to temp component
7. Approval support Return to Level and COntinue to Level
8. Add support environment config to form component
9. Add support set TrxNo for create RFA component
10. Fix failed first load component in init current state stepper for container component
11. Fix override submit approval component
12. Fix form array resultData input
13. Fix load input lookup object in form array
14. Fix input pagingInput and Api Report Path in report component
15. Fix parse environment input in Approval General info component
16. Fix parse environment input in Approval History component
17. Fix set transformed object request for Table input data in View component

Version 1.8.3
1. Fix Stepper Component, Container component can't load in current state page init
2. Fix Form array input data from dictionary data source
3. Add support whereValue in paging component
4. Revert container layout to container-fluid layout

Version 1.8.2
1. Support Conditions in Component
2. Support Stepper Current State in Page Init
3. Fix Bottom Button if page not have form component
4. Fix Lookup not properly loaded from local json file
5. Fix Approval General Info & History environment not parsed to enviConfig value

Version 1.8.1
1. Merge hotfix version 1.7.5

Version 1.8.0
1. Add support stepper component
2. Add close button icon in modal
3. Add support modal on cancel and submit action
4. Add support data dictionary as datasource in form array 
5. Fix conditions button not working in bottom buttons

Version 1.7.5
1. Fix merge conflict publish

Version 1.7.4
1. Support data dictionary in ucform component

Version 1.7.3
1. Fix issue callback self implement

Version 1.7.2
1. Support custom route and page folder path

Version 1.7.1
1. UcPaging Support nav constant
2. Add to Temp support from value dictionary data
3. Fix toaster action error message
4. Fix on submit form dictionary data

Version 1.7.0
1. Add feature Grid Button Action Http Request
2. Impl Grid Grid Button Action Function  
3. Impl Grid Text type Http Request  
4. Update Grid Text type Link support data dictionary  
5. Update Apv General Info 
6. Update Apv Hist  
7. Overrideable OnSubmit Action
8. Overrideable OnCancel Action
9. Update Data Dictionary

Version 1.6.7
1. Add support data dictionary approval general info
2. Add support data dictionary approval history
3. Fix set lookup from json file
4. Fix modal get injected ref data
5. Fix Approval general info not rendered in view mode
6. Fix Approval history not rendered in view mode

Version 1.6.6
1. Fix parse value from mapping return object array data

Version 1.6.5
1. Fix parse value from mapping return object

Version 1.6.4
1. Add support data dictionary in where value params
2. Fix form array get detail data
3. Fix paging integration api path using plain path without urlconstant
4. Fix form array get user access from cookie

Version 1.6.3
1. Rollback apv history and apv general info

Version 1.6.2
1. Remove /v1 from uc input create rfa, apv history and apv general info

Version 1.6.1
1. Fix getting nested data from template literals

Version 1.6.0
1. Support Nested Object Request Creation
2. Support Template literals (Template string)
3. Support Table with client side pagination and sort
4. Support Grid Action Type Link
5. Support Grid Action Type Modal
6. Support Button Action Type Link
7. Support Button Action Type Modal
8. Support Button Action Type Http Request
9. Support Button Action Type Call Function
10.Support Button Action Type Switch (Nested Action)
11.Support Button Action Type Toaster
12.Support Button Conditions
13.Support data dictionary in View
14.Support data dictionary in Paging
15.Support data dictionary in Grid
16.Support data dictionary in Add to temp
17.Support data dictionary in Table
18.Fix EnviUrl, remove /v1 in Approval Input Obj

Version 1.5.3
1. Fix mapping object on page init response

Version 1.5.2
1. Paging criteria support data dictionary
2. Lookup criteria support data dictionary
3. Form criteria support data dictionary and cookie
4. Add to temp criteria support data dictionary

Version 1.5.1
1. fix onload in form component after update version 1.5.0

Version 1.5.0
1. add new feature on page init
2. add new feature map data from dictionary, params, hardcode and cookie
3. add new feature override url envi paging lookup from json config
4. add new feature view component support table component
5. add support subsection and title in table component
6. fix lookup value not patch when form mode edit
7. fix table component on transform request payload data
8. fix table component blocked other component
9. fix form mode edit not loaded when on load is empty
10. fix reset form to initial value when redirect self page

Version 1.4.0
1. Support Table view stable release
2. Support Nested Custom Component (Template Component)

Version 1.3.4
1. Fix Update Form Value

Version 1.3.3
1. Fix cosmetic layout issue's
2. Fix onload isHumanApproval
3. Fix resetFormValue to initial form value

Version 1.3.2
1. Support GridView Beta version
2. Fix layout template 
3. Reset list button
4. Optimize code

Version 1.3.1
1. Support Custom Component Template Beta version (reuse component template)
2. Support conditional create rfa config isHumanApproval
3. Support URLConstant in apiPath property
4. Support hard code set scheme code in create rfa 
5. Fix submit handler approval
6. Fix submit handler create approval
7. Rename component alias create rfa
8. Rename property dataInput to formInput in ucformarray input object

Version 1.3.0
1. Support override environmentUrl
   - UcAddress
   - UcUpload
   - UcPaging
   - UcLookup
2. Support override apiUrl
   - UcLookup
   - UcPaging
3. Support Callback Form
4. Support Data Dictionary 
5. Support Map Response Object to Form Variable
6. Fix Parsed Date title not formatted as defined format
7. Fix Create Request for Approval
8. Add listValue criteria object
   - ucaddtotemp
   - form type lookup
   - ucpaging
9. Notify form update to ucform   

Version 1.2.3
1. Fix form submit self page
2. Approval Create button submit ke hide

Version 1.2.2
1. Fix Approval Reason tidak terpatch

Version 1.2.1
1. Add support navConstant
2. Bugfix: submit hide btn

Version 1.2.0
1. Bug fixes
2. Enhance uctemplate feature

Version 1.1.1
1. Bug fix: Dropdown list
2. Bug fix: Lookup tidak muncul

Version 1.1.0
1. Support lookup config from json file

Version 1.0.1
1. Update angular version 13

Version 1.0.0
1. Final release UcTemplate

Version 0.0.1
1. initial library UcTemplate

## Dependency
## Dependency Module
import this module : 
- FormsModule `npm i @angular/forms`
- UcPagingModule `npm i @adins/ucpaging`
- UcFormModule `npm i @adins/ucform`
- UcDirectiveUpperCaseModule `npm i @adins/uc-directive-upper-case`
- UcFormarrayModule `npm i @adins/ucformarray`
- UcAddtotempModule `npm i @adins/ucaddtotemp`
- UcViewgenericModule `npm i @adins/ucviewgeneric`
- ToastrModule `npm i ngx-toastr`
- NgxCurrencyModule `npm i ngx-currency`
- UcReportModule `npm i @adins/ucreport`
- UcUploadModule `npm i @adins/ucupload`
- UcApprovalcreateModule `npm i @adins/ucapprovalcreate`
- UcApprovalR3Module `npm i @adins/ucapproval-r3`
- UcApprovalgeneralinfoModule `npm i @adins/ucapprovalgeneralinfo`
- UcApprovalHistoryModule `npm i @adins/ucapproval-history`

## Selector
Selector: `adins-uctemplate`

## Input
1. pageName     : Identifier template pageName (string) *mandatory
2. Form   : Form (FormGroup) *optional
3. container     : List of component class for injected in container *optional
4. handler  : Function handler for self-custom / self-implement

## Output

## Injection Service
After installed all dependencies module, before use UcTemplate we need to create Injection Service for `UcTemplateService`

Generate new service `ng g service AdinsTemplate` and extend it to `UcTemplateService`
``` typescript
import {Injectable} from '@angular/core';
import {UcTemplateService} from '@adins/uctemplate';
import {environment} from '../../../environments/environment';
import {envi, URLConstant} from '../../shared/constant/URLConstant';
import * as _moment from 'moment';
import {AdInsHelper} from '../../shared/AdInsHelper';
import {CookieService} from 'ngx-cookie';

/** Import all component module tobe injected in container */
import * as Module from '../../form-template';
import {NavigationConstant} from '../../shared/NavigationConstant';

const listEnvironments = [
  { environment: 'FOU', url: envi.FoundationR3Url + '/v1' },
  { environment: 'FOU_WEB', url: envi.FoundationR3Web },
  { environment: 'FOUR3WEB', url: URLConstant.environment.fouR3Web },
  { environment: 'LOSR3WEB', url: URLConstant.environment.losR3Web },
  { environment: 'LMSR3WEB', url: URLConstant.environment.lmsR3Web },
  { environment: 'PAYMENT', url: URLConstant.environment.PaymentUrl },
  { environment: 'AR', url: URLConstant.environment.ARUrl + '/v1' },
  { environment: 'ARMNT', url: URLConstant.environment.ARMNTUrl + '/v1' },
  { environment: 'LOS', url: envi.LosURL + '/v1' }
];

@Injectable({
  providedIn: 'root'
})
export class AdinsTemplateService extends UcTemplateService {

  constructor() {
    super();

    this.configure();
  }

  getCookie(cookieService: CookieService, key: string): any {
    return AdInsHelper.GetCookie(cookieService, key);
  }

  private configure() {
    this.environment  = environment;
    this.envConfig    = envi;
    this.urlConstant  = URLConstant;
    this.navConstant  = NavigationConstant;
    this.listEnvironments = listEnvironments;
    this.moment = _moment;
    this.module = Module;
  }
}
```

## Setup Provider
After creating Injection Service then we need to provide `UcTemplateService` with Injection Service we created `AdinsTemplateService` at `providers` property in `AppModule` 
``` typescript
@NgModule({
    declarations: [
        ...
    ],
    imports: [
        ...
    ],
    providers: [
        ...,
        { provide: UcTemplateService, useClass: AdinsTemplateService }
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
    constructor() {
    }
}
```

## Setup Routes
Open file `full-layout.routes.ts` add `BREAD` route in `Full_ROUTES` array
``` typescript
export const Full_ROUTES: Routes = [
  {
    path: PathConstant.LR_DASHBOARD,
    loadChildren: () => import('app/dashboard/dashboard.module').then(m => m.DashboardModule)
  },
  {
    path: 'BREAD/:page',
    component: UcTemplateComponent
  },
  ...
];
```

## How to Access Page
All pages within `BREAD` route can be access using these format `http[s]://ip_address|domain/BREAD/pageIdentifier`

Example<br/>
http: `http://localhost:4200/BREAD/Profession` <br/>
https: `https://r3-webserver.ad-ins.com/BREAD/Profession`


## Build

Run `ng build uctemplate` to build the project. The build artifacts will be stored in the `dist/` directory.

## Publishing

After building your library with `ng build uctemplate`, go to the dist folder `cd dist/uctemplate` and run `npm publish`.

## Running unit tests

Run `ng test uctemplate` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
