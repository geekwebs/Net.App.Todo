export * from './lib/uctemplate.service';
export * from './lib/uctemplate.component';
export * from './lib/uctemplate.module';
export * from './lib/services';
export * from './lib/interfaces';
